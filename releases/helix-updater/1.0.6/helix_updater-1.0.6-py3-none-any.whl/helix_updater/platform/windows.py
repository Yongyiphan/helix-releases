from __future__ import annotations

import json
from pathlib import Path
import subprocess


class WindowsPlatform:
    """SCM boundary; pywin32 is loaded only when service operations are used."""
    def __init__(self, service_manager=None, runner=subprocess.run):
        self.service_manager = service_manager
        self.runner = runner

    def _manager(self):
        if self.service_manager is None:
            import win32serviceutil
            self.service_manager = win32serviceutil
        return self.service_manager

    def stop_service(self, name):
        if not name:
            return
        if self.service_manager is not None:
            self._manager().StopService(name)
            return
        result = self.runner(("sc.exe", "stop", name), check=False, capture_output=True, text=True)
        if result.returncode and "1060" not in (result.stdout + result.stderr):
            raise RuntimeError(f"sc.exe stop {name} failed: {(result.stdout + result.stderr).strip()}")
    def start_service(self, name):
        if not name:
            return
        if self.service_manager is not None:
            self._manager().StartService(name)
            return
        result = self.runner(("sc.exe", "start", name), check=False, capture_output=True, text=True)
        if result.returncode:
            raise RuntimeError(f"sc.exe start {name} failed: {(result.stdout + result.stderr).strip()}")
    def service_running(self, name):
        if not name:
            return True
        if self.service_manager is not None:
            return self._manager().QueryServiceStatus(name)[1] == 4
        result = self.runner(("sc.exe", "query", name), check=False, capture_output=True, text=True)
        return result.returncode == 0 and "RUNNING" in (result.stdout + result.stderr)

    def activate(self, root: Path, release: Path):
        root.mkdir(parents=True, exist_ok=True)
        releases_root = (root / "releases").resolve()
        release = release.resolve()
        if not release.is_relative_to(releases_root):
            raise ValueError(f"release is outside target root: {release}")
        path = root / "installation.json"
        current = json.loads(path.read_text(encoding="utf-8")) if path.exists() else {"schema": 1, "releases": []}
        releases = [str(release)] + [item for item in current.get("releases", []) if item != str(release)]
        temporary = path.with_suffix(".json.new")
        temporary.write_text(json.dumps({**current, "active": str(release), "releases": releases}, indent=2) + "\n", encoding="utf-8")
        temporary.replace(path)

    def active(self, root):
        path = root / "installation.json"
        if not path.exists(): return None
        value = json.loads(path.read_text(encoding="utf-8"))
        active = Path(value["active"]).resolve() if value.get("active") else None
        if active and not active.is_relative_to((root / "releases").resolve()):
            raise ValueError(f"active release is outside target root: {active}")
        return active
