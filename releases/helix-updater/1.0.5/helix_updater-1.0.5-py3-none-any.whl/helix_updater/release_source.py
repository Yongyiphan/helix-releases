from __future__ import annotations

from dataclasses import dataclass
import json
import os
from pathlib import Path
import platform as host_platform
import subprocess
import tempfile

from .manifest import ManifestError, ReleaseManifest
from .registry import PackageSubscription


class ReleaseSourceError(RuntimeError):
    pass


class NoReleaseAvailable(ReleaseSourceError):
    pass


@dataclass(frozen=True)
class DiscoveredRelease:
    manifest: ReleaseManifest
    manifest_url: str
    artifact_url: str
    tag: str


class GitHubReleaseSource:
    """GitHub release source backed exclusively by the authenticated ``gh`` CLI."""

    def __init__(self, repository: str, *, runner=subprocess.run, gh_config_dir: str | Path | None = None):
        self.repository = repository
        self.runner = runner
        self.gh_config_dir = Path(gh_config_dir).expanduser() if gh_config_dir else None

    def discover(self, subscription: PackageSubscription) -> DiscoveredRelease:
        releases = self._json(("gh", "release", "list", "--repo", self.repository, "--limit", "100", "--json", "tagName,isDraft,isPrerelease"))
        if not isinstance(releases, list):
            raise ReleaseSourceError("gh release list returned an invalid response")
        for release in releases:
            if not isinstance(release, dict) or release.get("isDraft") or (release.get("isPrerelease") and subscription.channel == "stable"):
                continue
            tag = release.get("tagName")
            if not isinstance(tag, str) or not tag:
                continue
            try:
                details = self._json(("gh", "release", "view", tag, "--repo", self.repository, "--json", "assets"))
                assets = details.get("assets", []) if isinstance(details, dict) else []
                if not isinstance(assets, list):
                    continue
                manifest_asset = next((item for item in assets if isinstance(item, dict) and str(item.get("name", "")).endswith(".manifest.json")), None)
                if not manifest_asset:
                    continue
                manifest_name = manifest_asset.get("name")
                manifest = ReleaseManifest.from_bytes(self._download_asset(tag, manifest_name))
                if manifest.package != subscription.package_id or manifest.channel != subscription.channel:
                    continue
                artifact = manifest.artifact_for(self.platform_key())
                artifact_asset = next((item for item in assets if isinstance(item, dict) and item.get("name") == artifact.file), None)
                if not artifact_asset:
                    continue
                return DiscoveredRelease(manifest, self._asset_id(tag, manifest_name), self._asset_id(tag, artifact.file), tag)
            except (ManifestError, ReleaseSourceError):
                continue
        raise NoReleaseAvailable(f"no valid {subscription.package_id} release for channel {subscription.channel}")

    def download_artifact(self, release: DiscoveredRelease, destination: Path) -> None:
        self._download_asset(release.tag, self._asset_name(release.artifact_url), destination=destination)

    def _download_asset(self, tag: str, name: str | None, *, destination: Path | None = None):
        if not isinstance(name, str) or not name or Path(name).name != name:
            raise ReleaseSourceError("release asset has an invalid filename")
        if destination is None:
            with tempfile.TemporaryDirectory(prefix="helix-updater-gh-") as directory:
                path = self._download_asset(tag, name, destination=Path(directory) / name)
                return path.read_bytes()
        destination.parent.mkdir(parents=True, exist_ok=True)
        self._run(("gh", "release", "download", tag, "--repo", self.repository, "--pattern", name, "--dir", str(destination.parent), "--clobber"), timeout=120)
        downloaded = destination.parent / name
        if not downloaded.is_file():
            raise ReleaseSourceError(f"gh did not download expected release asset: {name}")
        if downloaded != destination:
            downloaded.replace(destination)
        return destination

    def _json(self, command: tuple[str, ...]):
        result = self._run(command, timeout=60)
        try:
            return json.loads(result.stdout)
        except json.JSONDecodeError as exc:
            raise ReleaseSourceError("gh returned invalid JSON") from exc

    def _run(self, command: tuple[str, ...], *, timeout: int):
        environment = os.environ.copy()
        if self.gh_config_dir:
            environment["GH_CONFIG_DIR"] = str(self.gh_config_dir)
        result = self.runner(command, check=False, capture_output=True, text=True, env=environment, timeout=timeout)
        if result.returncode != 0:
            detail = (result.stderr or result.stdout or "gh command failed").strip()
            if "not found" in detail.lower() or "no such file" in detail.lower():
                raise ReleaseSourceError("GitHub release access requires the authenticated gh CLI")
            raise ReleaseSourceError(f"gh release access failed for {self.repository}: {detail[-1000:]}")
        return result

    def _asset_id(self, tag: str, name: str) -> str:
        return f"gh://{self.repository}/{tag}/{name}"

    @staticmethod
    def _asset_name(asset_id: str) -> str:
        if not asset_id.startswith("gh://"):
            raise ReleaseSourceError("invalid gh release asset reference")
        name = asset_id.rsplit("/", 1)[-1]
        if not name or Path(name).name != name:
            raise ReleaseSourceError("invalid gh release asset filename")
        return name

    @staticmethod
    def platform_key() -> str:
        system = "windows" if host_platform.system().lower() == "windows" else "linux"
        machine = host_platform.machine().lower().replace("amd64", "x86_64").replace("x64", "x86_64")
        return f"{system}-{machine}"


class CatalogReleaseSource:
    """Read the HR public-catalog layout from a local checkout or mounted path."""

    def __init__(self, root: str | Path):
        self.root = Path(root).expanduser().resolve()

    def discover(self, subscription: PackageSubscription) -> DiscoveredRelease:
        base = self.root / "releases" / subscription.package_id
        if not base.is_dir():
            raise NoReleaseAvailable(f"catalog has no package: {subscription.package_id}")
        candidates: list[DiscoveredRelease] = []
        for manifest_path in base.glob("*/manifest.json"):
            try:
                manifest = ReleaseManifest.from_bytes(manifest_path.read_bytes())
                if manifest.package != subscription.package_id or manifest.channel != subscription.channel:
                    continue
                artifact = manifest.artifact_for(self.platform_key())
                artifact_path = manifest_path.parent / artifact.file
                if not artifact_path.is_file():
                    continue
                candidates.append(DiscoveredRelease(manifest, str(manifest_path), str(artifact_path), manifest.version))
            except (OSError, ManifestError):
                continue
        if not candidates:
            raise NoReleaseAvailable(f"no valid {subscription.package_id} release in catalog")
        return max(candidates, key=lambda item: _version_key(item.manifest.version))

    def download_artifact(self, release: DiscoveredRelease, destination: Path) -> None:
        source = Path(release.artifact_url)
        if not source.is_file():
            raise ReleaseSourceError(f"catalog artifact is missing: {source}")
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes(source.read_bytes())

    @staticmethod
    def platform_key() -> str:
        system = "windows" if host_platform.system().lower() == "windows" else "linux"
        machine = host_platform.machine().lower().replace("amd64", "x86_64").replace("x64", "x86_64")
        return f"{system}-{machine}"


def _version_key(value: str) -> tuple:
    parts = []
    for part in value.split("."):
        digits = "".join(char for char in part if char.isdigit())
        parts.append((0, int(digits)) if digits else (1, part))
    return tuple(parts)
