from __future__ import annotations

from pathlib import Path
import shutil
import tempfile

from .installer import PackageInstaller
from .discovery import RepositoryDiscovery, write_inventory
from .release_source import CatalogReleaseSource, GitHubReleaseSource, NoReleaseAvailable
from .registry import PackageSubscription, Registry
from .state import StateStore
from .verifier import verify_artifact
from .self_update import SelfUpdateRequested, prepare_self_update


def _version_key(value: str) -> tuple:
    # Release ordering is intentionally conservative for the first milestone:
    # numeric dot-separated versions and prerelease text are supported without
    # pretending to solve arbitrary package-version semantics.
    parts = []
    for part in value.split("."):
        digits = "".join(char for char in part if char.isdigit())
        parts.append((0, int(digits)) if digits else (1, part))
    return tuple(parts)


def _satisfies(current: str, requirement: str) -> bool:
    requirement = requirement.strip()
    for operator in (">=", "<=", "==", ">", "<"):
        if requirement.startswith(operator):
            expected = requirement[len(operator):].strip()
            left, right = _version_key(current), _version_key(expected)
            return {">=": left >= right, "<=": left <= right, "==": left == right, ">": left > right, "<": left < right}[operator]
    raise ValueError(f"unsupported updater requirement: {requirement}")


class Updater:
    def __init__(self, registry: Registry, *, source_factory=None, platform=None):
        self.registry = registry
        self.state = StateStore(registry.state_root)
        self.source_factory = source_factory or (lambda package: CatalogReleaseSource(package.source.repository) if package.source.type == "catalog" else GitHubReleaseSource(package.source.repository, gh_config_dir=registry.gh_config_dir))
        if platform is None:
            platform = __import__("platform").system().lower()
            platform = __import__("helix_updater.platform.windows" if platform == "windows" else "helix_updater.platform.linux", fromlist=["*"])
            platform = platform.WindowsPlatform() if platform.__name__.endswith("windows") else platform.LinuxPlatform()
        self.installer = PackageInstaller(self.state, platform)

    def subscriptions(self, package_id: str | None = None):
        packages = [package for package in self.registry.packages.values()
                    if package.enabled and (package_id is None or package.package_id == package_id)]
        # HU must update itself before it evaluates the rest of the catalog.
        # Self-update exits the current service loop after handing off to its
        # helper, so this ordering is part of the safety contract.
        return tuple(sorted(packages, key=lambda package: (package.package_id != "helix-updater", package.package_id)))

    def adopt(self, package: PackageSubscription, version: str) -> Path:
        active = self.installer.platform.active(package.target.root)
        releases_root = (package.target.root / "releases").resolve()
        if active is None or not active.is_dir() or not active.resolve().is_relative_to(releases_root):
            raise RuntimeError(f"no safe existing release found for {package.package_id}")
        if not version.strip():
            raise ValueError("adoption requires the installed release version")
        observations = RepositoryDiscovery(self.registry).scan()
        matching = [item for item in observations if item.package == package.package_id and item.repository == package.source.repository.strip().lower()]
        if not matching:
            raise RuntimeError(f"no local repository observation matches {package.source.repository}")
        if matching[0].production_paths and str(package.target.root) not in matching[0].production_paths:
            raise RuntimeError(f"configured target {package.target.root} was not found in project deployment metadata")
        write_inventory(self.state.inventory_path, observations)
        self.state.write(package.package_id, {"state": "successful", "current": version, "current_path": str(active), "failed_releases": []})
        return active

    def check(self, package: PackageSubscription):
        current_state = self.state.read(package.package_id)
        current = current_state.get("current")
        self.state.write(package.package_id, {"state": "discovering", "current": current, "failed_releases": current_state.get("failed_releases", [])})
        try:
            release = self.source_factory(package).discover(package)
        except NoReleaseAvailable:
            self.state.write(package.package_id, {"state": "no_release_available", "current": current, "latest": None, "failed_releases": current_state.get("failed_releases", [])})
            return None, False
        if release.manifest.updater_requirement and not _satisfies(self.registry.updater_version, release.manifest.updater_requirement):
            raise RuntimeError(f"release requires updater {release.manifest.updater_requirement}; installed updater is {self.registry.updater_version}")
        failed_versions = {str(item.get("version")) for item in current_state.get("failed_releases", []) if isinstance(item, dict)}
        if release.manifest.version in failed_versions:
            self.state.write(package.package_id, {"state": "failed", "current": current, "latest": release.manifest.version, "candidate_suppressed": True, "failed_releases": current_state.get("failed_releases", [])})
            return release, False
        if current and _version_key(release.manifest.version) <= _version_key(str(current)):
            self.state.write(package.package_id, {"state": "successful", "current": current, "latest": release.manifest.version, "failed_releases": current_state.get("failed_releases", [])})
            return release, False
        self.state.write(package.package_id, {"state": "successful", "current": current, "latest": release.manifest.version, "failed_releases": current_state.get("failed_releases", [])})
        return release, True

    def update(self, package: PackageSubscription):
        release, needed = self.check(package)
        if not needed or release is None:
            return None
        active = self.installer.platform.active(package.target.root)
        if active and not self.state.read(package.package_id).get("current"):
            raise RuntimeError(f"{package.package_id} has an existing active release; adopt it before updating")
        artifact_meta = release.manifest.artifact_for(self.installer._platform_key())
        current_state = self.state.read(package.package_id)
        unsafe = current_state.get("failed_releases", [])
        if any(isinstance(item, dict) and item.get("version") == release.manifest.version and item.get("artifact_sha256") == artifact_meta.sha256 for item in unsafe):
            self.state.write(package.package_id, {**current_state, "state": "failed", "latest": release.manifest.version, "candidate_suppressed": True})
            return None
        self.registry.download_root.mkdir(parents=True, exist_ok=True)
        temporary_directory = Path(tempfile.mkdtemp(prefix=f"{package.package_id}-", dir=self.registry.download_root))
        temporary = temporary_directory / Path(artifact_meta.file).name
        try:
            self.source_factory(package).download_artifact(release, temporary)
            verify_artifact(temporary, artifact_meta)
            if package.package_id == "helix-updater":
                prepare_self_update(self.registry, self.state, package, release.manifest, temporary, self.installer.platform)
                raise SelfUpdateRequested(release.manifest.version)
            return self.installer.install(package, release.manifest, temporary)
        except SelfUpdateRequested:
            raise
        except Exception as exc:
            self._record_failed_release(package, release.manifest.version, artifact_meta.sha256, str(exc))
            raise
        finally:
            shutil.rmtree(temporary_directory, ignore_errors=True)

    def _record_failed_release(self, package: PackageSubscription, version: str, digest: str, reason: str) -> None:
        """Persist an unsafe candidate even when failure occurs before installation starts."""
        current = self.state.read(package.package_id)
        failed = list(current.get("failed_releases", []))
        duplicate = any(
            isinstance(item, dict)
            and item.get("version") == version
            and item.get("artifact_sha256") == digest
            for item in failed
        )
        if duplicate:
            return
        failed.append({"version": version, "artifact_sha256": digest, "reason": reason})
        self.state.write(
            package.package_id,
            {
                **current,
                "state": "failed",
                "latest": version,
                "candidate_suppressed": True,
                "failed_releases": failed,
                "error": reason,
            },
        )
