"""Native Windows SCM host for the HU polling loop."""

from __future__ import annotations

import os

import servicemanager
import win32event
import win32service
import win32serviceutil

from .cli import main


class HelixUpdaterService(win32serviceutil.ServiceFramework):
    _svc_name_ = "HelixUpdater"
    _svc_display_name_ = "Helix Updater"
    _svc_description_ = "Discovers and updates registered Helix components."

    def __init__(self, args):
        super().__init__(args)
        self.stop_event = win32event.CreateEvent(None, 0, 0, None)

    def SvcStop(self):
        self.ReportServiceStatus(win32service.SERVICE_STOP_PENDING)
        win32event.SetEvent(self.stop_event)

    def SvcDoRun(self):
        servicemanager.LogInfoMsg("HelixUpdater service started")
        config = os.getenv("HELIX_UPDATER_CONFIG", r"C:\ProgramData\Helix\Updater\helix-updater.toml")
        main(["--config", config, "serve"], stop_event=_StopEvent(self.stop_event))
        servicemanager.LogInfoMsg("HelixUpdater service stopped")


class _StopEvent:
    def __init__(self, handle):
        self.handle = handle

    def wait(self, timeout: float) -> bool:
        result = win32event.WaitForSingleObject(self.handle, int(timeout * 1000))
        return result == win32event.WAIT_OBJECT_0


if __name__ == "__main__":
    win32serviceutil.HandleCommandLine(HelixUpdaterService)
