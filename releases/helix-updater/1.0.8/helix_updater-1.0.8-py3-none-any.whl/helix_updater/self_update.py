from __future__ import annotations

import json
from pathlib import Path
import secrets
import sys
from datetime import datetime, timezone

from .manifest import ReleaseManifest
from .registry import PackageSubscription, Registry
from .staging import stage_artifact
from .state import StateStore
from .verifier import verify_artifact


class SelfUpdateRequested(RuntimeError):
    """Signals the service loop to exit after handing off to the helper."""


def prepare_self_update(
    registry: Registry,
    state: StateStore,
    package: PackageSubscription,
    manifest: ReleaseManifest,
    artifact: Path,
    platform,
) -> None:
    """Stage HU and hand the mechanical apply operation to a Linux helper."""
    if not hasattr(platform, "launch_self_update") or not hasattr(platform, "platform_key"):
        raise RuntimeError("HU self-update is not implemented for this platform")
    platform_key = platform.platform_key()
    if not platform_key.startswith("linux-"):
        raise RuntimeError("HU self-update is currently implemented only on Linux")
    if manifest.install.strategy != "python_wheel":
        raise ValueError("Linux HU self-update currently requires a Python wheel")

    root = package.target.root.expanduser().resolve()
    current = platform.active(root)
    if current is None:
        raise RuntimeError("HU self-update requires an adopted active release")
    verify_artifact(artifact, manifest.artifact_for(platform_key))
    candidate = stage_artifact(artifact, root, manifest.version, manifest.install.strategy)
    transaction_id = secrets.token_hex(16)
    state.write_self_update({
        "state": "self_update_prepared",
        "transaction_id": transaction_id,
        "component": package.package_id,
        "current_version": state.read(package.package_id).get("current", "unknown"),
        "candidate_version": manifest.version,
        "candidate_path": str(candidate),
        "previous_path": str(current),
        "service": package.target.service or "helix-updater.service",
        "startup_ack_path": str(state.root / "startup-ack.json"),
        "artifact_sha256": manifest.artifact_for(platform_key).sha256,
    })
    helper = [sys.executable, "-m", "helix_updater.bootstrap", "--state", str(state.self_update_path)]
    state.write_self_update({**state.read_self_update(), "state": "helper_launched"})
    platform.launch_self_update(helper)


def acknowledge_startup(state: StateStore, version: str) -> None:
    """Let the helper distinguish a healthy candidate from an old restart."""
    tx = state.read_self_update()
    if not tx or tx.get("state") not in {"helper_launched", "stopping_service", "activating", "starting_service", "awaiting_health"}:
        return
    if tx.get("candidate_version") != version:
        return
    path = Path(tx["startup_ack_path"])
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(".json.new")
    temporary.write_text(json.dumps({"transaction_id": tx["transaction_id"], "version": version, "status": "ready", "started_at": datetime.now(timezone.utc).isoformat()}, sort_keys=True) + "\n", encoding="utf-8")
    temporary.replace(path)
    active = Path(tx.get("candidate_path", "")).resolve()
    root = active.parent.parent
    current = root / "current"
    if current.is_symlink() and current.resolve() == active:
        state.write_self_update({**tx, "state": "successful", "current_version": version})
        package_state = state.read("helix-updater")
        state.write("helix-updater", {**package_state, "state": "successful", "current": version, "current_path": str(active), "previous": tx.get("current_version"), "previous_path": tx.get("previous_path")})
