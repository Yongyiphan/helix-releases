from __future__ import annotations

from pathlib import Path
import shutil
import subprocess
import sys
import os
import tarfile
import zipfile


def stage_artifact(artifact: Path, root: Path, version: str, strategy: str = "file") -> Path:
    if not artifact.is_file():
        raise ValueError(f"artifact does not exist: {artifact}")
    if not version or any(part in version for part in ("/", "\\")):
        raise ValueError("invalid release version")
    root = root.expanduser().resolve()
    if root == Path(root.anchor) or len(root.parts) < 3:
        raise ValueError(f"refusing unsafe installation root: {root}")
    releases = root / "releases"
    releases.mkdir(parents=True, exist_ok=True)
    destination = releases / version
    if destination.exists():
        raise ValueError(f"release already staged: {version}")
    temporary = releases / f".{version}.staging"
    temporary.mkdir()
    published = False
    try:
        if strategy == "archive":
            _extract_archive(artifact, temporary)
            (temporary / "artifact").write_text(artifact.name + "\n", encoding="utf-8")
        else:
            shutil.copy2(artifact, temporary / artifact.name)
            (temporary / "artifact").write_text(artifact.name + "\n", encoding="utf-8")
        if strategy == "python_wheel":
            runtime = temporary / ".venv"
            subprocess.run((sys.executable, "-m", "venv", str(runtime)), check=True, capture_output=True)
            runtime_python = runtime / ("Scripts/python.exe" if os.name == "nt" else "bin/python")
            result = subprocess.run((str(runtime_python), "-m", "pip", "install", "--no-cache-dir", str(artifact)), check=False, capture_output=True, text=True)
            if result.returncode:
                detail = (result.stderr or result.stdout).strip()[-2000:]
                raise RuntimeError(f"runtime artifact installation failed: {detail}")
        elif strategy != "file":
            raise ValueError(f"unsupported install strategy: {strategy}")
        temporary.replace(destination)
        published = True
        if strategy == "python_wheel":
            _relocate_python_venv(destination / ".venv", temporary / ".venv")
    except Exception:
        shutil.rmtree(temporary, ignore_errors=True)
        if published:
            shutil.rmtree(destination, ignore_errors=True)
        raise
    return destination


def _relocate_python_venv(runtime: Path, old_runtime: Path) -> None:
    """Repair console-script launchers after moving a Python virtualenv.

    ``venv`` writes an absolute interpreter path into generated scripts. HU
    stages releases under a temporary directory and then atomically publishes
    them under their version, so those launchers otherwise keep pointing at a
    directory that no longer exists. Unix launchers are text files; Windows
    venvs keep the interpreter reference in ``*-script.py`` companions.
    """
    if not runtime.is_dir():
        raise RuntimeError(f"staged Python runtime is missing: {runtime}")
    old_text = str(old_runtime)
    new_text = str(runtime)
    script_dir = runtime / ("Scripts" if os.name == "nt" else "bin")
    if not script_dir.is_dir():
        raise RuntimeError(f"staged Python runtime scripts are missing: {script_dir}")
    for script in script_dir.iterdir():
        if not script.is_file() or script.suffix.lower() == ".exe":
            continue
        try:
            content = script.read_text(encoding="utf-8")
        except (UnicodeDecodeError, OSError):
            continue
        if not content.startswith("#!") or old_text not in content:
            continue
        script.write_text(content.replace(old_text, new_text), encoding="utf-8")


def prune_release_runtimes(root: Path, keep_versions: set[str]) -> tuple[str, ...]:
    """Remove virtualenvs from old releases while preserving rollback runtimes.

    Release directories and their immutable artifacts remain available. Only
    ``.venv`` directories for releases outside ``keep_versions`` are removed.
    This keeps the active and previous known-good versions immediately
    runnable without allowing every historical release to consume a full
    dependency environment.
    """
    root = root.expanduser().resolve()
    releases = root / "releases"
    if root == Path(root.anchor) or len(root.parts) < 3 or not releases.is_dir():
        return ()
    removed: list[str] = []
    for release in releases.iterdir():
        if not release.is_dir() or release.is_symlink() or release.name.startswith("."):
            continue
        if release.name in keep_versions:
            continue
        runtime = release / ".venv"
        if runtime.is_dir() and not runtime.is_symlink():
            shutil.rmtree(runtime)
            removed.append(release.name)
    return tuple(sorted(removed))


def _extract_archive(artifact: Path, destination: Path) -> None:
    if zipfile.is_zipfile(artifact):
        with zipfile.ZipFile(artifact) as archive:
            for member in archive.infolist():
                target = (destination / member.filename).resolve()
                if not target.is_relative_to(destination.resolve()):
                    raise ValueError(f"archive member escapes staging directory: {member.filename}")
            archive.extractall(destination)
        return
    if tarfile.is_tarfile(artifact):
        with tarfile.open(artifact) as archive:
            members = archive.getmembers()
            for member in members:
                target = (destination / member.name).resolve()
                if not target.is_relative_to(destination.resolve()):
                    raise ValueError(f"archive member escapes staging directory: {member.name}")
                if member.issym() or member.islnk():
                    link_target = (target.parent / member.linkname).resolve()
                    if not link_target.is_relative_to(destination.resolve()):
                        raise ValueError(f"archive link escapes staging directory: {member.name}")
            try:
                archive.extractall(destination, filter="data")
            except TypeError:  # Python 3.11: members were already validated above.
                archive.extractall(destination)
        return
    raise ValueError(f"unsupported archive format: {artifact.name}")
