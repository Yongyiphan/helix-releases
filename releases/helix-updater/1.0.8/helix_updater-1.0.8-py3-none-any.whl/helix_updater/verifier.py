from __future__ import annotations

import hashlib
from pathlib import Path

from .manifest import Artifact


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def verify_artifact(path: Path, artifact: Artifact) -> None:
    actual = sha256(path)
    if actual != artifact.sha256:
        raise ValueError(f"artifact checksum mismatch: expected {artifact.sha256}, got {actual}")
