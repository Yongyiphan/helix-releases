from __future__ import annotations

import json
from pathlib import Path
import subprocess


class WindowsPlatform:
    """SCM boundary using the Windows-provided ``sc.exe`` command."""
    def __init__(self, runner=subprocess.run, poll_interval=0.5, timeout=60):
        self.runner = runner
        self.poll_interval = poll_interval
        self.timeout = timeout

    def _query(self, name):
        result = self.runner(("sc.exe", "query", name), check=False, capture_output=True, text=True)
        output = result.stdout + result.stderr
        if result.returncode != 0:
            return None if "1060" in output else "UNKNOWN"
        for state in ("RUNNING", "STOPPED", "START_PENDING", "STOP_PENDING", "PAUSED"):
            if state in output:
                return state
        return "UNKNOWN"

    def _wait_for(self, name, expected):
        import time
        deadline = time.monotonic() + self.timeout
        while time.monotonic() < deadline:
            state = self._query(name)
            if state in expected:
                return
            time.sleep(self.poll_interval)
        raise RuntimeError(f"service {name} did not reach {sorted(expected)}; final state: {self._query(name)}")

    def stop_service(self, name):
        if not name:
            return
        result = self.runner(("sc.exe", "stop", name), check=False, capture_output=True, text=True)
        if result.returncode and "1060" not in (result.stdout + result.stderr):
            raise RuntimeError(f"sc.exe stop {name} failed: {(result.stdout + result.stderr).strip()}")
        self._wait_for(name, {None, "STOPPED"})
    def start_service(self, name):
        if not name:
            return
        result = self.runner(("sc.exe", "start", name), check=False, capture_output=True, text=True)
        if result.returncode:
            raise RuntimeError(f"sc.exe start {name} failed: {(result.stdout + result.stderr).strip()}")
        self._wait_for(name, {"RUNNING"})
    def service_running(self, name):
        if not name:
            return True
        return self._query(name) == "RUNNING"

    def activate(self, root: Path, release: Path):
        root.mkdir(parents=True, exist_ok=True)
        releases_root = (root / "releases").resolve()
        release = release.resolve()
        if not release.is_relative_to(releases_root):
            raise ValueError(f"release is outside target root: {release}")
        path = root / "installation.json"
        current = json.loads(path.read_text(encoding="utf-8")) if path.exists() else {"schema": 1, "releases": []}
        releases = [str(release)] + [item for item in current.get("releases", []) if item != str(release)]
        temporary = path.with_suffix(".json.new")
        temporary.write_text(json.dumps({**current, "active": str(release), "releases": releases}, indent=2) + "\n", encoding="utf-8")
        temporary.replace(path)

    def active(self, root):
        path = root / "installation.json"
        if not path.exists(): return None
        value = json.loads(path.read_text(encoding="utf-8"))
        active = Path(value["active"]).resolve() if value.get("active") else None
        if active and not active.is_relative_to((root / "releases").resolve()):
            raise ValueError(f"active release is outside target root: {active}")
        return active
