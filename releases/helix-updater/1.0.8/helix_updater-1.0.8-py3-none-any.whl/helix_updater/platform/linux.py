from __future__ import annotations

import os
import hashlib
from pathlib import Path
import subprocess


class LinuxPlatform:
    def __init__(self, runner=subprocess.run):
        self.runner = runner

    def _systemctl(self, action, name):
        if not name:
            return
        result = self.runner(("systemctl", action, name), check=False, capture_output=True, text=True)
        if result.returncode != 0 and not (action == "stop" and "not be found" in result.stderr.lower()):
            raise RuntimeError(f"systemctl {action} {name} failed: {result.stderr.strip()}")

    def stop_service(self, name): self._systemctl("stop", name)
    def start_service(self, name): self._systemctl("start", name)
    def service_running(self, name):
        if not name: return True
        return self.runner(("systemctl", "is-active", "--quiet", name), check=False).returncode == 0

    def activate(self, root: Path, release: Path):
        root.mkdir(parents=True, exist_ok=True)
        temporary = root / ".current.new"
        temporary.unlink(missing_ok=True)
        temporary.symlink_to(release)
        os.replace(temporary, root / "current")

    def active(self, root):
        current = root / "current"
        return current.resolve() if current.is_symlink() else None

    @staticmethod
    def platform_key():
        machine = os.uname().machine.lower().replace("amd64", "x86_64").replace("x64", "x86_64")
        return f"linux-{machine}"

    def launch_self_update(self, command):
        """Launch the handoff as a transient systemd unit, outside HU's cgroup."""
        suffix = hashlib.sha256("\0".join(command).encode()).hexdigest()[:12]
        unit = f"helix-updater-self-update-{suffix}"
        result = self.runner(("systemd-run", "--unit", unit, "--collect", "--service-type=oneshot", *command), check=False, capture_output=True, text=True)
        if result.returncode != 0:
            raise RuntimeError(f"systemd-run self-update handoff failed: {result.stderr.strip()}")
