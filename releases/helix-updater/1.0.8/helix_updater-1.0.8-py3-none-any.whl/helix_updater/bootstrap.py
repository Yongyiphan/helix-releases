from __future__ import annotations

import argparse
import json
from pathlib import Path
import time

from .platform.linux import LinuxPlatform
from .state import StateStore


def _load(path: Path) -> dict:
    value = json.loads(path.read_text(encoding="utf-8"))
    required = ("transaction_id", "candidate_version", "candidate_path", "previous_path", "service", "startup_ack_path")
    if not isinstance(value, dict) or value.get("component") != "helix-updater" or any(not isinstance(value.get(key), str) or not value[key] for key in required):
        raise RuntimeError("invalid HU self-update transaction")
    if value["service"] != "helix-updater.service":
        raise RuntimeError("self-update transaction names an unexpected service")
    return value


def _inside(path: Path, root: Path) -> bool:
    return path.resolve().is_relative_to(root.resolve())


def apply(path: Path) -> int:
    state = StateStore(path.parent)
    tx = _load(path)
    root = Path(tx["candidate_path"]).resolve().parent.parent
    candidate = Path(tx["candidate_path"]).resolve()
    previous = Path(tx["previous_path"]).resolve()
    if not _inside(candidate, root / "releases") or not _inside(previous, root / "releases"):
        raise RuntimeError("self-update path is outside HU release root")
    if not candidate.is_dir() or not previous.is_dir():
        raise RuntimeError("self-update release directory is unavailable")
    platform = LinuxPlatform()
    service = tx["service"]
    try:
        state.write_self_update({**tx, "state": "stopping_service"})
        platform.stop_service(service)
        state.write_self_update({**tx, "state": "activating"})
        platform.activate(root, candidate)
        state.write_self_update({**tx, "state": "starting_service"})
        platform.start_service(service)
        state.write_self_update({**tx, "state": "awaiting_health"})
        ack_path = Path(tx["startup_ack_path"])
        deadline = time.monotonic() + 60
        while time.monotonic() < deadline:
            if ack_path.exists():
                try:
                    ack = json.loads(ack_path.read_text(encoding="utf-8"))
                except (OSError, json.JSONDecodeError):
                    ack = {}
                if ack.get("transaction_id") == tx["transaction_id"] and ack.get("version") == tx["candidate_version"] and ack.get("status") == "ready":
                    state.write_self_update({**tx, "state": "successful", "current_version": tx["candidate_version"]})
                    state.write("helix-updater", {"state": "successful", "current": tx["candidate_version"], "current_path": str(candidate), "previous": tx.get("current_version"), "previous_path": str(previous), "failed_releases": []})
                    return 0
            time.sleep(0.5)
        raise RuntimeError("new HU did not acknowledge startup")
    except Exception as exc:
        failed = {"version": tx["candidate_version"], "artifact_sha256": tx.get("artifact_sha256"), "reason": str(exc)}
        try:
            state.write_self_update({**tx, "state": "rolling_back", "error": str(exc), "failed_release": failed})
            platform.stop_service(service)
            platform.activate(root, previous)
            platform.start_service(service)
            state.write_self_update({**tx, "state": "rolled_back", "error": str(exc), "failed_release": failed})
            package_state = state.read("helix-updater")
            failed_releases = list(package_state.get("failed_releases", []))
            if not any(
                isinstance(item, dict)
                and item.get("version") == failed["version"]
                and item.get("artifact_sha256") == failed["artifact_sha256"]
                for item in failed_releases
            ):
                failed_releases.append(failed)
            state.write("helix-updater", {**package_state, "state": "rolled_back", "current": tx.get("current_version"), "current_path": str(previous), "candidate": tx["candidate_version"], "failed_releases": failed_releases})
            return 1
        except Exception as recovery:
            state.write_self_update({**tx, "state": "failed", "error": f"{exc}; rollback failed: {recovery}", "failed_release": failed})
            return 2


def main(argv=None):
    parser = argparse.ArgumentParser(prog="helix-updater-bootstrap")
    parser.add_argument("--state", type=Path, required=True)
    args = parser.parse_args(argv)
    return apply(args.state)


if __name__ == "__main__":
    raise SystemExit(main())
