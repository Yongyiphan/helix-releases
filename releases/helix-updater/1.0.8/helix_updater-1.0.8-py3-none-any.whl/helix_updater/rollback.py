from __future__ import annotations

from pathlib import Path

from .health import check_health
from .registry import PackageSubscription
from .state import StateStore


def rollback(package: PackageSubscription, state: StateStore, platform) -> Path:
    item = state.read(package.package_id)
    previous = item.get("previous")
    if not previous:
        raise RuntimeError(f"no previous release recorded for {package.package_id}")
    previous_path = Path(item.get("previous_path") or previous)
    if not previous_path.is_dir():
        raise RuntimeError(f"previous release is unavailable: {previous_path}")
    current = platform.active(package.target.root)
    platform.stop_service(package.target.service)
    try:
        platform.activate(package.target.root, previous_path)
        platform.start_service(package.target.service)
        check_health(platform, package.target.service, {"type": "service"})
    except Exception:
        if current:
            platform.activate(package.target.root, current)
            platform.start_service(package.target.service)
        raise
    state.write(package.package_id, {"state": "successful", "current": previous, "current_path": str(previous_path), "previous": item.get("current"), "previous_path": str(current) if current else None})
    return previous_path
