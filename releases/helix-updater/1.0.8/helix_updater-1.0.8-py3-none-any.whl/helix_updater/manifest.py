from __future__ import annotations

from dataclasses import dataclass
import json
import re
from typing import Any


class ManifestError(ValueError):
    pass


@dataclass(frozen=True)
class Artifact:
    file: str
    sha256: str


@dataclass(frozen=True)
class InstallSpec:
    strategy: str = "file"
    component: str | None = None


@dataclass(frozen=True)
class ReleaseManifest:
    schema: int
    package: str
    version: str
    channel: str
    commit: str
    published_at: str
    artifacts: dict[str, Artifact]
    updater_requirement: str | None
    healthcheck: dict[str, Any]
    rollback_supported: bool
    install: InstallSpec

    @classmethod
    def from_bytes(cls, raw: bytes | str, *, supported_schema: int = 1) -> "ReleaseManifest":
        try:
            value = json.loads(raw)
        except (TypeError, json.JSONDecodeError) as exc:
            raise ManifestError("release manifest is not valid JSON") from exc
        if not isinstance(value, dict):
            raise ManifestError("release manifest must be an object")
        if value.get("schema") != supported_schema:
            raise ManifestError(f"unsupported release manifest schema: {value.get('schema')!r}")
        required = ("package", "version", "channel", "commit", "published_at", "artifacts")
        if any(not isinstance(value.get(key), str) or not value[key].strip() for key in required[:-1]):
            raise ManifestError("manifest identity fields must be non-empty strings")
        package = value["package"].strip()
        version = value["version"].strip()
        if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.+-]*", package):
            raise ManifestError(f"invalid package ID: {package!r}")
        if not re.fullmatch(r"[0-9A-Za-z][0-9A-Za-z_.+-]*", version):
            raise ManifestError(f"invalid release version: {version!r}")
        artifacts_raw = value.get("artifacts")
        if not isinstance(artifacts_raw, dict) or not artifacts_raw:
            raise ManifestError("manifest artifacts must be a non-empty object")
        artifacts: dict[str, Artifact] = {}
        for platform, item in artifacts_raw.items():
            if not isinstance(platform, str) or not isinstance(item, dict):
                raise ManifestError("manifest artifact entries are invalid")
            filename, digest = item.get("file"), item.get("sha256")
            if not isinstance(filename, str) or not filename or filename in {".", ".."} or "/" in filename or "\\" in filename:
                raise ManifestError(f"invalid artifact filename for {platform}")
            if not isinstance(digest, str) or not re.fullmatch(r"[0-9a-fA-F]{64}", digest):
                raise ManifestError(f"invalid SHA-256 for {platform}")
            artifacts[platform] = Artifact(filename, digest.lower())
        requirements = value.get("requirements", {})
        if not isinstance(requirements, dict) or (requirements and not isinstance(requirements.get("updater"), str)):
            raise ManifestError("manifest requirements are invalid")
        healthcheck = value.get("healthcheck", {})
        if not isinstance(healthcheck, dict):
            raise ManifestError("manifest healthcheck must be an object")
        rollback = value.get("rollback", {})
        if not isinstance(rollback, dict) or not isinstance(rollback.get("supported", True), bool):
            raise ManifestError("manifest rollback is invalid")
        install = value.get("install", {})
        if not isinstance(install, dict) or install.get("strategy", "file") not in {"file", "archive", "python_wheel"}:
            raise ManifestError("unsupported install strategy")
        component = install.get("component")
        if component is not None and not isinstance(component, str):
            raise ManifestError("install component must be a string")
        return cls(value["schema"], package, version, value["channel"].strip(), value["commit"].strip(),
                   value["published_at"].strip(), artifacts, requirements.get("updater"), healthcheck,
                   rollback.get("supported", True), InstallSpec(install.get("strategy", "file"), component))

    def artifact_for(self, platform: str) -> Artifact:
        candidates = (platform, f"{platform.split('-', 1)[0]}-any", "any")
        for candidate in candidates:
            if candidate in self.artifacts:
                return self.artifacts[candidate]
        raise ManifestError(f"release has no artifact for platform {platform}")
