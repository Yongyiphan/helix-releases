from __future__ import annotations

from urllib.request import urlopen


def check_health(adapter, service: str | None, specification: dict) -> None:
    check_type = specification.get("type", "service")
    if check_type == "service":
        if not adapter.service_running(service):
            raise RuntimeError("service health check failed")
        return
    if check_type == "http":
        url = specification.get("url")
        if not isinstance(url, str) or not url.startswith(("http://", "https://")):
            raise ValueError("HTTP health check requires an HTTP URL")
        with urlopen(url, timeout=float(specification.get("timeout_seconds", 30))):
            return
    raise ValueError(f"unsupported health check type: {check_type}")
