from __future__ import annotations

from pathlib import Path
import threading

from .health import check_health
from .manifest import ReleaseManifest
from .registry import PackageSubscription
from .staging import prune_release_runtimes, stage_artifact
from .state import StateStore
from .verifier import verify_artifact


class PackageInstaller:
    def __init__(self, state: StateStore, platform):
        self.state, self.platform = state, platform
        self._locks: dict[str, threading.Lock] = {}
        self._guard = threading.Lock()

    def install(self, subscription: PackageSubscription, manifest: ReleaseManifest, artifact: Path) -> Path:
        if manifest.package != subscription.package_id:
            raise ValueError(f"manifest package {manifest.package!r} does not match requested package {subscription.package_id!r}")
        with self._guard:
            lock = self._locks.setdefault(subscription.package_id, threading.Lock())
        with lock:
            current = self.platform.active(subscription.target.root)
            store = self.state
            prior = store.read(subscription.package_id)
            current_version = prior.get("current")
            if isinstance(current_version, str) and current_version.startswith("/"):
                current_version = prior.get("current_version")
            snapshot = {"current": current_version, "current_path": str(current) if current else None}
            store.write(subscription.package_id, {**snapshot, "state": "verifying", "candidate": manifest.version})
            verify_artifact(artifact, manifest.artifact_for(self._platform_key()))
            release = stage_artifact(artifact, subscription.target.root, manifest.version, manifest.install.strategy)
            store.write(subscription.package_id, {**snapshot, "state": "staged", "candidate": manifest.version, "staged": str(release)})
            try:
                store.write(subscription.package_id, {**snapshot, "state": "stopping_service", "candidate": manifest.version, "staged": str(release)})
                self.platform.stop_service(subscription.target.service)
                store.write(subscription.package_id, {**snapshot, "state": "activating", "candidate": manifest.version, "staged": str(release)})
                self.platform.activate(subscription.target.root, release)
                store.write(subscription.package_id, {**snapshot, "state": "starting_service", "candidate": manifest.version, "staged": str(release)})
                self.platform.start_service(subscription.target.service)
                store.write(subscription.package_id, {**snapshot, "state": "health_checking", "candidate": manifest.version, "staged": str(release)})
                check_health(self.platform, subscription.target.service, manifest.healthcheck)
            except Exception as exc:
                failed = store.read(subscription.package_id).get("failed_releases", [])
                failed = [*failed, {"version": manifest.version, "artifact_sha256": manifest.artifact_for(self._platform_key()).sha256, "reason": str(exc)}]
                store.write(subscription.package_id, {**snapshot, "state": "rolling_back", "candidate": manifest.version, "failed_releases": failed})
                try:
                    if current:
                        self.platform.stop_service(subscription.target.service)
                        self.platform.activate(subscription.target.root, current)
                        self.platform.start_service(subscription.target.service)
                        check_health(self.platform, subscription.target.service, {"type": "service"})
                    store.write(subscription.package_id, {**snapshot, "state": "rolled_back", "failed_releases": failed})
                except Exception as recovery:
                    store.write(subscription.package_id, {**snapshot, "state": "failed", "candidate": manifest.version, "failed_releases": failed, "error": f"{exc}; rollback failed: {recovery}"})
                    raise RuntimeError(f"update failed and rollback failed: {exc}; {recovery}") from exc
                raise RuntimeError(f"update failed and was rolled back: {exc}") from exc
            store.write(subscription.package_id, {"state": "successful", "current": manifest.version, "current_path": str(release), "previous": current_version, "previous_path": str(current) if current else None, "failed_releases": store.read(subscription.package_id).get("failed_releases", [])})
            keep_versions = {manifest.version}
            if isinstance(current_version, str) and current_version:
                keep_versions.add(current_version)
            elif current is not None and current.parent.name == "releases":
                # Adoption or legacy state may not have recorded the version
                # string yet. Never prune the path that was just replaced.
                keep_versions.add(current.name)
            prune_release_runtimes(subscription.target.root, keep_versions)
            return release

    @staticmethod
    def _platform_key(platform=None):
        if platform is not None and hasattr(platform, "platform_key"):
            return platform.platform_key()
        from .release_source import GitHubReleaseSource
        return GitHubReleaseSource.platform_key()
