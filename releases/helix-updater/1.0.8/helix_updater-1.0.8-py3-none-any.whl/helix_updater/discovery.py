from __future__ import annotations

from dataclasses import asdict, dataclass
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import subprocess
import tomllib
from typing import Any

from .registry import Registry


@dataclass(frozen=True)
class RepositoryObservation:
    package: str
    local_path: str
    repository: str
    config_files: tuple[str, ...]
    development_paths: tuple[str, ...]
    production_paths: tuple[str, ...]
    services: tuple[str, ...]
    observed_at: str

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


class DiscoveryError(RuntimeError):
    pass


class RepositoryDiscovery:
    """Bounded, read-only discovery of locally checked-out Helix repositories."""

    def __init__(self, registry: Registry, *, runner=subprocess.run):
        self.registry = registry
        self.runner = runner

    def scan(self) -> list[RepositoryObservation]:
        observations: dict[tuple[str, str], RepositoryObservation] = {}
        for root in self.registry.discovery.roots:
            if not root.exists() or not root.is_dir():
                continue
            for git_marker in self._git_markers(root):
                repo_path = git_marker.parent
                remote = self._remote(repo_path)
                if not remote or not self._allowed(remote):
                    continue
                package = self.registry.package_for_repository(remote)
                if not package:
                    package = self._infer_package(remote)
                if not package:
                    continue
                observation = self._observe(repo_path, package, remote)
                observations[(package, observation.local_path)] = observation
        return sorted(observations.values(), key=lambda item: (item.package, item.local_path))

    def _git_markers(self, root: Path):
        # Do not walk generated runtimes, caches, or arbitrary nested dependency trees.
        ignored = {".venv", "venv", "node_modules", "__pycache__", "build", "dist", "releases", "workspaces", "graphify-out"}
        for current, directories, files in os.walk(root, followlinks=False):
            current_path = Path(current)
            directories[:] = [name for name in directories if name not in ignored]
            marker = current_path / ".git"
            if marker.is_dir() or marker.is_file():
                yield marker
                # A configured root may itself be a repository while also being
                # a workspace containing sibling repositories.
                if current_path != root:
                    directories[:] = []

    def _remote(self, path: Path) -> str | None:
        result = self.runner(("git", "-C", str(path), "config", "--get", "remote.origin.url"), check=False, capture_output=True, text=True)
        if result.returncode != 0:
            return None
        return canonical_repository(result.stdout.strip())

    def _allowed(self, repository: str) -> bool:
        owners = self.registry.discovery.allowed_owners
        return not owners or repository.split("/", 1)[0].lower() in owners

    def _infer_package(self, repository: str) -> str | None:
        owner, name = repository.split("/", 1)
        if repository in self.registry.discovery.repositories:
            return self.registry.discovery.repositories[repository]
        if name in {"helix-updater", "helix-core", "helix-endpoint", "hdc"}:
            return name
        if name == "helix-development":
            return "hdc"
        return None

    def _observe(self, path: Path, package: str, repository: str) -> RepositoryObservation:
        config_files: list[str] = []
        development_paths: set[str] = {str(path.resolve())}
        production_paths: set[str] = set()
        services: set[str] = set()
        for candidate in sorted(path.glob("*.toml")):
            try:
                raw = tomllib.loads(candidate.read_text(encoding="utf-8"))
            except (OSError, tomllib.TOMLDecodeError):
                continue
            config_files.append(str(candidate.resolve()))
            _collect_values(raw, development_paths, production_paths, services)
        return RepositoryObservation(package, str(path.resolve()), repository, tuple(config_files), tuple(sorted(development_paths)), tuple(sorted(production_paths)), tuple(sorted(services)), datetime.now(timezone.utc).isoformat())


def canonical_repository(value: str) -> str | None:
    value = value.strip()
    if value.endswith(".git"):
        value = value[:-4]
    if value.startswith("git@") and ":" in value:
        value = value.split(":", 1)[1]
    elif "://" in value:
        value = value.split("://", 1)[1].split("/", 1)[1] if "/" in value.split("://", 1)[1] else ""
    value = value.strip("/")
    parts = value.split("/")
    if len(parts) != 2 or not all(parts):
        return None
    return "/".join(parts).lower()


def _collect_values(value: Any, development: set[str], production: set[str], services: set[str], context: tuple[str, ...] = ()) -> None:
    if isinstance(value, dict):
        for key, child in value.items():
            key_lower = str(key).lower()
            next_context = context + (key_lower,)
            if isinstance(child, str):
                if any(token in key_lower for token in ("service", "unit")) or "service" in context or "systemd" in context or "scm" in context:
                    services.add(child)
                if any(token in key_lower for token in ("production", "deployment", "install", "runtime")) or key_lower in {"application_root", "root"} and any(token in context for token in ("deployment", "production", "runtime")):
                    production.add(child)
                if key_lower in {"path", "workspace_root", "application_root"} and not child.startswith(("/opt/", "c:\\", "C:\\")):
                    development.add(child)
            else:
                _collect_values(child, development, production, services, next_context)
    elif isinstance(value, list):
        for child in value:
            _collect_values(child, development, production, services, context)


def write_inventory(path: Path, observations: list[RepositoryObservation]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = {"schema": 1, "updated_at": datetime.now(timezone.utc).isoformat(), "repositories": {item.package: item.as_dict() for item in observations}}
    temporary = path.with_suffix(path.suffix + ".new")
    temporary.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    temporary.replace(path)


def read_inventory(path: Path) -> dict[str, Any]:
    if not path.exists():
        return {"schema": 1, "repositories": {}}
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict) or value.get("schema") != 1 or not isinstance(value.get("repositories"), dict):
        raise DiscoveryError(f"invalid discovery inventory: {path}")
    return value
