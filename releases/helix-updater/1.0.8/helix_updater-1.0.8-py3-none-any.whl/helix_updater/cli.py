from __future__ import annotations

import argparse
from pathlib import Path
import os
import random
import time

from . import __version__
from .discovery import RepositoryDiscovery, read_inventory, write_inventory
from .registry import Registry
from .release_source import GitHubReleaseSource
from .state import StateStore
from .updater import Updater
from .rollback import rollback
from .self_update import SelfUpdateRequested, acknowledge_startup


def _registry(path):
    return Registry.from_file(path or os.getenv("HELIX_UPDATER_CONFIG", "helix-updater.toml"))


def main(argv=None, *, stop_event=None):
    parser = argparse.ArgumentParser(prog="helix-updater")
    parser.add_argument("--config", type=Path)
    parser.add_argument(
        "--version",
        dest="installed_version",
        nargs="?",
        const="__show_version__",
        help="show HU version, or provide the installed version for adopt",
    )
    parser.add_argument("--once", action="store_true", help="For serve, perform one polling pass and exit")
    parser.add_argument("command", choices=("packages", "status", "discover", "inventory", "check", "update", "rollback", "adopt", "serve"), nargs="?", default="status")
    parser.add_argument("package", nargs="?")
    args = parser.parse_args(argv)
    if args.installed_version == "__show_version__":
        print(__version__)
        return 0
    registry = _registry(args.config)
    state = StateStore(registry.state_root)
    acknowledge_startup(state, __version__)
    updater = Updater(registry)
    if args.command == "discover":
        observations = RepositoryDiscovery(registry).scan()
        write_inventory(state.inventory_path, observations)
        for item in observations:
            production = ",".join(item.production_paths) or "unknown"
            print(f"{item.package}: {item.repository} local={item.local_path} production={production}")
        if not observations:
            print("No local Helix repositories discovered.")
        return 0
    if args.command == "inventory":
        inventory = read_inventory(state.inventory_path)
        for package, item in sorted(inventory.get("repositories", {}).items()):
            print(f"{package}: {item.get('repository')} local={item.get('local_path')} production={','.join(item.get('production_paths', [])) or 'unknown'}")
        return 0
    if args.command == "serve":
        while True:
            observations = RepositoryDiscovery(registry).scan()
            write_inventory(state.inventory_path, observations)
            for package in updater.subscriptions():
                try:
                    release = updater.update(package)
                    item = state.read(package.package_id)
                    result = "updated" if release else ("no_release_available" if item.get("state") == "no_release_available" else "current")
                    print(f"{package.package_id}: {result}", flush=True)
                except SelfUpdateRequested:
                    return 0
                except Exception as exc:
                    print(f"{package.package_id}: update failed: {exc}", flush=True)
            if args.once:
                return 0
            delay = 300 + random.uniform(0, 30)
            if stop_event is not None:
                if stop_event.wait(delay):
                    return 0
            else:
                time.sleep(delay)
    if args.command == "packages":
        for package in registry.packages.values():
            if package.enabled:
                print(f"{package.package_id}\t{package.source.repository}\t{package.channel}\t{package.target.root}")
        return 0
    if args.command == "status":
        print(f"Helix Updater {__version__}")
        inventory = read_inventory(state.inventory_path)
        print(f"Discovered repositories: {len(inventory.get('repositories', {}))}")
        for package in registry.packages.values():
            if args.package and package.package_id != args.package: continue
            if not package.enabled: continue
            item = state.read(package.package_id)
            print(f"{package.package_id}: state={item.get('state')} current={item.get('current', 'unknown')} source={package.source.repository} channel={package.channel}")
        return 0
    for package in updater.subscriptions(args.package):
        if args.command == "check":
            release, needed = updater.check(package)
            if release is None:
                print(f"{package.package_id}: no_release_available")
            else:
                print(f"{package.package_id}: {release.manifest.version} ({'update_available' if needed else 'current'})")
        elif args.command == "update":
            release = updater.update(package)
            print(f"{package.package_id}: {'updated' if release else 'current'}")
        elif args.command == "rollback":
            print(f"{package.package_id}: rolled back to {rollback(package, state, updater.installer.platform)}")
        elif args.command == "adopt":
            if not args.installed_version:
                raise SystemExit("adopt requires --version")
            print(f"{package.package_id}: adopted {updater.adopt(package, args.installed_version)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
