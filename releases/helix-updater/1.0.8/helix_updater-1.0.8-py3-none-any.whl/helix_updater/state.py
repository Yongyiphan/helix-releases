from __future__ import annotations

from datetime import datetime, timezone
import json
from pathlib import Path
from typing import Any


TRANSACTION_STATES = {"not_started", "discovering", "downloading", "verifying", "staged", "stopping_service", "activating", "starting_service", "health_checking", "self_update_prepared", "helper_launched", "awaiting_health", "successful", "no_release_available", "rolling_back", "rolled_back", "failed"}


class StateStore:
    def __init__(self, root: Path | str):
        self.root = Path(root)

    def path(self, package_id: str) -> Path:
        if not package_id or "/" in package_id or "\\" in package_id:
            raise ValueError("invalid package ID")
        return self.root / "packages" / f"{package_id}.json"

    @property
    def inventory_path(self) -> Path:
        return self.root / "discovery.json"

    @property
    def self_update_path(self) -> Path:
        return self.root / "self-update.json"

    def read(self, package_id: str) -> dict[str, Any]:
        path = self.path(package_id)
        if not path.exists():
            return {"package": package_id, "state": "not_started", "failed_releases": []}
        value = json.loads(path.read_text(encoding="utf-8"))
        if not isinstance(value, dict) or value.get("package") != package_id:
            raise ValueError(f"invalid state for {package_id}")
        return value

    def write(self, package_id: str, value: dict[str, Any]) -> None:
        state = dict(value, package=package_id, updated_at=datetime.now(timezone.utc).isoformat())
        if state.get("state") not in TRANSACTION_STATES:
            raise ValueError(f"invalid transaction state: {state.get('state')}")
        path = self.path(package_id)
        path.parent.mkdir(parents=True, exist_ok=True)
        temporary = path.with_suffix(".json.new")
        temporary.write_text(json.dumps(state, sort_keys=True, indent=2) + "\n", encoding="utf-8")
        temporary.replace(path)

    def read_self_update(self) -> dict[str, Any] | None:
        if not self.self_update_path.exists():
            return None
        value = json.loads(self.self_update_path.read_text(encoding="utf-8"))
        if not isinstance(value, dict):
            raise ValueError("invalid HU self-update state")
        return value

    def write_self_update(self, value: dict[str, Any]) -> None:
        state = dict(value, updated_at=datetime.now(timezone.utc).isoformat())
        if state.get("state") not in TRANSACTION_STATES:
            raise ValueError(f"invalid self-update state: {state.get('state')}")
        self.root.mkdir(parents=True, exist_ok=True)
        temporary = self.self_update_path.with_suffix(".json.new")
        temporary.write_text(json.dumps(state, sort_keys=True, indent=2) + "\n", encoding="utf-8")
        temporary.replace(self.self_update_path)
