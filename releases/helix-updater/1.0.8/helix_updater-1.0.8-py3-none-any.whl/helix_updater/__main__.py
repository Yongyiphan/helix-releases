"""Module entry point for ``python -m helix_updater``."""

from .cli import main


if __name__ == "__main__":
    raise SystemExit(main())
