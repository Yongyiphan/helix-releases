from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import tomllib
from typing import Any


class RegistryError(ValueError):
    pass


@dataclass(frozen=True)
class SourceConfig:
    type: str
    repository: str


@dataclass(frozen=True)
class TargetConfig:
    component: str
    root: Path
    service: str | None


@dataclass(frozen=True)
class DiscoveryConfig:
    roots: tuple[Path, ...]
    allowed_owners: tuple[str, ...]
    repositories: dict[str, str]


@dataclass(frozen=True)
class PackageSubscription:
    package_id: str
    enabled: bool
    channel: str
    source: SourceConfig
    target: TargetConfig


@dataclass(frozen=True)
class Registry:
    updater_version: str
    state_root: Path
    download_root: Path
    packages: dict[str, PackageSubscription]
    discovery: DiscoveryConfig
    gh_config_dir: Path | None = None
    # All replaceable Helix runtimes may share one permission boundary.  Keep
    # this optional for backwards compatibility with older HU configurations.
    helix_root: Path | None = None

    @classmethod
    def from_file(cls, path: Path | str) -> "Registry":
        try:
            raw = tomllib.loads(Path(path).read_text(encoding="utf-8"))
        except (OSError, tomllib.TOMLDecodeError) as exc:
            raise RegistryError(f"cannot read updater configuration: {path}") from exc
        packages_raw = raw.get("packages", {})
        if not isinstance(packages_raw, dict):
            raise RegistryError("packages must be a table")
        packages: dict[str, PackageSubscription] = {}
        for package_id, item in packages_raw.items():
            if not isinstance(package_id, str) or not isinstance(item, dict):
                raise RegistryError("package subscriptions are invalid")
            source, target = item.get("source"), item.get("target")
            source_type = source.get("type") if isinstance(source, dict) else None
            if not isinstance(source, dict) or source_type not in {"github", "catalog", "public"} or not isinstance(source.get("repository"), str) or (source_type in {"github", "public"} and source["repository"].count("/") != 1):
                raise RegistryError(f"invalid GitHub source for {package_id}")
            if not isinstance(target, dict) or not isinstance(target.get("component"), str) or not isinstance(target.get("root"), str):
                raise RegistryError(f"invalid target for {package_id}")
            enabled = item.get("enabled", True)
            channel = item.get("channel", "stable")
            if not isinstance(enabled, bool) or not isinstance(channel, str) or not channel.strip():
                raise RegistryError(f"invalid subscription settings for {package_id}")
            target_root = _target_root(target["root"], raw.get("helix_root"), package_id)
            packages[package_id] = PackageSubscription(package_id, enabled, channel.strip(),
                SourceConfig(str(source["type"]), source["repository"].strip()),
                TargetConfig(target["component"].strip(), target_root, target.get("service")))
        updater_version = raw.get("updater_version", "0.1.0")
        state_root = raw.get("state_root", "state")
        download_root = raw.get("download_root", "downloads")
        gh_config_dir = raw.get("gh_config_dir")
        helix_root = raw.get("helix_root")
        if not isinstance(updater_version, str) or not isinstance(state_root, str) or not isinstance(download_root, str) or (gh_config_dir is not None and not isinstance(gh_config_dir, str)) or (helix_root is not None and not isinstance(helix_root, str)):
            raise RegistryError("updater_version, state_root, download_root, and helix_root must be strings; gh_config_dir must be a path")
        discovery_raw = raw.get("discovery", {})
        if not isinstance(discovery_raw, dict):
            raise RegistryError("discovery must be a table")
        roots_raw = discovery_raw.get("roots", [])
        owners_raw = discovery_raw.get("allowed_owners", [])
        if not isinstance(roots_raw, list) or any(not isinstance(item, str) or not item.strip() for item in roots_raw):
            raise RegistryError("discovery.roots must be a list of paths")
        if not isinstance(owners_raw, list) or any(not isinstance(item, str) or not item.strip() for item in owners_raw):
            raise RegistryError("discovery.allowed_owners must be a list of owners")
        repo_raw = discovery_raw.get("repositories", {})
        if not isinstance(repo_raw, dict):
            raise RegistryError("discovery.repositories must be a table")
        repositories: dict[str, str] = {}
        for repository, package in repo_raw.items():
            if not isinstance(repository, str) or repository.count("/") != 1 or not isinstance(package, str) or not package.strip():
                raise RegistryError("discovery repository mappings are invalid")
            repositories[repository.strip().lower()] = package.strip()
        discovery = DiscoveryConfig(
            tuple(Path(item).expanduser() for item in roots_raw),
            tuple(item.strip().lower() for item in owners_raw),
            repositories,
        )
        return cls(
            updater_version,
            Path(state_root).expanduser(),
            Path(download_root).expanduser(),
            packages,
            discovery,
            Path(gh_config_dir).expanduser() if gh_config_dir else None,
            Path(helix_root).expanduser().resolve() if helix_root else None,
        )

    def package_for_repository(self, repository: str) -> str | None:
        return self.discovery.repositories.get(repository.strip().lower())

    def as_toml(self) -> str:
        """Serialize the small, intentionally boring HU configuration format."""
        lines = [
            f'updater_version = "{_toml_string(self.updater_version)}"',
            f'state_root = "{_toml_string(str(self.state_root))}"',
            f'download_root = "{_toml_string(str(self.download_root))}"',
            *([f'helix_root = "{_toml_string(str(self.helix_root))}"'] if self.helix_root else []),
            *([f'gh_config_dir = "{_toml_string(str(self.gh_config_dir))}"'] if self.gh_config_dir else []),
            "",
            "[discovery]",
            "roots = [" + ", ".join(f'"{_toml_string(str(root))}"' for root in self.discovery.roots) + "]",
            "allowed_owners = [" + ", ".join(f'"{_toml_string(owner)}"' for owner in self.discovery.allowed_owners) + "]",
            "",
            "[discovery.repositories]",
        ]
        for repository, package in sorted(self.discovery.repositories.items()):
            lines.append(f'"{_toml_string(repository)}" = "{_toml_string(package)}"')
        for package in self.packages.values():
            lines.extend([
                f'\n[packages."{_toml_string(package.package_id)}"]',
                f"enabled = {str(package.enabled).lower()}",
                f'channel = "{_toml_string(package.channel)}"',
                "",
                f'[packages."{_toml_string(package.package_id)}".source]',
                f'type = "{_toml_string(package.source.type)}"',
                f'repository = "{_toml_string(package.source.repository)}"',
                "",
                f'[packages."{_toml_string(package.package_id)}".target]',
                f'component = "{_toml_string(package.target.component)}"',
                f'root = "{_toml_string(str(package.target.root))}"',
            ])
            if package.target.service:
                lines.append(f'service = "{_toml_string(package.target.service)}"')
        return "\n".join(lines) + "\n"


def _toml_string(value: str) -> str:
    return value.replace("\\", "\\\\").replace('"', '\\"')


def _target_root(value: str, configured_root: Any, package_id: str) -> Path:
    """Resolve a package target and enforce the shared Helix boundary."""
    target = Path(value).expanduser()
    if configured_root is None:
        return target
    if not isinstance(configured_root, str) or not configured_root.strip():
        raise RegistryError("helix_root must be a non-empty path")
    boundary = Path(configured_root).expanduser().resolve()
    resolved = (boundary / target if not target.is_absolute() else target).resolve()
    if resolved == boundary or not resolved.is_relative_to(boundary):
        raise RegistryError(f"target for {package_id} must be inside helix_root: {resolved}")
    return resolved
