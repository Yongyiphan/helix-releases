"""HDC command-line interface."""

import os
from dataclasses import replace
import json
from pathlib import Path
import shutil
import sys
import time
import typer

from .adapters import CodexAdapter, GitAdapter, GraphifyAdapter, HermesAdapter
from .config import Config, ConfigError, initialize_config, load_config
from .execution_plan import build_execution_plan
from .task_packets import IssueReference, TaskPacketError, list_task_packets
from .workspaces import WorkspaceError, WorkspaceManager
from .run_records import RunStore
from .workflow import WorkflowError, start_run
from .reports import render_acceptance_report
from .lifecycle import TaskStateStore
from .worker_loop import run_ready_tasks
from .architect import ArchitectRequest, HermesArchitect
from .design import DesignError, run_design
from .design_context import DesignContextBuilder
from .design_sessions import DesignSessionStore
from .paths import controller_root, design_root, local_state_root, runs_root, task_state_root
from .service import service_descriptor_suffix, write_service_descriptor
from .diagnostics import write_config_error
from .packaging import PackagingError, build_wheel
from .process import CommandRunner
from .github import GitHubAdapter, GitHubError, GitHubIssue
from .reconciliation import reconcile_packets
from .coordinated_worker import run_coordinated_cycle
from .github_coordination import GitHubCoordinationBackend
from .reviewers import HermesReviewer
from .backlog_decision import HermesIssueSelector, WorkerAvailability, build_candidates, decide_next_issue
from .backlog_store import BacklogStore
from .backlog_automation import materialize_selected_issue
from .feature_workflow import FeatureWorkflow, FeatureWorkflowStore
from .release_workflow import (
    ReleaseStore,
    ReleaseWorkflowError,
    build_handoff,
    collect_diagnostics,
    create_release_request,
    finish_observation,
    record_hotfix,
    require_human,
    start_reinvestigation,
)
from .polling import BacklogPoller
from .heartbeat import ControllerRegistry, GitHubHeartbeatBackend, HeartbeatServer, WorkerHeartbeat, register_with_seed, request_heartbeat, send_heartbeat
from .controller_runtime import ControllerRuntime, RuntimeErrorState, read_runtime_status, stop_runtime
from .peer import PeerContextRequest, build_peer_context, request_peer_context
from . import __version__

app = typer.Typer(help="Helix Development Cycle foundation")
config_app = typer.Typer(help="Inspect HDC configuration")
repo_app = typer.Typer(help="Inspect configured repositories")
graph_app = typer.Typer(help="Inspect Graphify outputs")
task_app = typer.Typer(help="Inspect deterministic task packets")
workspace_app = typer.Typer(help="Manage isolated HDC workspaces")
run_app = typer.Typer(help="Inspect durable HDC runs")
worker_app = typer.Typer(help="Run the foreground HDC worker")
controller_app = typer.Typer(help="Run and inspect the HDC Controller")
issue_app = typer.Typer(help="Inspect GitHub issues without authorizing work")
backlog_app = typer.Typer(help="Inspect persisted backlog context and decisions")
release_app = typer.Typer(help="Prepare and coordinate reproducible component releases")
app.add_typer(config_app, name="config")
app.add_typer(repo_app, name="repo")
app.add_typer(graph_app, name="graph")
app.add_typer(task_app, name="task")
app.add_typer(workspace_app, name="workspace")
app.add_typer(run_app, name="run")
app.add_typer(worker_app, name="worker")
app.add_typer(controller_app, name="controller")
app.add_typer(issue_app, name="issue")
app.add_typer(backlog_app, name="backlog")
app.add_typer(release_app, name="release")


@app.callback()
def main(
    config: Path | None = typer.Option(None, "--config", help="Configuration file for this invocation."),
    state_root: Path | None = typer.Option(None, "--state-root", help="Persistent state root for this invocation."),
    audit_log: Path | None = typer.Option(None, "--audit-log", help="JSONL external-command audit path for this invocation."),
) -> None:
    """Configure an HDC command without requiring shell environment exports."""
    if config is not None:
        os.environ["HDC_CONFIG"] = str(config)
    if state_root is not None:
        os.environ["HDC_STATE_ROOT"] = str(state_root)
    if audit_log is not None:
        os.environ["HDC_AUDIT_LOG"] = str(audit_log)


@app.command("version")
def version() -> None:
    """Show the installed HDC release version."""
    typer.echo(__version__)


@app.command("init")
def init_config() -> None:
    """Generate the single local hdc.toml and persistent controller.id."""
    path = __import__("pathlib").Path.cwd() / "hdc.toml"
    try:
        target, identity, changed = initialize_config(path)
        typer.echo(f"{'INITIALIZED' if changed else 'VALIDATED'} {target}")
        typer.echo(f"CONTROLLER ID {identity}")
    except ConfigError as exc:
        typer.echo(f"INIT ERROR: {exc}", err=True)
        raise typer.Exit(1)


@app.command("package")
def package(output: Path = typer.Option(Path("dist"), "--output", "-o", help="Directory for the wheel artifact.")) -> None:
    """Build a versioned wheel from the development checkout."""
    try:
        for artifact in build_wheel(output):
            typer.echo(f"BUILT {artifact}")
    except PackagingError as exc:
        typer.echo(f"PACKAGE ERROR: {exc}", err=True)
        raise typer.Exit(1)


@release_app.command("request")
def release_request(
    component: str = typer.Argument(..., help="Configured component/repository to release."),
    version: str | None = typer.Option(None, "--version", help="Release version; defaults to static project.version."),
    channel: str = typer.Option("dev", "--channel"),
) -> None:
    """Lock one component and create a durable HR build request."""
    try:
        request = create_release_request(_config(), component, version=version, channel=channel)
    except (ConfigError, ReleaseWorkflowError) as exc:
        typer.echo(f"RELEASE REQUEST ERROR: {exc}", err=True)
        raise typer.Exit(1)
    typer.echo(json.dumps(request.to_dict(), indent=2, sort_keys=True))


@release_app.command("handoff")
def release_handoff(
    request_id: str = typer.Argument(...),
    hermes_validated: bool = typer.Option(False, "--hermes-validated", help="Assert that Hermes completed contract validation."),
) -> None:
    """Create the complete HR handoff after deterministic and Hermes validation."""
    try:
        config = _config()
        request = ReleaseStore.for_config(config).load_request(request_id)
        handoff = build_handoff(config, request, hermes_validated=hermes_validated)
    except (ConfigError, ReleaseWorkflowError) as exc:
        typer.echo(f"RELEASE HANDOFF ERROR: {exc}", err=True)
        raise typer.Exit(1)
    typer.echo(json.dumps(handoff.to_dict(), indent=2, sort_keys=True))


@release_app.command("publish")
def release_publish(
    component: str = typer.Argument(...),
    catalog: Path = typer.Option(..., "--catalog", help="Local HR/public-catalog checkout."),
    output: Path = typer.Option(Path("dist/releases"), "--output"),
    hr_command: str = typer.Option("hr", "--hr-command", help="HR executable."),
    version: str | None = typer.Option(None, "--version"),
    channel: str = typer.Option("dev", "--channel"),
    commit: bool = typer.Option(False, "--commit", help="Commit the published catalog changes."),
    push: bool = typer.Option(False, "--push", help="Push the committed catalog changes."),
    hermes_validated: bool = typer.Option(False, "--hermes-validated", help="Assert that Hermes completed contract validation."),
) -> None:
    """Lock, create an HDC handoff, and invoke HR to build/test/publish one component."""
    request = None
    try:
        config = _config()
        store = ReleaseStore.for_config(config)
        request = store.active_for_component(component)
        if request is None:
            request = create_release_request(config, component, version=version, channel=channel)
        elif request.state not in {"LOCKED", "BUILDING"}:
            raise ReleaseWorkflowError(f"release request {request.request_id} is not buildable: {request.state}")
        handoff = build_handoff(config, request, hermes_validated=hermes_validated)
        store.update_request(request, state="BUILDING")
        result = CommandRunner().run(
            [hr_command, "packages", str(store.handoffs / f"{handoff.handoff_id}.json"),
             "--output", str(output), "--catalog", str(catalog),
             *(["--commit"] if commit or push else []), *(["--push"] if push else [])],
            timeout=1800.0,
            cwd=config.source.parent,
        )
        if not hasattr(result, "ok") or not result.ok:
            detail = getattr(result, "message", getattr(result, "stderr", "HR failed"))
            raise ReleaseWorkflowError(str(detail))
        store.update_request(request, state="PUBLISHED")
        typer.echo(result.stdout, nl=False)
        typer.echo(f"RELEASE PUBLISHED {request.request_id} {request.component} {request.version}")
    except (ConfigError, ReleaseWorkflowError) as exc:
        if request is not None:
            try:
                diagnostics = collect_diagnostics(config, request.request_id)
                ReleaseStore.for_config(config).update_request(request, state="BUILD_FAILED")
                typer.echo(f"RELEASE DIAGNOSTICS {diagnostics}", err=True)
            except (OSError, ReleaseWorkflowError):
                pass
        typer.echo(f"RELEASE PUBLISH ERROR: {exc}", err=True)
        raise typer.Exit(1)


@release_app.command("diagnose")
def release_diagnose(request_id: str = typer.Argument(...)) -> None:
    """Collect repeatable release-incident evidence without asking the operator for commands."""
    try:
        path = collect_diagnostics(_config(), request_id)
    except (ConfigError, ReleaseWorkflowError) as exc:
        typer.echo(f"RELEASE DIAGNOSTICS ERROR: {exc}", err=True)
        raise typer.Exit(1)
    typer.echo(f"DIAGNOSTICS {path}")


@release_app.command("hotfix")
def release_hotfix(request_id: str = typer.Argument(...), diagnostic: str = typer.Option(..., "--diagnostic")) -> None:
    """Record one bounded release hotfix attempt."""
    try:
        incident = record_hotfix(_config(), request_id, diagnostic)
    except (ConfigError, ReleaseWorkflowError) as exc:
        typer.echo(f"RELEASE HOTFIX ERROR: {exc}", err=True)
        raise typer.Exit(1)
    typer.echo(json.dumps(incident.to_dict(), indent=2, sort_keys=True))


@release_app.command("reinvestigate")
def release_reinvestigate(request_id: str = typer.Argument(...), diagnostic: str = typer.Option(..., "--diagnostic")) -> None:
    """Move a failed release out of patch tunnelling and into reinvestigation."""
    try:
        incident = start_reinvestigation(_config(), request_id, diagnostic)
    except (ConfigError, ReleaseWorkflowError) as exc:
        typer.echo(f"RELEASE REINVESTIGATION ERROR: {exc}", err=True)
        raise typer.Exit(1)
    typer.echo(json.dumps(incident.to_dict(), indent=2, sort_keys=True))


@release_app.command("human")
def release_human(request_id: str = typer.Argument(...), diagnostic: str = typer.Option(..., "--diagnostic")) -> None:
    """Stop automated patching and require human intervention."""
    try:
        incident = require_human(_config(), request_id, diagnostic)
    except (ConfigError, ReleaseWorkflowError) as exc:
        typer.echo(f"RELEASE HUMAN-INTERVENTION ERROR: {exc}", err=True)
        raise typer.Exit(1)
    typer.echo(json.dumps(incident.to_dict(), indent=2, sort_keys=True))


@release_app.command("observe")
def release_observe(request_id: str = typer.Argument(...), outcome: str = typer.Option(..., "--outcome", help="pass, rollback, or incident")) -> None:
    """Record the explicit HU observation outcome and release or retain the HDC lock."""
    try:
        request = finish_observation(_config(), request_id, outcome)
    except (ConfigError, ReleaseWorkflowError) as exc:
        typer.echo(f"RELEASE OBSERVATION ERROR: {exc}", err=True)
        raise typer.Exit(1)
    typer.echo(f"RELEASE OBSERVATION {request.request_id}: {request.state}")


@app.command("design")
def design(
    user_request: str | None = typer.Argument(None),
    issue: int | None = typer.Option(None, help="GitHub issue number to analyze"),
    github_repository: str | None = typer.Option(None, help="GitHub repository slug, e.g. org/repo"),
    resume: str | None = typer.Option(None, help="Resume a design session by ID"),
) -> None:
    """Turn a natural-language idea into human-reviewable DRAFT TaskPackets."""
    config = _config()
    if not _hermes_enabled(config):
        typer.echo("DESIGN: Hermes disabled; no design session was created")
        return
    issue_context = None
    if issue is not None:
        if not github_repository:
            typer.echo("DESIGN ERROR: --github-repository is required with --issue", err=True)
            raise typer.Exit(1)
        try:
            issue_data = GitHubAdapter().inspect_issue(github_repository, issue)
        except GitHubError as exc:
            typer.echo(f"DESIGN ERROR: {exc}", err=True)
            raise typer.Exit(1)
        issue_context = f"GitHub issue #{issue}: {issue_data.get('title', '')}\n{issue_data.get('body', '')}"
    try:
        session = run_design(
            config, user_request=user_request, design_id=resume, issue_context=issue_context,
            architect=HermesArchitect(), context_builder=DesignContextBuilder(), session_store=DesignSessionStore(design_root(config.source)),
            tasks_dir=config.source.parent / "tasks",
        )
    except (DesignError, ValueError) as exc:
        typer.echo(f"DESIGN ERROR: {exc}", err=True)
        raise typer.Exit(1)
    typer.echo(f"Design session {session.design_id}: {session.status}")


@issue_app.command("search")
def issue_search(
    github_repository: list[str] = typer.Option(..., "--github-repository", help="Repository slug, repeat for Core and Endpoint"),
    query: str = typer.Option("", help="Additional GitHub issue search terms"),
    state: str = typer.Option("open", help="open, closed, or all"),
) -> None:
    """Search issues only in explicitly supplied repositories."""
    try:
        issues = _github_adapter().search_issues(github_repository, query=query, state=state)
    except (GitHubError, ValueError) as exc:
        typer.echo(f"ISSUE ERROR: {exc}", err=True)
        raise typer.Exit(1)
    for issue in issues:
        typer.echo(f"{issue.repository}#{issue.number}\t{issue.state}\t{issue.title}\t{issue.url}")


@task_app.command("reconcile")
def task_reconcile(
    github_repository: list[str] = typer.Option(..., "--github-repository", help="Repository slug, repeat for Core and Endpoint"),
    query: str = typer.Option("", help="Additional GitHub issue search terms"),
    state: str = typer.Option("open", help="open, closed, or all"),
) -> None:
    """Compare local TaskPackets with GitHub issues; never writes or authorizes tasks."""
    config = _config()
    try:
        packets = list_task_packets(config.source.parent / "tasks", set(config.repositories))
        issues = _github_adapter().search_issues(github_repository, query=query, state=state)
        for decision in reconcile_packets(packets, issues):
            issue = "" if decision.issue is None else f" {decision.issue.repository}#{decision.issue.number}"
            typer.echo(f"{decision.task_id}\t{decision.status}{issue}\t{decision.reason}")
    except (GitHubError, TaskPacketError, ValueError) as exc:
        typer.echo(f"RECONCILE ERROR: {exc}", err=True)
        raise typer.Exit(1)


@task_app.command("sync")
def task_sync() -> None:
    """Publish local TaskPacket metadata to shared coordination as DRAFT."""
    config = _config()
    if config.coordination is None:
        typer.echo("SYNC ERROR: [coordination] configuration is required", err=True)
        raise typer.Exit(1)
    backend = GitHubCoordinationBackend(
        configured_github_transport(token=os.getenv("GITHUB_TOKEN")),
        config.coordination.repository,
        branch=config.coordination.branch,
        state_root=config.coordination.state_root,
    )
    try:
        packets = list_task_packets(config.source.parent / "tasks", set(config.repositories))
        for packet in packets:
            if not backend.sync_task(packet):
                typer.echo(f"{packet.id}\tCONFLICT\tshared metadata or coordination write rejected")
                continue
            typer.echo(f"{packet.id}\tSYNCED\tstate is preserved; new projections remain DRAFT")
    except (GitHubError, TaskPacketError, ValueError) as exc:
        typer.echo(f"SYNC ERROR: {exc}", err=True)
        raise typer.Exit(1)


@task_app.command("decide")
def task_decide(
    github_repository: list[str] = typer.Option(..., "--github-repository", help="Repository slug, repeat for Core and Endpoint"),
    query: str = typer.Option("", help="Additional GitHub issue search terms"),
    state: str = typer.Option("open", help="open, closed, or all"),
    worker_status: list[str] = typer.Option([], "--worker-status", help="Worker status as worker-id=available|unavailable; repeatable"),
    max_attempts: int = typer.Option(3, min=1, max=10, help="Maximum Hermes recommendations before a final blocked decision"),
) -> None:
    """Select one backlog issue with Hermes, then stop after deterministic HDC vetting."""
    config = _config()
    if not _hermes_enabled(config):
        typer.echo("DECIDE: Hermes disabled; no backlog decision was created")
        return
    try:
        availability = _parse_worker_status(worker_status)
        packets = list_task_packets(config.source.parent / "tasks", set(config.repositories))
        issues = _github_adapter().search_issues(github_repository, query=query, state=state)
        candidates = build_candidates(config, issues, packets, availability)
        store = BacklogStore(local_state_root(config.source) / "backlog")
        snapshot = store.save_snapshot(tuple(github_repository), tuple(issues), candidates)
        result = decide_next_issue(HermesIssueSelector(), candidates, max_attempts=max_attempts)
        decision = store.save_decision(snapshot, result)
    except (GitHubError, TaskPacketError, ValueError) as exc:
        typer.echo(f"DECIDE ERROR: {exc}", err=True)
        raise typer.Exit(1)
    typer.echo(f"FINAL DECISION: {result.status}")
    typer.echo(f"summary: {result.summary}")
    if result.issue:
        typer.echo(f"issue: {result.issue.repository}#{result.issue.number}")
        typer.echo(f"title: {result.issue.title}")
        typer.echo(f"worker: {result.candidate.worker_id if result.candidate else '(unknown)'}")
    typer.echo(f"attempts: {result.attempts}")
    typer.echo(f"snapshot: {snapshot.snapshot_id}")
    typer.echo(f"decision: {decision.decision_id}")
    if result.rejection_reasons:
        typer.echo("rejections:")
        for reason in result.rejection_reasons:
            typer.echo(f"  - {reason}")


@backlog_app.command("show")
def backlog_show() -> None:
    """Show the latest persisted issue snapshot and Hermes/HDC decision."""
    config = _config()
    store = BacklogStore(local_state_root(config.source) / "backlog")
    snapshot, decision = store.latest_snapshot(), store.latest_decision()
    if snapshot is None:
        typer.echo("No backlog snapshot.")
        return
    eligible = sum(1 for candidate in snapshot.candidates if candidate["eligible"])
    typer.echo(f"snapshot: {snapshot.snapshot_id}")
    typer.echo(f"captured_at: {snapshot.captured_at}")
    typer.echo(f"issues: {len(snapshot.issues)}")
    typer.echo(f"eligible_candidates: {eligible}")
    if decision is None:
        typer.echo("decision: none")
        return
    typer.echo(f"decision: {decision.decision_id}")
    typer.echo(f"status: {decision.status}")
    typer.echo(f"issue: {decision.issue or '(none)'}")
    typer.echo(f"summary: {decision.summary}")


@backlog_app.command("materialize")
def backlog_materialize() -> None:
    """Turn the latest selected issue into local READY TaskPackets explicitly."""
    config = _config()
    if not _hermes_enabled(config):
        typer.echo("MATERIALIZE: Hermes disabled; no TaskPackets were created")
        return
    store = BacklogStore(local_state_root(config.source) / "backlog")
    workflow_store = FeatureWorkflowStore(local_state_root(config.source) / "backlog" / "workflows")
    active_workflow = workflow_store.load()
    if active_workflow is not None and active_workflow.state in {"PLANNING", "RUNNING"}:
        typer.echo(f"MATERIALIZE ERROR: active feature workflow exists: {active_workflow.workflow_id}", err=True)
        raise typer.Exit(1)
    snapshot, decision = store.latest_snapshot(), store.latest_decision()
    if snapshot is None or decision is None:
        typer.echo("MATERIALIZE ERROR: a persisted backlog snapshot and decision are required", err=True)
        raise typer.Exit(1)
    if decision.status != "SELECTED":
        typer.echo(f"MATERIALIZE ERROR: latest decision is {decision.status}, not SELECTED", err=True)
        raise typer.Exit(1)
    selected_issue = _decision_issue(snapshot, decision.issue)
    if selected_issue is None:
        typer.echo("MATERIALIZE ERROR: selected issue is missing from the persisted snapshot", err=True)
        raise typer.Exit(1)
    try:
        result = materialize_selected_issue(
            config,
            snapshot,
            type("SelectedDecision", (), {"status": decision.status, "issue": selected_issue})(),
            tasks_dir=_controller_tasks_dir(config),
            architect=HermesArchitect(),
            state_store=TaskStateStore(task_state_root(config.source)),
        )
    except (GitHubError, TaskPacketError, ValueError) as exc:
        typer.echo(f"MATERIALIZE ERROR: {exc}", err=True)
        raise typer.Exit(1)
    store.save_automation(snapshot, selected_issue.repository, selected_issue.number, result.status, result.summary)
    if result.status == "READY":
        try:
            workflow_store.start(
                FeatureWorkflow(
                    workflow_id=f"feature-{selected_issue.repository.replace('/', '-')}-{selected_issue.number}",
                    issue=f"{selected_issue.repository}#{selected_issue.number}",
                    snapshot_id=snapshot.snapshot_id,
                    task_ids=result.task_ids,
                )
            )
        except ValueError as exc:
            typer.echo(f"MATERIALIZE ERROR: {exc}", err=True)
            raise typer.Exit(1)
    typer.echo(f"MATERIALIZE {result.status}: {result.summary}")
    for task_id in result.task_ids:
        typer.echo(f"task: {task_id}")


def _decision_issue(snapshot, issue_key: str) -> GitHubIssue | None:
    repository, separator, raw_number = issue_key.rpartition("#")
    if not separator or not raw_number.isdigit():
        return None
    raw = next(
        (item for item in snapshot.issues
         if item.get("repository") == repository and item.get("number") == int(raw_number)),
        None,
    )
    if raw is None:
        return None
    return GitHubIssue(
        repository,
        int(raw_number),
        str(raw.get("title", "")),
        str(raw.get("body", "")),
        str(raw.get("state", "open")),
        str(raw.get("url", "")),
        tuple(str(label) for label in raw.get("labels", [])),
    )


@backlog_app.command("poll")
def backlog_poll(
    github_repository: list[str] = typer.Option(..., "--github-repository", help="Repository slug, repeat for Core and Endpoint"),
    once: bool = typer.Option(False, help="Perform one refresh and stop"),
    forever: bool = typer.Option(False, help="Keep the Controller running between refreshes"),
    cycles: int = typer.Option(1, min=1, help="Number of refresh cycles unless --forever is used"),
    interval_seconds: int | None = typer.Option(None, min=1, help="Override configured backlog refresh interval"),
    worker_status: list[str] = typer.Option([], "--worker-status", help="Worker status as worker-id=available|unavailable; repeatable"),
) -> None:
    """Poll, cache, and decide backlog work without creating or executing tasks."""
    if once and forever:
        typer.echo("POLL ERROR: --once and --forever are mutually exclusive", err=True)
        raise typer.Exit(1)
    config = _config()
    if not _hermes_enabled(config):
        typer.echo("POLL: Hermes disabled; no backlog refresh or decision was performed")
        return
    try:
        poller = BacklogPoller(
            config, tuple(github_repository), github=_github_adapter(),
            selector=HermesIssueSelector(), store=BacklogStore(local_state_root(config.source) / "backlog"),
            availability=_parse_worker_status(worker_status),
            tasks_dir=_controller_tasks_dir(config),
            heartbeat_backend=GitHubHeartbeatBackend(
                configured_github_transport(token=os.getenv("GITHUB_TOKEN")), config.coordination.repository,
                branch=config.coordination.branch,
            ) if config.coordination else None,
        )
        results = poller.run(cycles=None if forever else 1 if once else cycles, interval_seconds=interval_seconds)
    except (GitHubError, TaskPacketError, ValueError) as exc:
        typer.echo(f"POLL ERROR: {exc}", err=True)
        raise typer.Exit(1)
    for result in results:
        decision = result.decision
        selected = decision.issue if decision else "(none)"
        typer.echo(f"POLL {result.reason}: {decision.status if decision else 'NO_DECISION'} {selected}")
def _config():
    try:
        return load_config()
    except ConfigError as exc:
        config_file = Path.cwd() / "hdc.toml"
        try:
            diagnostic = write_config_error(config_file, exc)
            typer.echo(f"CONFIG ERROR: {exc}; details: {diagnostic}", err=True)
        except OSError:
            typer.echo(f"CONFIG ERROR: {exc}", err=True)
        raise typer.Exit(1)


def _github_adapter() -> GitHubAdapter:
    """Use the configured GitHub transport, including the authenticated gh CLI."""
    return GitHubAdapter(transport=configured_github_transport(token=os.getenv("GITHUB_TOKEN")))


def _parse_worker_status(values: list[str]) -> dict[str, WorkerAvailability]:
    result: dict[str, WorkerAvailability] = {}
    for value in values:
        if "=" not in value:
            raise ValueError("--worker-status must use worker-id=available|unavailable")
        worker_id, state = (part.strip() for part in value.split("=", 1))
        if not worker_id or state not in {"available", "unavailable"}:
            raise ValueError("--worker-status must use worker-id=available|unavailable")
        if worker_id in result:
            raise ValueError(f"duplicate worker status: {worker_id}")
        result[worker_id] = WorkerAvailability(worker_id, state == "available", f"reported {state}")
    return result


def _hermes_enabled(config: Config) -> bool:
    controller = getattr(config, "controller", None)
    return controller.hermes_enabled if controller is not None else True


def _max_workers(config: Config) -> int:
    controller = getattr(config, "controller", None)
    return controller.max_workers if controller is not None else 1


@app.command()
def doctor() -> None:
    """Run read-only environment and repository checks."""
    config = _config()
    git, graphify = GitAdapter(), GraphifyAdapter()
    checks: list[tuple[str, bool, str]] = [("Python >= 3.11", sys.version_info >= (3, 11), sys.version.split()[0])]
    for adapter in (git, CodexAdapter(), graphify):
        status = adapter.status()
        checks.append((f"{status.name} available", status.available, status.version or (status.error or "")))
    status = HermesAdapter().status()
    checks.append((f"{status.name} available", status.available, status.version or (status.error or "")))
    github_repositories = any(repository.github_repository for repository in config.repositories.values())
    if config.coordination is not None and github_repositories:
        credential_file = (
            config.deployment_paths.configuration_root / "hdc.env"
            if config.deployment_paths is not None else None
        )
        credential_ok, credential_detail = _github_credential_status(credential_file)
        checks.append(("GitHub credential configured", credential_ok, credential_detail))
    for name, repo in config.repositories.items():
        if repo.path is None:
            checks.extend([
                (f"{name} path", True, "not hosted locally"),
                (f"{name} Git repository", True, "not applicable; remote project"),
                (f"{name} Graphify output", True, "not applicable; remote project"),
            ])
            continue
        checks.extend([
            (f"{name} path", repo.path.is_dir(), str(repo.path)),
            (f"{name} Git repository", repo.path.is_dir() and git.repository_valid(repo.path), "read-only check"),
            (f"{name} Graphify output", repo.path.is_dir() and all(graphify.output_status(repo.path).values()), "graph.json, GRAPH_REPORT.md, graph.html"),
        ])
    failed = False
    for label, ok, detail in checks:
        typer.echo(f"{'OK' if ok else 'FAIL':4} {label}: {detail}")
        failed |= not ok
    if failed:
        raise typer.Exit(1)


def _github_credential_status(credential_file: Path | None) -> tuple[bool, str]:
    """Check unattended GitHub credentials without reading or displaying them."""
    if os.getenv("HDC_GITHUB_AUTH", "gh").strip().lower() == "gh":
        if shutil.which("gh"):
            return True, "gh CLI selected; authentication is managed by gh"
        return False, "HDC_GITHUB_AUTH=gh but the gh executable is unavailable"
    if os.getenv("GITHUB_TOKEN"):
        return True, "GITHUB_TOKEN is present in the process environment"
    if credential_file is None or not credential_file.is_file():
        return False, "authenticated gh CLI is unavailable; set HDC_GITHUB_AUTH=token with GITHUB_TOKEN for direct API mode"
    try:
        mode = credential_file.stat().st_mode & 0o777
    except OSError as exc:
        return False, f"cannot inspect {credential_file}: {exc}"
    if mode & 0o077:
        return False, f"{credential_file} must be mode 0600 (currently {mode:03o})"
    return True, f"protected credential file present: {credential_file}"


@config_app.command("show")
def config_show() -> None:
    config = _config()
    identity = config.worker.identity
    typer.echo(f"[controller] name={identity.worker_id} id={identity.controller_id or 'missing'} host={identity.host} platform={identity.platform} roles={list(identity.roles)}")
    if config.controller:
        typer.echo(
            f"advertise_urls={list(config.controller.advertise_urls)} "
            f"network_seeds={list(config.controller.network_seeds)} core_url={config.heartbeat.core_url or 'none'}"
        )
    typer.echo(f"heartbeat interval={config.heartbeat.interval_seconds}s stale_after={config.heartbeat.stale_after_seconds}s registry_records=retained bind={config.heartbeat.bind_host}:{config.heartbeat.port}")
    typer.echo(f"coordination={'configured' if config.coordination else 'not configured'}")
    typer.echo(f"hermes_enabled={_hermes_enabled(config)} max_workers={_max_workers(config)}")
    typer.echo(f"repositories={list(identity.repositories)} capabilities={list(identity.capabilities)} workspace_root={config.worker.workspace_root} base_branch={config.worker.base_branch}")
    typer.echo(f"source = {config.source}")
    for label, paths in (("development", config.development_paths), ("deployment", config.deployment_paths)):
        if paths:
            typer.echo(
                f"[{label}.paths] application_root={paths.application_root} configuration_root={paths.configuration_root} "
                f"state_root={paths.state_root} workspace_root={paths.workspace_root} log_root={paths.log_root}"
            )
    for repo in config.repositories.values():
        branch = repo.base_branch or config.worker.base_branch
        path = str(repo.path) if repo.path is not None else "(remote; query another Controller)"
        typer.echo(f"[{repo.name}] path={path} read_only={str(repo.read_only).lower()} graphify={str(repo.graphify).lower()} base_branch={branch}")


@controller_app.command("heartbeat")
def controller_heartbeat(url: str) -> None:
    """Probe one Controller's HTTP heartbeat endpoint."""
    config = _config()
    try:
        heartbeat = request_heartbeat(url, timeout_seconds=config.heartbeat.timeout_seconds, auth_token=config.heartbeat.auth_token)
    except Exception as exc:
        typer.echo(f"HEARTBEAT ERROR: {exc}", err=True)
        raise typer.Exit(1)
    typer.echo(f"HEARTBEAT OK: {heartbeat.worker_id} id={heartbeat.controller_id or 'missing'} roles={list(heartbeat.roles)} platform={heartbeat.platform}")


@controller_app.command("serve")
def controller_serve() -> None:
    """Run the foreground, heartbeat-only Controller endpoint."""
    config = _config()
    heartbeat = WorkerHeartbeat.from_identity(config.worker.identity)
    server = HeartbeatServer(
        heartbeat, host=config.heartbeat.bind_host, port=config.heartbeat.port,
        auth_token=config.heartbeat.auth_token,
        registry=ControllerRegistry(local_state_root(config.source) / "controllers"),
        stale_after_seconds=config.heartbeat.stale_after_seconds,
        prune_after_seconds=config.heartbeat.prune_after_seconds,
        peer_context_provider=lambda request: build_peer_context(config, config.worker.identity, request).to_payload(),
    )
    typer.echo(f"HEARTBEAT SERVING: http://{config.heartbeat.bind_host}:{config.heartbeat.port}/hdc/heartbeat")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.shutdown()


@controller_app.command("heartbeat-loop")
def controller_heartbeat_loop(url: str | None = None, cycles: int | None = typer.Option(None, help="Stop after this many announcements; default is continuous.")) -> None:
    """Announce this Controller to Core at the configured interval."""
    config = _config()
    target = url or config.heartbeat.core_url
    if not target:
        typer.echo("HEARTBEAT ERROR: configure heartbeat.core_url or pass a URL", err=True)
        raise typer.Exit(1)
    count = 0
    while cycles is None or count < cycles:
        heartbeat = WorkerHeartbeat.from_identity(config.worker.identity)
        try:
            send_heartbeat(target, heartbeat, timeout_seconds=config.heartbeat.timeout_seconds, auth_token=config.heartbeat.auth_token)
            typer.echo(f"HEARTBEAT SENT: {target}")
        except Exception as exc:
            typer.echo(f"HEARTBEAT ERROR: {exc}", err=True)
        count += 1
        if cycles is None or count < cycles:
            time.sleep(config.heartbeat.interval_seconds)


@controller_app.command("register")
def controller_register() -> None:
    """Register this Controller with configured network seeds once."""
    config = _config()
    if not config.controller or not config.controller.network_seeds:
        typer.echo("REGISTER ERROR: configure controller.network_seeds", err=True)
        raise typer.Exit(1)
    heartbeat = WorkerHeartbeat.from_identity(
        config.worker.identity,
        controller_version=__version__,
        schema_major=config.schema_version.major,
        schema_minor=config.schema_version.minor,
        advertise_urls=config.controller.advertise_urls,
    )
    registry = ControllerRegistry(controller_root(config.source) / "controllers")
    failures = []
    total = 0
    for seed in config.controller.network_seeds:
        try:
            records = register_with_seed(seed, heartbeat, timeout_seconds=config.heartbeat.timeout_seconds, auth_token=config.heartbeat.auth_token)
            registry.merge(records)
            total = max(total, len(records))
            typer.echo(f"REGISTERED {seed} controllers={len(records)}")
        except Exception as exc:
            failures.append(f"{seed}: {exc}")
    if failures:
        for failure in failures:
            typer.echo(f"REGISTER ERROR: {failure}", err=True)
        raise typer.Exit(1)
    typer.echo(f"REGISTER COMPLETE controllers={total}")


@controller_app.command("peer-query")
def controller_peer_query(
    peer: str = typer.Argument(..., help="Configured peer name or peer URL."),
    repository: list[str] = typer.Option([], "--repository", help="Project name to request; repeat to request several."),
) -> None:
    """Query one peer Controller for hosted project context on demand."""
    config = _config()
    known = dict(_known_controller_endpoints(config))
    url = known.get(peer, peer)
    try:
        context = request_peer_context(
            url,
            PeerContextRequest(config.worker.identity.controller_id, tuple(repository)),
            timeout_seconds=config.heartbeat.timeout_seconds,
            auth_token=config.heartbeat.auth_token,
        )
    except (OSError, ValueError) as exc:
        typer.echo(f"PEER ERROR: {exc}", err=True)
        raise typer.Exit(1)
    typer.echo(f"PEER {context.controller_name}: {context.platform} status={context.status}")
    typer.echo(f"capabilities: {list(context.capabilities)}")
    for project in context.projects:
        hosted = "hosted" if project.hosted else "not hosted"
        typer.echo(f"project: {project.name} {hosted} read_only={str(project.read_only).lower()} base_branch={project.base_branch}")


@controller_app.command("list")
def controller_list() -> None:
    """List this Controller and the configured peer Controllers it can query."""
    config = _config()
    local = build_peer_context(
        config,
        config.worker.identity,
        PeerContextRequest(config.worker.identity.controller_id).to_payload(),
    )
    contexts = [("local", local)]
    for name, url in _known_controller_endpoints(config):
        try:
            context = request_peer_context(
                url,
                PeerContextRequest(config.worker.identity.controller_id),
                timeout_seconds=config.heartbeat.timeout_seconds,
                auth_token=config.heartbeat.auth_token,
            )
        except (OSError, ValueError) as exc:
            typer.echo(f"CONTROLLER {name}: unavailable ({exc})")
            continue
        contexts.append((name, context))

    for source, context in contexts:
        typer.echo(
            f"CONTROLLER {source}: {context.controller_name} id={context.controller_id} "
            f"host={context.host} platform={context.platform} status={context.status}"
        )
        typer.echo(f"  capabilities: {list(context.capabilities)}")
        for project in context.projects:
            hosted = "hosted" if project.hosted else "not hosted"
            typer.echo(
                f"  project: {project.name} {hosted} "
                f"read_only={str(project.read_only).lower()} base_branch={project.base_branch}"
            )


def _known_controller_urls(config: Config) -> tuple[str, ...]:
    """Return explicit and seed-discovered Controller endpoints without duplicates."""
    return tuple(url for _name, url in _known_controller_endpoints(config))


def _known_controller_endpoints(config: Config) -> tuple[tuple[str, str], ...]:
    endpoints = list((config.controller.peer_urls or {}).items() if config.controller else ())
    try:
        records = ControllerRegistry(controller_root(config.source) / "controllers").list()
    except (OSError, ValueError, KeyError, TypeError):
        records = []
    local_id = config.worker.identity.controller_id
    for heartbeat in records:
        if heartbeat.controller_id == local_id:
            continue
        endpoints.extend((heartbeat.worker_id, url) for url in heartbeat.advertise_urls)
    return tuple(dict.fromkeys(endpoints))


def _controller_tasks_dir(config: Config) -> Path:
    """Locate canonical TaskPackets when running from a checkout or deployment config."""
    hdc_repository = config.repositories.get("hdc")
    if hdc_repository is not None:
        if hdc_repository.path is not None:
            candidate = hdc_repository.path / "tasks"
            if candidate.is_dir():
                return candidate
    return config.source.parent / "tasks"


def _github_auth_available() -> bool:
    """Return whether the configured process can use a GitHub transport."""
    mode = os.getenv("HDC_GITHUB_AUTH", "gh").strip().lower()
    return bool(os.getenv("GITHUB_TOKEN")) or (mode == "gh" and shutil.which("gh") is not None)


def _run_controller_work_cycle(config: Config) -> object:
    """Run one bounded execution cycle for the Controller.

    Backlog selection and Hermes design are explicit workflow actions. They are
    intentionally absent here so a running service cannot spend model calls on a
    timer or select a new idea while an existing feature is in progress.
    """
    release_locks = ReleaseStore.for_config(config).active_requests()
    if release_locks:
        # Normal development is frozen while HR/HU complete the candidate's
        # build and observation. Release-incident commands remain explicit.
        return []
    if _max_workers(config) == 0:
        return []
    tasks_dir = _controller_tasks_dir(config)
    workflow = FeatureWorkflowStore(local_state_root(config.source) / "backlog" / "workflows").load()
    task_ids = set(workflow.task_ids) if workflow is not None and workflow.state in {"PLANNING", "RUNNING"} else None
    if config.coordination is None:
        coordination = None
    else:
        backend = GitHubCoordinationBackend(
            configured_github_transport(token=os.getenv("GITHUB_TOKEN")),
            config.coordination.repository,
            branch=config.coordination.branch,
            state_root=config.coordination.state_root,
        )
        coordination = backend

    if coordination is None:
        return run_ready_tasks(config, tasks_dir, max_tasks=_max_workers(config), task_ids=task_ids)
    # Per-task execution performs deterministic validation only. Hermes review is
    # an explicit aggregate feature step after the active batch completes.
    return run_coordinated_cycle(config, tasks_dir, coordination, reviewer=None, max_tasks=_max_workers(config), task_ids=task_ids)


def _run_full_test(
    config: Config,
    github_repositories: list[str],
    *,
    query: str = "",
    state: str = "open",
) -> None:
    """Exercise one complete planning-to-worker flow without authorizing work."""
    repositories = tuple(github_repositories) or tuple(
        repo.github_repository for repo in config.repositories.values() if repo.github_repository
    )
    if not repositories:
        raise ValueError("--github-repository is required when no repository.github_repository is configured")
    if state not in {"open", "closed", "all"}:
        raise ValueError("state must be open, closed, or all")

    tasks_dir = _controller_tasks_dir(config)
    existing_packets = list_task_packets(tasks_dir, set(config.repositories))
    issues = _github_adapter().search_issues(repositories, query=query, state=state)
    typer.echo(f"FULL TEST: fetched {len(issues)} GitHub issue(s) from {', '.join(repositories)}")

    if not _hermes_enabled(config):
        typer.echo("FULL TEST: Hermes disabled; planning stopped without Hermes or worker operations")
        return

    candidates = build_candidates(config, issues, existing_packets, {})
    eligible = tuple(candidate for candidate in candidates if candidate.eligible)
    if not eligible:
        typer.echo("FULL TEST: no eligible issue; Hermes was not invoked")
        return
    result = decide_next_issue(HermesIssueSelector(), candidates, max_attempts=1)
    if result.status != "SELECTED" or result.issue is None:
        typer.echo(f"FULL TEST: Hermes selection result={result.status}: {result.summary}")
        return
    typer.echo(f"FULL TEST: selected {result.issue.repository}#{result.issue.number}: {result.issue.title}")

    request_text = f"Implement GitHub issue {result.issue.repository}#{result.issue.number}: {result.issue.title}"
    context = DesignContextBuilder().build(config, request_text, tasks_dir=tasks_dir)
    architect_result = HermesArchitect(max_attempts=1).design(ArchitectRequest(
        design_id=f"full-test-{result.issue.repository.replace('/', '-')}-{result.issue.number}",
        user_request=request_text,
        context=context,
        issue_context=f"GitHub issue {result.issue.repository}#{result.issue.number}\n{result.issue.title}\n{result.issue.body}",
    ))
    typer.echo(f"FULL TEST: Hermes task breakdown={architect_result.status}")
    if architect_result.warnings:
        for warning in architect_result.warnings:
            typer.echo(f"FULL TEST: warning: {warning}")
    if architect_result.status != "READY_TO_DRAFT":
        typer.echo(f"FULL TEST: stopped before TaskPacket conversion: {architect_result.summary}")
        return

    packets = []
    existing_for_issue = sum(
        1 for packet in existing_packets
        if any(reference.repository == result.issue.repository and reference.number == result.issue.number for reference in packet.github_issues)
    )
    additional = max(0, len(architect_result.proposed_tasks) - existing_for_issue)
    typer.echo(
        f"FULL TEST: Hermes proposed {len(architect_result.proposed_tasks)} subissue/task(s); "
        f"additional recommended beyond {existing_for_issue} existing linked packet(s): {additional}"
    )
    try:
        for proposed in architect_result.proposed_tasks:
            packet = proposed.to_task_packet(set(config.repositories))
            packets.append(replace(packet, github_issues=[IssueReference(result.issue.repository, result.issue.number)]))
    except (TaskPacketError, ValueError) as exc:
        typer.echo(f"FULL TEST: TaskPacket conversion blocked: {exc}")
        return

    if not packets:
        typer.echo("FULL TEST: Hermes returned no TaskPackets")
        return
    typer.echo("FULL TEST: converted TaskPackets:")
    for packet in packets:
        typer.echo(f"  {packet.id}: {packet.repository} — {packet.objective}")
    typer.echo("FULL TEST: simulated sequential worker execution:")
    for packet in packets:
        typer.echo(f"  WORKER START {packet.id}: {packet.objective}")
        typer.echo(f"  WORKER DONE  {packet.id}: simulated DONE (no Codex, Git, Helix, or GitHub write)")
    typer.echo(
        f"FULL TEST: complete; {len(packets)} TaskPacket(s) returned DONE; "
        "no Hermes call was made per TaskPacket"
    )


@controller_app.command("run")
def controller_run(
    cycles: int | None = typer.Option(None, help="Stop after this many runtime cycles; default is continuous."),
    full_test: bool = typer.Option(False, "--full-test", help="Run one complete dry-run backlog-to-worker integration flow."),
    github_repository: list[str] = typer.Option([], "--github-repository", help="Repository slug for --full-test; repeat for each repository."),
) -> None:
    """Run the persistent foreground HDC Controller runtime."""
    config = _config()
    if full_test:
        try:
            _run_full_test(config, github_repository)
        except (ConfigError, GitHubError, TaskPacketError, ValueError) as exc:
            typer.echo(f"FULL TEST ERROR: {exc}", err=True)
            raise typer.Exit(1)
        return
    try:
        runtime = ControllerRuntime(
            config.worker.identity,
            config.heartbeat,
            controller_root(config.source),
            cycle=lambda: _run_controller_work_cycle(config),
            peer_context_provider=lambda request: build_peer_context(config, config.worker.identity, request).to_payload(),
            schema_version=config.schema_version,
            controller_version=__version__,
            advertise_urls=config.controller.advertise_urls if config.controller else (),
            network_seeds=config.controller.network_seeds if config.controller else (),
        )
        status = runtime.run(cycles=cycles)
    except (ConfigError, RuntimeErrorState, OSError) as exc:
        typer.echo(f"CONTROLLER ERROR: {exc}", err=True)
        raise typer.Exit(1)


@controller_app.command("stop")
def controller_stop() -> None:
    """Request a running Controller to stop."""
    config = _config()
    try:
        typer.echo(stop_runtime(controller_root(config.source)))
    except RuntimeErrorState as exc:
        typer.echo(f"CONTROLLER ERROR: {exc}", err=True)
        raise typer.Exit(1)


@controller_app.command("status")
def controller_status() -> None:
    """Show the local Controller runtime status."""
    config = _config()
    status = read_runtime_status(controller_root(config.source))
    if status is None:
        typer.echo("CONTROLLER STATUS: never started")
        return
    typer.echo(
        f"CONTROLLER STATUS: {status.status} id={status.controller_id} "
        f"last_heartbeat={status.last_heartbeat or 'none'} "
        f"last_cycle={status.last_cycle or 'none'} error={status.last_error or 'none'}"
    )


@controller_app.command("service-config")
def controller_service_config(output: Path | None = typer.Option(None, help="Descriptor path; defaults beside hdc.toml")) -> None:
    """Generate a reviewed Linux or Windows Controller service descriptor."""
    config = _config()
    target = output or (config.source.parent / f"hdc-controller{service_descriptor_suffix(config.worker.identity.platform)}")
    try:
        write_service_descriptor(config, target)
    except ValueError as exc:
        typer.echo(f"CONTROLLER SERVICE ERROR: {exc}", err=True)
        raise typer.Exit(1)
    typer.echo(f"CONTROLLER SERVICE DESCRIPTOR: {target}")


@repo_app.command("list")
def repo_list() -> None:
    for repo in _config().repositories.values():
        typer.echo(f"{repo.name}\t{repo.path if repo.path is not None else '(remote; query another Controller)'}")


@repo_app.command("status")
def repo_status(repo: str) -> None:
    config, git = _config(), GitAdapter()
    target = config.repository(repo)
    if target.path is None:
        typer.echo(f"repository {repo} is remote; query its hosting Controller", err=True)
        raise typer.Exit(1)
    if not target.path.is_dir():
        typer.echo(f"missing repository path: {target.path}", err=True)
        raise typer.Exit(1)
    if not git.repository_valid(target.path):
        typer.echo(f"not a Git repository: {target.path}", err=True)
        raise typer.Exit(1)
    typer.echo(git.repository_status(target.path))


@graph_app.command("status")
def graph_status(repo: str) -> None:
    target = _config().repository(repo)
    if target.path is None:
        typer.echo(f"repository {repo} is remote; Graphify status is available from its hosting Controller", err=True)
        raise typer.Exit(1)
    statuses = GraphifyAdapter().output_status(target.path)
    for name, present in statuses.items():
        typer.echo(f"{'OK' if present else 'MISSING'} {name}")
    if not all(statuses.values()):
        raise typer.Exit(1)


def _task_packet(task_id: str):
    config = _config()
    try:
        packets = list_task_packets(config.source.parent / "tasks", set(config.repositories))
        for packet in packets:
            if packet.id == task_id:
                return config, packet
        raise TaskPacketError(f"task packet not found: {task_id}")
    except TaskPacketError as exc:
        typer.echo(f"TASK ERROR: {exc}", err=True)
        raise typer.Exit(1)


@task_app.command("list")
def task_list() -> None:
    """List all valid task packets in deterministic order."""
    config = _config()
    try:
        packets = list_task_packets(config.source.parent / "tasks", set(config.repositories))
    except TaskPacketError as exc:
        typer.echo(f"TASK ERROR: {exc}", err=True)
        raise typer.Exit(1)
    for packet in packets:
        typer.echo(f"{packet.id}\t{packet.repository}\t{packet.risk}\t{packet.objective}")


@task_app.command("show")
def task_show(task_id: str) -> None:
    """Show a validated task packet."""
    _, packet = _task_packet(task_id)
    for field in ("id", "repository", "objective", "scope", "non_goals", "acceptance", "validation", "stop_conditions", "risk", "dependencies", "required_capabilities", "github_issues"):
        value = getattr(packet, field)
        if isinstance(value, list):
            typer.echo(f"{field}:")
            for item in value:
                typer.echo(f"  - {item}")
        else:
            typer.echo(f"{field}: {value}")


@task_app.command("validate")
def task_validate(task_id: str) -> None:
    """Validate one task packet without executing it."""
    _, packet = _task_packet(task_id)
    typer.echo(f"VALID task packet: {packet.id}")


@task_app.command("plan")
def task_plan(task_id: str) -> None:
    """Show the deterministic plan without executing the task."""
    config, packet = _task_packet(task_id)
    plan = build_execution_plan(config, packet)
    fields = (
        "task_id", "repository", "repository_path", "repository_read_only",
        "worker_id", "worker_platform", "worker_capabilities", "current_branch", "proposed_branch", "proposed_workspace", "risk", "dependencies", "required_capabilities", "base_branch",
        "codex_available", "hermes_available", "execution_permitted",
    )
    for field in fields:
        value = getattr(plan, field)
        typer.echo(f"{field}: {str(value).lower() if isinstance(value, bool) else value}")
    typer.echo("validation:")
    for command in plan.validation:
        typer.echo(f"  - {command}")
    typer.echo("stop_conditions:")
    for condition in plan.stop_conditions:
        typer.echo(f"  - {condition}")
    typer.echo("denial_reasons:")
    if plan.denial_reasons:
        for reason in plan.denial_reasons:
            typer.echo(f"  - {reason}")
    else:
        typer.echo("  - none")


@task_app.command("state")
def task_state(task_id: str) -> None:
    """Show the explicit local lifecycle state for a task."""
    config, _ = _task_packet(task_id)
    try:
        lifecycle = TaskStateStore(task_state_root(config.source)).load(task_id)
    except ValueError as exc:
        typer.echo(f"TASK STATE ERROR: {exc}", err=True)
        raise typer.Exit(1)
    typer.echo(f"{task_id}: {lifecycle.state}")


@task_app.command("transition")
def task_transition(task_id: str, state: str) -> None:
    """Apply one explicit lifecycle transition to a task."""
    config, _ = _task_packet(task_id)
    try:
        lifecycle = TaskStateStore(task_state_root(config.source)).transition(task_id, state.upper())
    except ValueError as exc:
        typer.echo(f"TASK STATE ERROR: {exc}", err=True)
        raise typer.Exit(1)
    typer.echo(f"{task_id}: {lifecycle.state}")


@workspace_app.command("list")
def workspace_list() -> None:
    """List HDC workspaces beneath the configured workspace root."""
    config = _config()
    workspaces = WorkspaceManager(root=config.worker.workspace_root).list()
    if not workspaces:
        typer.echo("No HDC workspaces.")
        return
    for workspace in workspaces:
        typer.echo(f"{workspace.task_id}\t{workspace.path}\t{workspace.branch or '(detached)'}\t{workspace.status or '(unavailable)'}")


@workspace_app.command("inspect")
def workspace_inspect(task_id: str) -> None:
    """Inspect one existing HDC workspace."""
    config = _config()
    try:
        workspace = WorkspaceManager(root=config.worker.workspace_root).inspect(task_id)
    except WorkspaceError as exc:
        typer.echo(f"WORKSPACE ERROR: {exc}", err=True)
        raise typer.Exit(1)
    typer.echo(f"task_id: {workspace.task_id}")
    typer.echo(f"path: {workspace.path}")
    typer.echo(f"branch: {workspace.branch or '(detached)'}")
    typer.echo(f"status: {workspace.status or '(unavailable)'}")


@workspace_app.command("create")
def workspace_create(task_id: str) -> None:
    """Create the isolated workspace described by a task plan."""
    config, packet = _task_packet(task_id)
    plan = build_execution_plan(config, packet)
    try:
        workspace = WorkspaceManager(root=config.worker.workspace_root).create(plan)
    except WorkspaceError as exc:
        typer.echo(f"WORKSPACE ERROR: {exc}", err=True)
        raise typer.Exit(1)
    typer.echo(f"CREATED workspace: {workspace.path}")


@run_app.command("list")
def run_list() -> None:
    """List durable local HDC run records."""
    config = _config()
    records = RunStore(runs_root(config.source)).list()
    if not records:
        typer.echo("No HDC runs.")
        return
    for record in records:
        typer.echo(f"{record.run_id}\t{record.phase}\t{record.task_id}\t{record.repository}")


@run_app.command("show")
def run_show(run_id: str) -> None:
    """Show one durable HDC run record."""
    try:
        config = _config()
        record = RunStore(runs_root(config.source)).load(run_id)
    except ValueError as exc:
        typer.echo(f"RUN ERROR: {exc}", err=True)
        raise typer.Exit(1)
    for field in ("run_id", "task_id", "repository", "branch", "workspace", "created_at", "updated_at", "phase", "terminal_status", "attempt_counts"):
        typer.echo(f"{field}: {getattr(record, field)}")


@run_app.command("start")
def run_start(task_id: str) -> None:
    """Start one authorized implementation and validation run."""
    config, packet = _task_packet(task_id)
    try:
        record = start_run(config, packet, lifecycle=TaskStateStore(task_state_root(config.source)).load(task_id), store=RunStore(runs_root(config.source)))
    except WorkflowError as exc:
        typer.echo(f"RUN ERROR: {exc}", err=True)
        raise typer.Exit(1)
    typer.echo(f"RUN {record.run_id}: {record.phase}")


@run_app.command("report")
def run_report(run_id: str) -> None:
    """Render a human-readable report for one durable run."""
    config = _config()
    store = RunStore(runs_root(config.source))
    try:
        record = store.load(run_id)
        _, packet = _task_packet(record.task_id)
    except (ValueError, typer.Exit) as exc:
        if isinstance(exc, typer.Exit):
            raise
        typer.echo(f"RUN ERROR: {exc}", err=True)
        raise typer.Exit(1)
    typer.echo(render_acceptance_report(record, packet, store), nl=False)


@worker_app.command("run")
def worker_run(
    coordinated: bool = typer.Option(False, help="Use GitHub coordination to discover, claim, and publish tasks"),
    lease_seconds: int = typer.Option(900, min=30, help="Seconds granted to each coordinated claim"),
) -> None:
    """Run HDC tasks once in the foreground."""
    config = _config()
    release_locks = ReleaseStore.for_config(config).active_requests()
    if release_locks:
        owners = ", ".join(f"{item.component}:{item.request_id}" for item in release_locks)
        typer.echo(f"WORKER: release lock active ({owners}); normal development is paused")
        return
    max_workers = _max_workers(config)
    if max_workers == 0:
        typer.echo("WORKER: max_workers=0; no worker operations were performed")
        return
    if coordinated:
        if config.coordination is None:
            typer.echo("WORKER ERROR: [coordination] configuration is required for --coordinated", err=True)
            raise typer.Exit(1)
        backend = GitHubCoordinationBackend(
            configured_github_transport(token=os.getenv("GITHUB_TOKEN")),
            config.coordination.repository,
            branch=config.coordination.branch,
            state_root=config.coordination.state_root,
        )
        try:
            results = run_coordinated_cycle(
                config,
                config.source.parent / "tasks",
                backend,
                lease_seconds=lease_seconds,
                reviewer=HermesReviewer() if _hermes_enabled(config) else None,
                max_tasks=max_workers,
            )
        except (TaskPacketError, GitHubError, ValueError) as exc:
            typer.echo(f"WORKER ERROR: {exc}", err=True)
            raise typer.Exit(1)
        if not results:
            typer.echo("No routable coordinated HDC tasks.")
            return
        for result in results:
            status = "PUBLISHED" if result.published else "NOT_PUBLISHED"
            detail = result.error or (result.run.phase if result.run else "blocked")
            typer.echo(f"{result.task_id}: {status} {detail}")
        return
    try:
        records = run_ready_tasks(config, config.source.parent / "tasks", max_tasks=max_workers)
    except (TaskPacketError, ValueError) as exc:
        typer.echo(f"WORKER ERROR: {exc}", err=True)
        raise typer.Exit(1)
    if not records:
        typer.echo("No READY HDC tasks.")
        return
    for record in records:
        typer.echo(f"RUN {record.run_id}: {record.phase}")


@worker_app.command("heartbeat")
def worker_heartbeat() -> None:
    """Publish this Controller host's availability to shared GitHub coordination."""
    config = _config()
    if config.coordination is None:
        typer.echo("HEARTBEAT ERROR: [coordination] configuration is required", err=True)
        raise typer.Exit(1)
    backend = GitHubHeartbeatBackend(
        configured_github_transport(token=os.getenv("GITHUB_TOKEN")), config.coordination.repository,
        branch=config.coordination.branch,
    )
    heartbeat = WorkerHeartbeat.from_identity(config.worker.identity)
    if not backend.publish(heartbeat):
        typer.echo(f"HEARTBEAT ERROR: could not publish {heartbeat.worker_id}", err=True)
        raise typer.Exit(1)
    typer.echo(f"HEARTBEAT PUBLISHED: {heartbeat.worker_id} {heartbeat.observed_at.isoformat()}")


if __name__ == "__main__":
    app()
