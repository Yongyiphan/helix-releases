"""Replaceable GitHub coordination adapter; never an authorization source."""

from dataclasses import dataclass
import json
import os
from pathlib import Path
import pwd
from typing import Any, Protocol, Sequence
from urllib.parse import urlencode
from urllib.request import Request, urlopen

from .process import CommandError, CommandRunner


class GitHubError(RuntimeError):
    """Raised when a GitHub operation cannot be completed."""


class GitHubTransport(Protocol):
    def request(self, method: str, path: str, payload: dict[str, Any] | None = None) -> dict[str, Any] | list[Any]:
        ...

    def download(self, url: str, destination: Path) -> None:
        ...


@dataclass(frozen=True)
class IssueAssociation:
    repository: str
    issue_number: int
    task_id: str
    explicitly_authorized: bool = False


@dataclass(frozen=True)
class GitHubIssue:
    repository: str
    number: int
    title: str
    body: str
    state: str
    url: str = ""
    labels: tuple[str, ...] = ()


class UrllibGitHubTransport:
    def __init__(self, base_url: str = "https://api.github.com", token: str | None = None):
        self.base_url = base_url.rstrip("/")
        self.token = token

    def request(self, method: str, path: str, payload: dict[str, Any] | None = None) -> dict[str, Any] | list[Any]:
        if not self.token:
            raise GitHubError("GitHub token is required for network operations")
        body = json.dumps(payload).encode() if payload is not None else None
        request = Request(f"{self.base_url}/{path.lstrip('/')}", data=body, method=method, headers={
            "Accept": "application/vnd.github+json",
            "Authorization": f"Bearer {self.token}",
            "X-GitHub-Api-Version": "2022-11-28",
            **({"Content-Type": "application/json"} if body is not None else {}),
        })
        try:
            with urlopen(request, timeout=30) as response:
                return json.loads(response.read().decode())
        except Exception as exc:
            raise GitHubError(str(exc)) from exc

    def download(self, url: str, destination: Path) -> None:
        request = Request(url, headers={
            "Accept": "application/octet-stream",
            "Authorization": f"Bearer {self.token}",
            "X-GitHub-Api-Version": "2022-11-28",
        })
        temporary = destination.with_suffix(destination.suffix + ".part")
        try:
            destination.parent.mkdir(parents=True, exist_ok=True)
            with urlopen(request, timeout=60) as response, temporary.open("wb") as handle:
                while chunk := response.read(1024 * 1024):
                    handle.write(chunk)
            temporary.replace(destination)
        except Exception as exc:
            temporary.unlink(missing_ok=True)
            raise GitHubError(str(exc)) from exc


class GhCliTransport:
    """Use the authenticated ``gh`` account store through ``gh api``."""

    def __init__(self, executable: str = "gh", runner: CommandRunner | None = None, timeout: float = 30.0):
        self.executable = executable
        self.runner = runner or CommandRunner()
        self.timeout = timeout

    def request(self, method: str, path: str, payload: dict[str, Any] | None = None) -> dict[str, Any] | list[Any]:
        args = [self.executable, "api", path, "--method", method]
        input_text = None if payload is None else json.dumps(payload)
        if payload is not None:
            args.extend(["--input", "-"])
        result = self.runner.run(args, timeout=self.timeout, input_text=input_text)
        if isinstance(result, CommandError):
            raise GitHubError(result.message)
        if not result.ok:
            raise GitHubError(result.stderr.strip() or result.stdout.strip() or f"gh api exited with code {result.returncode}")
        try:
            decoded = json.loads(result.stdout)
        except json.JSONDecodeError as exc:
            raise GitHubError(f"gh api returned invalid JSON: {exc}") from exc
        if not isinstance(decoded, (dict, list)):
            raise GitHubError("gh api response must be an object or array")
        return decoded

    def download(self, url: str, destination: Path) -> None:
        temporary = destination.with_suffix(destination.suffix + ".part")
        temporary.unlink(missing_ok=True)
        result = self.runner.run_binary(
            [self.executable, "api", url, "--header", "Accept: application/octet-stream"],
            timeout=60,
        )
        if isinstance(result, CommandError) or not result.ok:
            temporary.unlink(missing_ok=True)
            detail = result.message if isinstance(result, CommandError) else (result.stderr.decode(errors="replace").strip() or result.stdout.decode(errors="replace").strip())
            raise GitHubError(detail or "gh api download failed")
        try:
            temporary.write_bytes(result.stdout)
            temporary.replace(destination)
        except OSError as exc:
            temporary.unlink(missing_ok=True)
            raise GitHubError(str(exc)) from exc


def configured_github_transport(token: str | None = None) -> GitHubTransport:
    """Use the host's authenticated ``gh`` CLI unless direct API mode is explicit."""
    if os.environ.get("HDC_GITHUB_AUTH", "gh").strip().lower() == "gh":
        # systemd services often have no HOME. Resolve the configured service
        # account explicitly so gh uses the same account that published the
        # release instead of an empty root/default profile.
        if not os.environ.get("GH_CONFIG_DIR", "").strip():
            service_user = os.environ.get("HDC_SERVICE_USER", "").strip()
            if service_user:
                try:
                    service_home = pwd.getpwnam(service_user).pw_dir
                except KeyError:
                    service_home = ""
                if service_home:
                    os.environ["GH_CONFIG_DIR"] = str(Path(service_home) / ".config" / "gh")
        return GhCliTransport()
    return UrllibGitHubTransport(token=token)


class GitHubAdapter:
    def __init__(self, transport: GitHubTransport | None = None, *, token: str | None = None):
        self.transport = transport or configured_github_transport(token)

    def inspect_issue(self, repository: str, issue_number: int) -> dict[str, Any]:
        response = self.transport.request("GET", f"/repos/{repository}/issues/{issue_number}")
        if not isinstance(response, dict):
            raise GitHubError("GitHub issue response must be an object")
        return response

    def search_issues(self, repositories: Sequence[str], *, query: str = "", state: str = "open") -> list[GitHubIssue]:
        """Search issues only within explicitly configured repository slugs."""
        if state not in {"open", "closed", "all"}:
            raise ValueError("issue state must be open, closed, or all")
        results: list[GitHubIssue] = []
        for repository in repositories:
            terms = f"repo:{repository} is:issue state:{state}"
            if query.strip():
                terms = f"{terms} {query.strip()}"
            response = self.transport.request("GET", f"/search/issues?{urlencode({'q': terms, 'per_page': 100})}")
            if not isinstance(response, dict) or not isinstance(response.get("items"), list):
                raise GitHubError("GitHub issue search response must contain items")
            for item in response["items"]:
                if not isinstance(item, dict) or "pull_request" in item:
                    continue
                labels = tuple(label.get("name", "") for label in item.get("labels", []) if isinstance(label, dict) and label.get("name"))
                results.append(GitHubIssue(repository, int(item["number"]), str(item.get("title", "")), str(item.get("body") or ""), str(item.get("state", state)), str(item.get("html_url", "")), labels))
        return sorted(results, key=lambda issue: (issue.repository, issue.number))

    def associate_issue(self, repository: str, issue_number: int, task_id: str) -> IssueAssociation:
        self.inspect_issue(repository, issue_number)
        return IssueAssociation(repository, issue_number, task_id)

    def post_run_status(self, repository: str, issue_number: int, run_id: str, status: str) -> dict[str, Any]:
        return self.transport.request("POST", f"/repos/{repository}/issues/{issue_number}/comments", {
            "body": f"HDC run `{run_id}` status: `{status}`",
        })

    def create_draft_pull_request(self, repository: str, *, head: str, base: str, title: str, body: str) -> dict[str, Any]:
        return self.transport.request("POST", f"/repos/{repository}/pulls", {
            "title": title,
            "head": head,
            "base": base,
            "body": body,
            "draft": True,
        })

    def attach_summary(self, repository: str, issue_number: int, summary: str) -> dict[str, Any]:
        return self.transport.request("POST", f"/repos/{repository}/issues/{issue_number}/comments", {
            "body": summary,
        })
