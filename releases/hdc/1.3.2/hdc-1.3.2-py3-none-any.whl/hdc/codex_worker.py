"""Codex implementation worker behind the HDC worker interface."""

from pathlib import Path

from .adapters import CodexAdapter, GitAdapter
from .process import CommandError, CommandResult, CommandRunner
from .workers import DevelopmentWorker, WorkerRequest, WorkerResult


def build_worker_prompt(request: WorkerRequest) -> str:
    """Build a bounded prompt entirely from deterministic request context."""
    task = request.task
    plan = request.plan
    lines = [
        "You are HDC's implementation worker. Make the requested change in the assigned workspace.",
        "Follow repository rules, stay within scope, and do not modify external repositories.",
        "",
        "Repository instructions:",
        *(f"- {item}" for item in request.repository_instructions),
        "",
        f"Task ID: {task.id}",
        f"Objective: {task.objective}",
        "Scope:",
        *(f"- {item}" for item in task.scope),
        "Non-goals:",
        *(f"- {item}" for item in task.non_goals),
        "Acceptance criteria:",
        *(f"- {item}" for item in task.acceptance),
        f"Attempt: {request.attempt}",
        f"Execution branch: {plan.proposed_branch}",
        f"Workspace: {request.workspace}",
        "Validation expectations:",
        *(f"- {item}" for item in request.validation_expectations),
    ]
    if request.previous_failure_feedback:
        lines.extend(["", "Previous concrete failure feedback:", request.previous_failure_feedback])
    lines.extend(["", "Implement the task, inspect your changes, and report a concise summary."])
    return "\n".join(lines)


class CodexWorker(DevelopmentWorker):
    """Run one disposable Codex implementation attempt."""

    def __init__(
        self,
        runner: CommandRunner | None = None,
        git: GitAdapter | None = None,
        codex: CodexAdapter | None = None,
        timeout: float = 3600.0,
    ):
        self.runner = runner or CommandRunner()
        self.git = git or GitAdapter(self.runner)
        self.codex = codex or CodexAdapter(self.runner)
        self.timeout = timeout

    def execute(self, request: WorkerRequest) -> WorkerResult:
        prompt = build_worker_prompt(request)
        result = self.runner.run([
            self.codex.executable,
            "exec",
            "--ephemeral",
            "--json",
            "--approve-for-me",
            "-C",
            str(request.workspace),
            prompt,
        ], timeout=self.timeout)
        changed_files = self._changed_files(request.workspace)
        if isinstance(result, CommandError):
            return WorkerResult("failed", "Codex execution did not complete", error=result.message, changed_files=changed_files)
        summary = result.stdout.strip() or result.stderr.strip() or "Codex completed without a summary"
        if not result.ok:
            return WorkerResult("failed", summary, exit_code=result.returncode, changed_files=changed_files, error=result.stderr.strip() or summary)
        return WorkerResult("completed", summary, exit_code=result.returncode, changed_files=changed_files)

    def _changed_files(self, workspace: Path) -> tuple[str, ...]:
        status = self.git.repository_status(workspace)
        if not status or status.startswith("fatal:") or status.startswith("error:"):
            return ()
        files: list[str] = []
        for line in status.splitlines()[1:]:
            if len(line) >= 4:
                files.append(line[3:])
        return tuple(files)
