"""Durable diagnostics for headless HDC operation."""

from datetime import datetime, timezone
from pathlib import Path

from .paths import diagnostics_root


def write_config_error(config_file: Path | str, error: Exception) -> Path:
    """Persist a configuration error without including secret values."""
    path = diagnostics_root(config_file) / "config-error.err"
    path.parent.mkdir(parents=True, exist_ok=True)
    content = "\n".join([
        "HDC CONFIG ERROR",
        f"time: {datetime.now(timezone.utc).isoformat()}",
        f"config: {Path(config_file)}",
        "category: configuration_validation",
        f"message: {error}",
        "",
    ])
    path.write_text(content, encoding="utf-8")
    return path
