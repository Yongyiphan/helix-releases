"""Conservative TaskPacket-to-GitHub issue reconciliation."""

from dataclasses import dataclass
import re
from typing import Literal, Sequence

from .github import GitHubIssue
from .task_packets import IssueReference, TaskPacket

ReconciliationStatus = Literal["LINKED", "POTENTIAL_OVERLAP", "UNMATCHED"]


@dataclass(frozen=True)
class ReconciliationDecision:
    task_id: str
    status: ReconciliationStatus
    issue: IssueReference | None = None
    overlapping_task_ids: tuple[str, ...] = ()
    reason: str = ""


def reconcile_packets(packets: Sequence[TaskPacket], issues: Sequence[GitHubIssue]) -> list[ReconciliationDecision]:
    """Return reviewable decisions without creating links or changing state."""
    decisions: list[ReconciliationDecision] = []
    for packet in sorted(packets, key=lambda item: item.id):
        explicit = next((reference for reference in packet.github_issues if any(issue.repository == reference.repository and issue.number == reference.number for issue in issues)), None)
        if explicit:
            decisions.append(ReconciliationDecision(packet.id, "LINKED", explicit, reason="explicit packet issue reference"))
            continue
        candidates = tuple(issue for issue in issues if _overlaps(packet, issue))
        if candidates:
            first = candidates[0]
            decisions.append(ReconciliationDecision(packet.id, "POTENTIAL_OVERLAP", IssueReference(first.repository, first.number), reason="objective terms overlap issue text; human/Hermes review required"))
        else:
            decisions.append(ReconciliationDecision(packet.id, "UNMATCHED", reason="no explicit link or conservative text overlap"))
    return decisions


def _overlaps(packet: TaskPacket, issue: GitHubIssue) -> bool:
    objective = set(_terms(packet.objective))
    issue_terms = set(_terms(f"{issue.title} {issue.body}"))
    if not objective or not issue_terms:
        return False
    return packet.id in f"{issue.title} {issue.body}" or len(objective & issue_terms) >= max(3, min(len(objective), 5))


def _terms(value: str) -> list[str]:
    return [term for term in re.findall(r"[a-z0-9]+", value.casefold()) if len(term) > 2]
