"""Durable, deterministic task-packet loading and validation."""

from dataclasses import dataclass, field
from pathlib import Path
import tomllib

TASK_PACKET_FIELDS = {
    "id", "repository", "objective", "scope", "non_goals",
    "acceptance", "validation", "stop_conditions", "risk", "dependencies",
    "required_capabilities", "github_issues",
}
REQUIRED_TASK_PACKET_FIELDS = TASK_PACKET_FIELDS - {"dependencies", "required_capabilities", "github_issues"}
RISKS = {"low", "medium", "high"}


class TaskPacketError(ValueError):
    """Raised when a task packet cannot be loaded or is invalid."""


@dataclass(frozen=True)
class IssueReference:
    repository: str
    number: int


@dataclass(frozen=True)
class TaskPacket:
    id: str
    repository: str
    objective: str
    scope: list[str]
    non_goals: list[str]
    acceptance: list[str]
    validation: list[str]
    stop_conditions: list[str]
    risk: str
    dependencies: list[str] = field(default_factory=list)
    required_capabilities: list[str] = field(default_factory=list)
    github_issues: list[IssueReference] = field(default_factory=list)


def _text_list(raw: object, field: str) -> list[str]:
    if not isinstance(raw, list) or not raw or not all(isinstance(item, str) and item.strip() for item in raw):
        raise TaskPacketError(f"{field} must be a non-empty list of non-empty strings")
    return [item.strip() for item in raw]


def _parse(raw: dict[str, object], source: Path) -> TaskPacket:
    missing = REQUIRED_TASK_PACKET_FIELDS - raw.keys()
    if missing:
        raise TaskPacketError(f"{source}: missing fields: {', '.join(sorted(missing))}")
    unexpected = raw.keys() - TASK_PACKET_FIELDS
    if unexpected:
        raise TaskPacketError(f"{source}: unexpected fields: {', '.join(sorted(unexpected))}")
    for field in ("id", "repository", "objective", "risk"):
        if not isinstance(raw[field], str) or not raw[field].strip():
            raise TaskPacketError(f"{source}: {field} must be a non-empty string")
    risk = raw["risk"].strip().lower()
    if risk not in RISKS:
        raise TaskPacketError(f"{source}: risk must be one of: low, medium, high")
    dependencies = [] if "dependencies" not in raw else _dependency_list(raw["dependencies"], source)
    required_capabilities = [] if "required_capabilities" not in raw else _capability_list(raw["required_capabilities"], source)
    github_issues = [] if "github_issues" not in raw else _issue_reference_list(raw["github_issues"], source)
    return TaskPacket(
        id=raw["id"].strip(), repository=raw["repository"].strip(),
        objective=raw["objective"].strip(), scope=_text_list(raw["scope"], "scope"),
        non_goals=_text_list(raw["non_goals"], "non_goals"),
        acceptance=_text_list(raw["acceptance"], "acceptance"),
        validation=_text_list(raw["validation"], "validation"),
        stop_conditions=_text_list(raw["stop_conditions"], "stop_conditions"),
        risk=risk,
        dependencies=dependencies,
        required_capabilities=required_capabilities,
        github_issues=github_issues,
    )


def _dependency_list(raw: object, source: Path) -> list[str]:
    if not isinstance(raw, list) or not all(isinstance(item, str) and item.strip() for item in raw):
        raise TaskPacketError(f"{source}: dependencies must be a list of non-empty strings")
    dependencies = [item.strip() for item in raw]
    for dependency in dependencies:
        if Path(dependency).name != dependency or dependency.endswith(".toml"):
            raise TaskPacketError(f"{source}: invalid dependency ID: {dependency!r}")
    if len(set(dependencies)) != len(dependencies):
        raise TaskPacketError(f"{source}: dependencies must not contain duplicates")
    return dependencies


def _capability_list(raw: object, source: Path) -> list[str]:
    if not isinstance(raw, list) or not all(isinstance(item, str) and item.strip() for item in raw):
        raise TaskPacketError(f"{source}: required_capabilities must be a list of non-empty strings")
    capabilities = [item.strip() for item in raw]
    if len(set(capabilities)) != len(capabilities):
        raise TaskPacketError(f"{source}: required_capabilities must not contain duplicates")
    return capabilities


def _issue_reference_list(raw: object, source: Path) -> list[IssueReference]:
    if not isinstance(raw, list):
        raise TaskPacketError(f"{source}: github_issues must be an array of tables")
    references = []
    for item in raw:
        if not isinstance(item, dict) or not isinstance(item.get("repository"), str) or not item["repository"].strip():
            raise TaskPacketError(f"{source}: each github_issues entry needs a repository")
        number = item.get("number")
        if isinstance(number, bool) or not isinstance(number, int) or number <= 0:
            raise TaskPacketError(f"{source}: each github_issues entry needs a positive number")
        references.append(IssueReference(item["repository"].strip(), number))
    if len(set(references)) != len(references):
        raise TaskPacketError(f"{source}: github_issues must not contain duplicates")
    return references


def load_task_packet(path: Path | str, repository_names: set[str] | None = None) -> TaskPacket:
    """Load and validate one TOML packet, optionally checking its repository."""
    source = Path(path)
    try:
        with source.open("rb") as handle:
            raw = tomllib.load(handle)
    except FileNotFoundError as exc:
        raise TaskPacketError(f"task packet not found: {source}") from exc
    except tomllib.TOMLDecodeError as exc:
        raise TaskPacketError(f"{source}: malformed TOML: {exc}") from exc
    if not isinstance(raw, dict):
        raise TaskPacketError(f"{source}: packet must be a TOML table")
    packet = _parse(raw, source)
    if repository_names is not None and packet.repository not in repository_names:
        raise TaskPacketError(f"{source}: unknown repository: {packet.repository}")
    return packet


def task_packet_path(tasks_dir: Path | str, task_id: str) -> Path:
    """Return the conventional path for a task ID without allowing path traversal."""
    if not task_id or Path(task_id).name != task_id or task_id.endswith(".toml"):
        raise TaskPacketError(f"invalid task ID: {task_id!r}")
    root = Path(tasks_dir)
    packet = root / f"{task_id}.toml"
    example = root / "examples" / f"{task_id}.toml"
    return packet if packet.is_file() else example


def list_task_packets(tasks_dir: Path | str, repository_names: set[str] | None = None) -> list[TaskPacket]:
    """Load all packet files below the task directory in deterministic order."""
    directory = Path(tasks_dir)
    packets = [load_task_packet(path, repository_names) for path in sorted(directory.rglob("*.toml"))]
    validate_task_dependencies(packets)
    return packets


def validate_task_dependencies(packets: list[TaskPacket]) -> None:
    """Validate references between the packets in one task collection."""
    by_id: dict[str, TaskPacket] = {}
    for packet in packets:
        if packet.id in by_id:
            raise TaskPacketError(f"duplicate task ID: {packet.id}")
        by_id[packet.id] = packet
    for packet in packets:
        for dependency in packet.dependencies:
            if dependency == packet.id:
                raise TaskPacketError(f"task {packet.id}: self dependency")
            if dependency not in by_id:
                raise TaskPacketError(f"task {packet.id}: unknown dependency: {dependency}")
