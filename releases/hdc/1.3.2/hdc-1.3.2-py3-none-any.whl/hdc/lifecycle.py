"""Explicit deterministic lifecycle for executable HDC tasks."""

from dataclasses import dataclass, replace
import json
from pathlib import Path
from typing import Literal
from .paths import task_state_root

TaskState = Literal["DRAFT", "READY", "CLAIMED", "RUNNING", "REVIEW", "ACCEPTANCE", "DONE", "BLOCKED"]
TASK_STATES: set[str] = {"DRAFT", "READY", "CLAIMED", "RUNNING", "REVIEW", "ACCEPTANCE", "DONE", "BLOCKED"}
TRANSITIONS: dict[str, set[str]] = {
    "DRAFT": {"READY"},
    "READY": {"DRAFT", "CLAIMED"},
    "CLAIMED": {"RUNNING", "BLOCKED"},
    "RUNNING": {"REVIEW", "BLOCKED"},
    "REVIEW": {"ACCEPTANCE", "BLOCKED"},
    "ACCEPTANCE": {"DONE", "BLOCKED"},
    "DONE": set(),
    "BLOCKED": {"DRAFT", "READY"},
}
@dataclass(frozen=True)
class TaskLifecycle:
    task_id: str
    state: TaskState = "DRAFT"

    @property
    def execution_authorized(self) -> bool:
        return self.state == "READY"

    def transition(self, state: str) -> "TaskLifecycle":
        if state not in TASK_STATES:
            raise ValueError(f"unknown task state: {state}")
        if state not in TRANSITIONS[self.state]:
            raise ValueError(f"invalid task transition: {self.state} -> {state}")
        return replace(self, state=state)


class TaskStateStore:
    def __init__(self, root: Path | str | None = None):
        self.root = Path(root) if root is not None else task_state_root()

    def load(self, task_id: str) -> TaskLifecycle:
        path = self._path(task_id)
        if not path.is_file():
            return TaskLifecycle(task_id)
        raw = json.loads(path.read_text(encoding="utf-8"))
        lifecycle = TaskLifecycle(raw["task_id"], raw["state"])
        if lifecycle.task_id != task_id or lifecycle.state not in TASK_STATES:
            raise ValueError(f"invalid task state record: {path}")
        return lifecycle

    def save(self, lifecycle: TaskLifecycle) -> None:
        self.root.mkdir(parents=True, exist_ok=True)
        self._path(lifecycle.task_id).write_text(json.dumps({"task_id": lifecycle.task_id, "state": lifecycle.state}, indent=2) + "\n", encoding="utf-8")

    def transition(self, task_id: str, state: str) -> TaskLifecycle:
        lifecycle = self.load(task_id).transition(state)
        self.save(lifecycle)
        return lifecycle

    def _path(self, task_id: str) -> Path:
        if not task_id or Path(task_id).name != task_id:
            raise ValueError(f"invalid task ID: {task_id!r}")
        return self.root / f"{task_id}.json"
