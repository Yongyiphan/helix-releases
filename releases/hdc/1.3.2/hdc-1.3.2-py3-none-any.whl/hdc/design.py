"""Interactive Hermes Architect design workflow."""

from dataclasses import replace
from pathlib import Path
import uuid
from typing import Callable

from .architect import Architect, ArchitectRequest, ArchitectResult
from .config import Config
from .design_context import DesignContextBuilder
from .design_sessions import DesignSession, DesignSessionStore, write_draft_tasks
from .task_packets import TaskPacketError


class DesignError(RuntimeError):
    pass


def run_design(
    config: Config,
    *,
    user_request: str | None = None,
    design_id: str | None = None,
    issue_context: str | None = None,
    architect: Architect,
    context_builder: DesignContextBuilder,
    session_store: DesignSessionStore,
    tasks_dir: Path,
    input_fn: Callable[[str], str] = input,
    output_fn: Callable[[str], None] = print,
) -> DesignSession:
    if design_id:
        session = session_store.load(design_id)
    else:
        request_text = (user_request or input_fn("Describe the Helix feature you want: ")).strip()
        if not request_text:
            raise DesignError("a non-empty feature request is required")
        design_id = f"design-{uuid.uuid4().hex[:12]}"
        session = session_store.create(design_id, request_text, tuple(config.repositories))
    if issue_context:
        session = replace(session, relevant_issues=(issue_context,))
        session_store.save(session)

    for _ in range(8):
        context = context_builder.build(config, session.user_request, tasks_dir=tasks_dir)
        result = architect.design(ArchitectRequest(session.design_id, session.user_request, context, session.answers, issue_context))
        session = session_store.save_result(session, result)
        if result.status == "NEEDS_INPUT":
            for question in result.questions:
                answer = input_fn(f"{question}\nAnswer: ").strip()
                session = replace(session, answers=(*session.answers, answer))
            session_store.save(session)
            continue
        if result.status == "BLOCKED":
            output_fn(f"Design blocked: {result.error or result.summary}")
            return session
        packets = []
        try:
            for proposed in result.proposed_tasks:
                packets.append((proposed.to_task_packet(set(config.repositories)), proposed))
            proposed_ids = {proposed.id for _, proposed in packets}
            packets = [
                (replace(packet, dependencies=[dependency for dependency in proposed.dependencies if dependency in proposed_ids]), proposed)
                for packet, proposed in packets
            ]
            for _, proposed in packets:
                if proposed.id in proposed.dependencies:
                    raise TaskPacketError(f"proposed task {proposed.id}: self dependency")
                for dependency in proposed.dependencies:
                    if dependency not in proposed_ids:
                        output_fn(f"  external dependency: {dependency}")
        except TaskPacketError as exc:
            session = replace(session, status="BLOCKED")
            session_store.save(session)
            raise DesignError(str(exc)) from exc
        output_fn(result.summary)
        for packet, proposed in packets:
            output_fn(f"DRAFT {packet.id} [{packet.repository}]: {packet.objective}")
            if proposed.dependencies:
                output_fn(f"  depends_on: {', '.join(proposed.dependencies)}")
        confirmation = input_fn("Write these tasks as DRAFT packets? [y/N] ").strip().lower()
        if confirmation not in {"y", "yes"}:
            session = replace(session, status="CANCELLED")
            session_store.save(session)
            return session
        tasks_dir.mkdir(parents=True, exist_ok=True)
        write_draft_tasks(tasks_dir, tuple(packets))
        session = replace(session, status="DRAFTED")
        session_store.save(session)
        output_fn("Draft TaskPackets written. Human approval is still required before READY.")
        return session
    raise DesignError("design session exceeded the bounded clarification turn limit")
