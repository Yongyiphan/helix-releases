"""Linux-first queued HDC release discovery and update state."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import shutil
import uuid
import time
import threading
from typing import Callable, Literal

from .github import GitHubError, GitHubTransport


class UpdateError(RuntimeError):
    """Raised when a queued HDC release is invalid or cannot be staged."""


UpdateAction = Literal["none", "failed", "restart"]


@dataclass(frozen=True)
class ReleaseCandidate:
    version: str
    artifact: Path
    sha256: str


@dataclass(frozen=True)
class UpdateDecision:
    action: UpdateAction
    version: str = ""
    detail: str = ""


@dataclass(frozen=True)
class RemoteRelease:
    version: str
    tag: str
    asset_name: str
    download_url: str
    expected_sha256: str | None = None


def version_from_wheel(artifact: Path | str) -> str:
    name = Path(artifact).name
    match = re.match(r"^hdc-(?P<version>[0-9]+(?:\.[0-9]+)*)-[^/]+\.whl$", name)
    if not match:
        raise UpdateError(f"unsupported HDC wheel name: {name}")
    return match.group("version")


def version_key(version: str) -> tuple[int, ...]:
    try:
        parts = tuple(int(part) for part in version.split("."))
    except ValueError as exc:
        raise UpdateError(f"invalid HDC release version: {version}") from exc
    if not parts:
        raise UpdateError(f"invalid HDC release version: {version}")
    return parts


class GitHubReleaseSource:
    """Discover and download the authoritative HDC release from GitHub."""

    def __init__(self, transport: GitHubTransport, repository: str):
        self.transport = transport
        self.repository = repository

    def discover(self, current_version: str = "") -> RemoteRelease:
        response = self.transport.request("GET", f"/repos/{self.repository}/releases/latest")
        latest = self._release_from_response(response, "GitHub latest release")
        if not current_version or version_key(latest.version) > version_key(current_version):
            return latest

        # GitHub's /releases/latest is metadata-driven and may point to an
        # older release. Enumerate published releases and choose the highest
        # compatible HDC version instead of trusting that label.
        response = self.transport.request("GET", f"/repos/{self.repository}/releases?per_page=100")
        if not isinstance(response, list):
            raise GitHubError("GitHub releases response must be a list")
        candidates = []
        for item in response:
            if not isinstance(item, dict) or item.get("draft") is True:
                continue
            try:
                candidates.append(self._release_from_response(item, "GitHub release"))
            except GitHubError:
                continue
        newer = [item for item in candidates if version_key(item.version) > version_key(current_version)]
        if not newer:
            return latest
        return max(newer, key=lambda item: version_key(item.version))

    def _release_from_response(self, response: object, description: str) -> RemoteRelease:
        if not isinstance(response, dict):
            raise GitHubError(f"{description} response must be an object")
        tag = response.get("tag_name")
        if not isinstance(tag, str) or not tag.strip():
            raise GitHubError(f"{description} has no tag_name")
        version = _version_from_tag(tag)
        assets = response.get("assets")
        if not isinstance(assets, list):
            raise GitHubError(f"{description} assets must be a list")
        wheels = [
            asset for asset in assets
            if isinstance(asset, dict)
            and isinstance(asset.get("name"), str)
            and asset["name"].startswith(f"hdc-{version}-")
            and asset["name"].endswith(".whl")
            and (isinstance(asset.get("url"), str) or isinstance(asset.get("browser_download_url"), str))
        ]
        if not wheels:
            raise GitHubError(f"GitHub release {tag} has no HDC wheel asset")
        asset = sorted(wheels, key=lambda item: item["name"])[0]
        digest = asset.get("digest")
        expected_sha256 = None
        if isinstance(digest, str) and digest.startswith("sha256:"):
            expected_sha256 = digest.removeprefix("sha256:").lower()
            if not re.fullmatch(r"[0-9a-f]{64}", expected_sha256):
                raise GitHubError(f"GitHub release asset has invalid digest: {digest}")
        download_url = asset.get("url") or asset.get("browser_download_url")
        return RemoteRelease(version, tag.strip(), asset["name"], download_url, expected_sha256)

    def fetch_into_queue(self, queue: "LinuxUpdateQueue", current_version: str) -> ReleaseCandidate | None:
        release = self.discover(current_version)
        if version_key(release.version) <= version_key(current_version):
            return None
        for artifact in queue.incoming.glob("*.whl"):
            try:
                if version_from_wheel(artifact) == release.version:
                    return None
            except UpdateError:
                continue
        queue.root.mkdir(parents=True, exist_ok=True)
        temporary = queue.root / f"hdc-{release.version}-remote-download.whl"
        self.transport.download(release.download_url, temporary)
        try:
            digest = hashlib.sha256(temporary.read_bytes()).hexdigest()
            if release.expected_sha256 is not None and digest != release.expected_sha256:
                raise UpdateError(
                    f"GitHub asset digest mismatch for {release.asset_name}: expected {release.expected_sha256}, got {digest}"
                )
            return queue.enqueue(temporary)
        finally:
            temporary.unlink(missing_ok=True)


def _version_from_tag(tag: str) -> str:
    normalized = tag.strip()
    if normalized.startswith("v"):
        normalized = normalized[1:]
    version_key(normalized)
    return normalized


class LinuxUpdateQueue:
    """Durable local release inbox for the deployed Linux Controller."""

    def __init__(self, state_root: Path | str):
        self.root = Path(state_root) / "updates"
        self.incoming = self.root / "incoming"
        self.processed = self.root / "processed"
        self.status_path = self.root / "status.json"
        self.seen_events_path = self.root / "seen-release-events.json"

    def enqueue(self, artifact: Path | str) -> ReleaseCandidate:
        source = Path(artifact).expanduser().resolve()
        if not source.is_file() or source.suffix != ".whl":
            raise UpdateError(f"wheel artifact does not exist: {source}")
        version = version_from_wheel(source)
        self.incoming.mkdir(parents=True, exist_ok=True)
        suffix = source.name[len(f"hdc-{version}-"):]
        destination = self.incoming / f"hdc-{version}-{uuid.uuid4().hex[:12]}-{suffix}"
        temporary = destination.with_suffix(destination.suffix + ".new")
        shutil.copy2(source, temporary)
        temporary.replace(destination)
        return self._candidate(destination, version)

    def latest(self, current_version: str) -> ReleaseCandidate | None:
        current = version_key(current_version)
        candidates = []
        if self.incoming.exists():
            for artifact in self.incoming.glob("*.whl"):
                try:
                    version = version_from_wheel(artifact.name)
                except UpdateError:
                    continue
                if version_key(version) > current:
                    candidates.append(self._candidate(artifact, version))
        if not candidates:
            return None
        return max(candidates, key=lambda item: (version_key(item.version), item.artifact.name))

    def mark_processed(self, candidate: ReleaseCandidate) -> Path:
        self.processed.mkdir(parents=True, exist_ok=True)
        destination = self.processed / candidate.artifact.name
        candidate.artifact.replace(destination)
        return destination

    def archive_superseded(self, version: str) -> int:
        """Move queued releases at or below the applied release out of the inbox."""
        moved = 0
        if not self.incoming.exists():
            return moved
        self.processed.mkdir(parents=True, exist_ok=True)
        for artifact in self.incoming.glob("*.whl"):
            try:
                queued_version = version_from_wheel(artifact)
            except UpdateError:
                continue
            if version_key(queued_version) <= version_key(version):
                artifact.replace(self.processed / artifact.name)
                moved += 1
        return moved

    def read_status(self) -> dict[str, object]:
        if not self.status_path.exists():
            return {}
        try:
            value = json.loads(self.status_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            raise UpdateError(f"invalid update status: {self.status_path}") from exc
        if not isinstance(value, dict):
            raise UpdateError(f"update status must be an object: {self.status_path}")
        return value

    def write_status(self, value: dict[str, object]) -> None:
        self.root.mkdir(parents=True, exist_ok=True)
        temporary = self.status_path.with_suffix(".json.new")
        temporary.write_text(json.dumps(value, sort_keys=True, indent=2) + "\n", encoding="utf-8")
        temporary.replace(self.status_path)

    def event_seen(self, event_id: str) -> bool:
        return event_id in self._read_seen_events()

    def remember_event(self, event_id: str, *, version: str, state: str) -> None:
        events = self._read_seen_events()
        events[event_id] = {
            "version": version,
            "state": state,
            "updated_at": datetime.now(timezone.utc).isoformat(),
        }
        self.root.mkdir(parents=True, exist_ok=True)
        temporary = self.seen_events_path.with_suffix(".json.new")
        temporary.write_text(json.dumps(events, sort_keys=True, indent=2) + "\n", encoding="utf-8")
        temporary.replace(self.seen_events_path)

    def _read_seen_events(self) -> dict[str, dict[str, object]]:
        if not self.seen_events_path.exists():
            return {}
        try:
            raw = json.loads(self.seen_events_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            raise UpdateError(f"invalid release event history: {self.seen_events_path}") from exc
        if not isinstance(raw, dict) or not all(isinstance(key, str) and isinstance(value, dict) for key, value in raw.items()):
            raise UpdateError(f"release event history must be an object: {self.seen_events_path}")
        return raw

    @staticmethod
    def _candidate(artifact: Path, version: str) -> ReleaseCandidate:
        return ReleaseCandidate(version, artifact, hashlib.sha256(artifact.read_bytes()).hexdigest())


class LinuxAutoUpdater:
    """Apply one queued release, then ask the service manager to restart HDC."""

    def __init__(
        self,
        state_root: Path | str,
        current_version: str,
        install: Callable[[Path], Path],
        restart: Callable[[], bool],
        controller_id: str,
        refresh: Callable[[], ReleaseCandidate | None] | None = None,
        refresh_interval_seconds: int = 300,
        on_release: Callable[[ReleaseCandidate], None] | None = None,
    ):
        self.queue = LinuxUpdateQueue(state_root)
        self.current_version = current_version
        self.install = install
        self.restart = restart
        self.controller_id = controller_id
        self.refresh = refresh
        self.refresh_interval_seconds = refresh_interval_seconds
        self.on_release = on_release
        self._last_refresh = 0.0
        self._refresh_requested = True
        self._peer_hint = False
        self._check_lock = threading.Lock()

    def accept_release_hint(self, announcement: object) -> dict[str, object]:
        """Record one event and decide whether it should wake and propagate."""
        event_id = getattr(announcement, "event_id", "") or ""
        version = getattr(announcement, "version", "") or ""
        if not event_id or not version:
            return {"status": "ignored", "reason": "invalid_event"}
        if self.queue.event_seen(event_id):
            return {"status": "duplicate", "event_id": event_id, "version": version}
        self.queue.remember_event(event_id, version=version, state="received")
        try:
            target = version_key(version)
        except UpdateError:
            return {"status": "ignored", "event_id": event_id, "version": version, "reason": "invalid_version"}
        if target <= version_key(self.current_version):
            self.queue.remember_event(event_id, version=version, state="ignored_latest")
            return {"status": "ignored", "event_id": event_id, "version": version, "reason": "already_latest"}
        queued = self.queue.latest(self.current_version)
        if queued is not None and version_key(queued.version) >= target:
            self.queue.remember_event(event_id, version=version, state="ignored_queued")
            return {"status": "ignored", "event_id": event_id, "version": version, "reason": "already_queued"}
        if self._check_lock.locked():
            self.queue.remember_event(event_id, version=version, state="busy")
            return {"status": "checking", "event_id": event_id, "version": version, "forward": False}
        self.notify_release()
        self.queue.remember_event(event_id, version=version, state="checking")
        return {"status": "checking", "event_id": event_id, "version": version, "forward": True}

    def notify_release(self) -> None:
        """Request an immediate authoritative release check after a peer hint."""
        self._refresh_requested = True
        self._peer_hint = True

    def check_and_apply(self) -> UpdateDecision:
        if not self._check_lock.acquire(blocking=False):
            return UpdateDecision("none", detail="release check already in progress")
        try:
            return self._check_and_apply()
        finally:
            self._check_lock.release()

    def _check_and_apply(self) -> UpdateDecision:
        now = time.monotonic()
        if self.refresh is not None and (self._refresh_requested or now - self._last_refresh >= self.refresh_interval_seconds):
            from_peer_hint = self._peer_hint
            self._refresh_requested = False
            self._peer_hint = False
            self._last_refresh = now
            try:
                downloaded = self.refresh()
                if downloaded is not None and self.on_release is not None and not from_peer_hint:
                    self.on_release(downloaded)
            except Exception as exc:
                message = str(exc)
                # GitHub returns 404 when a repository has not published its
                # first release yet. That is a valid bootstrap state, not a
                # broken updater; continue polling and keep the distinction
                # visible in durable status.
                state = "waiting_for_release" if "Not Found" in message or "404" in message else "discovery_failed"
                self.queue.write_status({
                    "controller_id": self.controller_id,
                    "state": state,
                    "current_version": self.current_version,
                    "error": None if state == "waiting_for_release" else message,
                    "updated_at": datetime.now(timezone.utc).isoformat(),
                })
        candidate = self.queue.latest(self.current_version)
        if candidate is None:
            self._reconcile_status()
            return UpdateDecision("none")
        try:
            self.install(candidate.artifact)
        except Exception as exc:
            self.queue.write_status({
                "controller_id": self.controller_id,
                "state": "failed",
                "current_version": self.current_version,
                "desired_version": candidate.version,
                "artifact": candidate.artifact.name,
                "sha256": candidate.sha256,
                "error": str(exc),
                "updated_at": datetime.now(timezone.utc).isoformat(),
            })
            return UpdateDecision("failed", candidate.version, str(exc))
        self.queue.mark_processed(candidate)
        self.queue.archive_superseded(candidate.version)
        self.queue.write_status({
            "controller_id": self.controller_id,
            "state": "restart_requested",
            "current_version": self.current_version,
            "desired_version": candidate.version,
            "artifact": candidate.artifact.name,
            "sha256": candidate.sha256,
            "updated_at": datetime.now(timezone.utc).isoformat(),
        })
        # Persist the queue transition before asking systemd to terminate this
        # process.  A --no-block restart can replace us immediately.
        if not self.restart():
            detail = "release activated but Controller restart could not be requested"
            self.queue.write_status({
                "controller_id": self.controller_id,
                "state": "restart_failed",
                "current_version": self.current_version,
                "desired_version": candidate.version,
                "artifact": candidate.artifact.name,
                "sha256": candidate.sha256,
                "error": detail,
                "updated_at": datetime.now(timezone.utc).isoformat(),
            })
            return UpdateDecision("failed", candidate.version, detail)
        return UpdateDecision("restart", candidate.version, "release activated; restart requested")

    def _reconcile_status(self) -> None:
        """Clear stale failure state once no newer release remains queued.

        A failed status describes an earlier candidate, not the controller's
        current truth forever.  Keep discovery failures visible, but mark a
        completed/current controller explicitly so operators do not mistake an
        old record for an active failure.
        """
        status = self.queue.read_status()
        desired = status.get("desired_version")
        if not isinstance(desired, str):
            return
        try:
            if version_key(desired) > version_key(self.current_version):
                return
        except UpdateError:
            return
        if status.get("state") not in {"failed", "restart_failed", "restart_requested"}:
            return
        self.queue.write_status({
            "controller_id": self.controller_id,
            "state": "up_to_date",
            "current_version": self.current_version,
            "desired_version": self.current_version,
            "artifact": status.get("artifact"),
            "sha256": status.get("sha256"),
            "error": None,
            "updated_at": datetime.now(timezone.utc).isoformat(),
        })
