"""Shared task coordination contracts and a deterministic in-memory backend."""

from dataclasses import dataclass, replace
from datetime import datetime, timedelta, timezone
from typing import Literal, Protocol

from .identity import WorkerIdentity
from .task_packets import TaskPacket

CoordinationState = Literal[
    "DRAFT", "READY", "CLAIMED", "RUNNING", "REVIEW", "ACCEPTANCE", "ACCEPTED", "BLOCKED"
]
ACTIVE_STATES = {"CLAIMED", "RUNNING"}


def utc_now() -> datetime:
    return datetime.now(timezone.utc)


@dataclass(frozen=True)
class TaskClaim:
    task_id: str
    worker_id: str
    claimed_at: datetime
    expires_at: datetime
    version: int
    attempt: int

    def is_active(self, now: datetime) -> bool:
        return now < self.expires_at


@dataclass(frozen=True)
class ResultPublication:
    """The bounded shared summary of one worker execution."""

    run_id: str
    worker_id: str
    outcome: str
    summary: str
    branch: str = ""
    pull_request_url: str = ""
    blocked_reason: str | None = None
    integration_ready: bool = False


@dataclass(frozen=True)
class RemoteTask:
    """The coordination projection of a canonical TaskPacket."""

    task_id: str
    repository: str
    required_capabilities: tuple[str, ...] = ()
    dependencies: tuple[str, ...] = ()
    state: CoordinationState = "DRAFT"
    integration_ready: bool = False
    claim: TaskClaim | None = None
    version: int = 0
    attempt: int = 0
    result: ResultPublication | None = None


@dataclass(frozen=True)
class ClaimResult:
    acquired: bool
    claim: TaskClaim | None = None
    reason: str = ""


class CoordinationBackend(Protocol):
    def sync_task(self, packet: TaskPacket) -> bool: ...

    def authorize_task(self, task_id: str) -> bool: ...

    def discover_tasks(self, worker: WorkerIdentity, now: datetime | None = None) -> list[RemoteTask]: ...

    def claim_task(
        self, task_id: str, worker: WorkerIdentity, *, now: datetime | None = None,
        lease_seconds: int = 900,
    ) -> ClaimResult: ...

    def renew_claim(
        self, claim: TaskClaim, worker: WorkerIdentity, *, now: datetime | None = None,
        lease_seconds: int = 900,
    ) -> ClaimResult: ...

    def recover_expired_claim(self, task_id: str, *, now: datetime | None = None) -> bool: ...

    def publish_result(
        self, task_id: str, claim: TaskClaim, worker: WorkerIdentity, result: ResultPublication,
        *, now: datetime | None = None,
    ) -> bool: ...


def _dependencies_ready(task: RemoteTask, tasks: dict[str, RemoteTask]) -> bool:
    return all(
        (dependency := tasks.get(dependency_id)) is not None
        and dependency.state == "ACCEPTED"
        and dependency.integration_ready
        for dependency_id in task.dependencies
    )


def _routable(task: RemoteTask, worker: WorkerIdentity, tasks: dict[str, RemoteTask], now: datetime) -> bool:
    return (
        task.state == "READY"
        and worker.owns_repository(task.repository)
        and worker.supports(task.required_capabilities)
        and _dependencies_ready(task, tasks)
        and (task.claim is None or not task.claim.is_active(now))
    )


class InMemoryCoordinationBackend:
    """Fake shared backend used by tests and local coordination experiments."""

    def __init__(self, tasks: list[RemoteTask] | None = None):
        self._tasks = {task.task_id: task for task in tasks or []}

    def register(self, task: RemoteTask) -> None:
        if task.task_id in self._tasks:
            raise ValueError(f"duplicate coordination task: {task.task_id}")
        self._tasks[task.task_id] = task

    def sync_task(self, packet: TaskPacket) -> bool:
        current = self._tasks.get(packet.id)
        if current is None:
            self._tasks[packet.id] = RemoteTask(
                packet.id, packet.repository, tuple(packet.required_capabilities), tuple(packet.dependencies),
            )
            return True
        if current.claim is not None or current.state in ACTIVE_STATES:
            if current.repository != packet.repository or current.required_capabilities != tuple(packet.required_capabilities) or current.dependencies != tuple(packet.dependencies):
                return False
        self._tasks[packet.id] = replace(
            current,
            repository=packet.repository,
            required_capabilities=tuple(packet.required_capabilities),
            dependencies=tuple(packet.dependencies),
            version=current.version + 1,
        )
        return True

    def authorize_task(self, task_id: str) -> bool:
        task = self.get_task(task_id)
        if task.state != "DRAFT" or task.claim is not None or task.result is not None:
            return False
        self._tasks[task_id] = replace(task, state="READY", version=task.version + 1)
        return True

    def get_task(self, task_id: str) -> RemoteTask:
        try:
            return self._tasks[task_id]
        except KeyError as exc:
            raise KeyError(f"unknown coordination task: {task_id}") from exc

    def set_state(self, task_id: str, state: CoordinationState, *, integration_ready: bool = False) -> None:
        task = self.get_task(task_id)
        self._tasks[task_id] = replace(task, state=state, integration_ready=integration_ready, version=task.version + 1)

    def discover_tasks(self, worker: WorkerIdentity, now: datetime | None = None) -> list[RemoteTask]:
        current = now or utc_now()
        self._recover_all(current)
        return [
            task for task in sorted(self._tasks.values(), key=lambda item: item.task_id)
            if _routable(task, worker, self._tasks, current)
        ]

    def claim_task(
        self, task_id: str, worker: WorkerIdentity, *, now: datetime | None = None,
        lease_seconds: int = 900,
    ) -> ClaimResult:
        current = now or utc_now()
        self._recover_all(current)
        task = self.get_task(task_id)
        if not _routable(task, worker, self._tasks, current):
            return ClaimResult(False, reason="task is not READY, routable, or dependency-complete")
        claim = TaskClaim(task_id, worker.worker_id, current, current + timedelta(seconds=lease_seconds), task.version + 1, task.attempt + 1)
        self._tasks[task_id] = replace(task, state="CLAIMED", claim=claim, version=claim.version, attempt=claim.attempt)
        return ClaimResult(True, claim, "claimed")

    def renew_claim(
        self, claim: TaskClaim, worker: WorkerIdentity, *, now: datetime | None = None,
        lease_seconds: int = 900,
    ) -> ClaimResult:
        current = now or utc_now()
        self._recover_all(current)
        task = self.get_task(claim.task_id)
        if task.claim != claim or claim.worker_id != worker.worker_id:
            return ClaimResult(False, reason="claim is not owned by this worker")
        renewed = TaskClaim(claim.task_id, worker.worker_id, claim.claimed_at, current + timedelta(seconds=lease_seconds), task.version + 1, claim.attempt)
        self._tasks[task.task_id] = replace(task, claim=renewed, version=renewed.version)
        return ClaimResult(True, renewed, "renewed")

    def recover_expired_claim(self, task_id: str, *, now: datetime | None = None) -> bool:
        current = now or utc_now()
        task = self.get_task(task_id)
        if task.claim is None or task.claim.is_active(current):
            return False
        self._tasks[task_id] = replace(task, state="READY", claim=None, version=task.version + 1)
        return True

    def publish_result(self, task_id: str, claim: TaskClaim, worker: WorkerIdentity, result: ResultPublication, *, now: datetime | None = None) -> bool:
        task = self.get_task(task_id)
        if task.claim != claim or claim.worker_id != worker.worker_id or not claim.is_active(now or utc_now()):
            return False
        state: CoordinationState = "ACCEPTED" if result.integration_ready else ("REVIEW" if result.outcome == "completed" else "BLOCKED")
        self._tasks[task_id] = replace(task, state=state, integration_ready=result.integration_ready, claim=None, result=result, version=task.version + 1)
        return True

    def _recover_all(self, now: datetime) -> None:
        for task_id in list(self._tasks):
            self.recover_expired_claim(task_id, now=now)
