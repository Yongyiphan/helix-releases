"""Build HDC release artifacts from the development checkout."""

from pathlib import Path
import os
import shutil
import sys

from .process import CommandRunner, CommandError


class PackagingError(RuntimeError):
    pass


def build_wheel(output: Path, *, runner: CommandRunner | None = None) -> tuple[Path, ...]:
    """Build a wheel without including the Git checkout or development files."""
    output = Path(output)
    output.mkdir(parents=True, exist_ok=True)
    # The release shell helper historically selected the newest wheel by mtime.
    # Remove only generated HDC wheels first so an older artifact cannot win when
    # a build is performed as a different user or after a failed release.
    for artifact in output.glob("hdc-*.whl"):
        if artifact.is_symlink() or not artifact.is_file():
            raise PackagingError(f"refusing to remove unsafe wheel artifact: {artifact}")
        artifact.unlink()
    # Setuptools reuses build/lib between invocations. Remove it so deleted
    # modules from an older checkout cannot leak into the new wheel.
    build_root = Path.cwd() / "build"
    if build_root.exists() and not os.access(build_root, os.W_OK):
        # Release helpers build as the service user. A previous privileged
        # build may leave an unreadable checkout build tree behind; isolate
        # this build rather than requiring ownership changes in the checkout.
        import tempfile
        with tempfile.TemporaryDirectory(prefix="hdc-package-") as temporary:
            source_copy = Path(temporary) / "source"
            shutil.copytree(
                Path.cwd(), source_copy,
                ignore=shutil.ignore_patterns(".git", ".venv", "build", "dist", ".hdc"),
            )
            return _build_wheel(source_copy, output, runner=runner)
    if build_root.exists():
        if build_root.is_symlink() or (hasattr(build_root, "is_junction") and build_root.is_junction()) or build_root.resolve().parent != Path.cwd().resolve():
            raise PackagingError("Refusing to clean a build directory outside the checkout")
        shutil.rmtree(build_root)
    return _build_wheel(Path.cwd(), output, runner=runner)


def _build_wheel(source_root: Path, output: Path, *, runner: CommandRunner | None = None) -> tuple[Path, ...]:
    result = (runner or CommandRunner()).run(
        (sys.executable, "-m", "pip", "wheel", str(source_root), "--no-deps", "--no-build-isolation", "--wheel-dir", str(output)),
        cwd=source_root,
        timeout=300,
    )
    if isinstance(result, CommandError) or not result.ok:
        detail = result.message if isinstance(result, CommandError) else (result.stderr.strip() or result.stdout.strip())
        raise PackagingError(f"wheel build failed: {detail}")
    wheels = tuple(sorted(output.glob("hdc-*.whl"), key=lambda path: path.stat().st_mtime))
    if not wheels:
        raise PackagingError(f"wheel build completed without an artifact in {output}")
    return (wheels[-1],)
