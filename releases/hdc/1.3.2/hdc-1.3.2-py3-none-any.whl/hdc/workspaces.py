"""Safe Git worktree lifecycle for authorized HDC execution plans."""

from dataclasses import dataclass
from pathlib import Path

from .adapters import CommandError, CommandResult, GitAdapter
from .execution_plan import ExecutionPlan


class WorkspaceError(RuntimeError):
    """Raised when a workspace operation cannot be safely completed."""


@dataclass(frozen=True)
class WorkspaceInfo:
    task_id: str
    path: Path
    branch: str | None
    status: str | None


class WorkspaceManager:
    def __init__(self, root: Path | str | None = None, git: GitAdapter | None = None):
        self.root = Path(root) if root is not None else Path.cwd() / "workspaces"
        self.git = git or GitAdapter()

    def list(self) -> list[WorkspaceInfo]:
        if not self.root.is_dir():
            return []
        workspaces: list[WorkspaceInfo] = []
        for path in sorted(self.root.iterdir()):
            if not path.is_dir():
                continue
            branch = self.git.current_branch(path)
            status = self.git.repository_status(path) if branch else None
            workspaces.append(WorkspaceInfo(path.name, path, branch, status))
        return workspaces

    def inspect(self, task_id: str) -> WorkspaceInfo:
        target = self._target(task_id)
        if not target.is_dir():
            raise WorkspaceError(f"workspace not found: {target}")
        if not self.git.repository_valid(target):
            raise WorkspaceError(f"workspace is not a Git worktree: {target}")
        return WorkspaceInfo(task_id, target, self.git.current_branch(target), self.git.repository_status(target))

    def create(self, plan: ExecutionPlan) -> WorkspaceInfo:
        if not plan.execution_permitted:
            reason = "; ".join(plan.denial_reasons) or "execution is not permitted"
            raise WorkspaceError(f"workspace creation denied: {reason}")
        target = self._target(plan.task_id)
        if target != plan.proposed_workspace:
            raise WorkspaceError("execution plan workspace is outside the configured workspace root")
        if target.exists():
            raise WorkspaceError(f"workspace already exists: {target}")
        self.root.mkdir(parents=True, exist_ok=True)
        result = self.git.create_worktree(plan.repository_path, target, plan.proposed_branch, plan.base_branch)
        if isinstance(result, CommandError) or not result.ok:
            detail = result.message if isinstance(result, CommandError) else result.stderr.strip()
            raise WorkspaceError(f"Git worktree creation failed: {detail or 'unknown error'}")
        return self.inspect(plan.task_id)

    def _target(self, task_id: str) -> Path:
        if not task_id or Path(task_id).name != task_id or task_id in {".", ".."}:
            raise WorkspaceError(f"invalid task ID: {task_id!r}")
        target = self.root / task_id
        if target.parent.resolve() != self.root.resolve():
            raise WorkspaceError("workspace path escapes the configured workspace root")
        return target
