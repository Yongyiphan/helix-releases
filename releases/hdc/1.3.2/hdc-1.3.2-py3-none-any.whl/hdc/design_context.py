"""Bounded deterministic context gathering for Hermes Architect sessions."""

from dataclasses import dataclass
from pathlib import Path

from .config import Config
from .process import CommandRunner
from .task_packets import list_task_packets


@dataclass(frozen=True)
class DesignContextBuilder:
    runner: CommandRunner | None = None
    max_chars: int = 12000

    def build(self, config: Config, request: str, *, tasks_dir: Path, graphify_executable: str = "graphify") -> str:
        sections = [
            "Worker identity:",
            f"- id={config.worker.identity.worker_id} platform={config.worker.identity.platform} "
            f"capabilities={list(config.worker.identity.capabilities)}",
            "Architect capability rule: required_capabilities must be chosen from the advertised capabilities above; "
            "do not invent or paraphrase capability names.",
            "",
            "Repositories:",
        ]
        for repo in config.repositories.values():
            branch = repo.base_branch or config.worker.base_branch
            sections.append(
                f"- {repo.name}: hosted={str(repo.path is not None).lower()} read_only={str(repo.read_only).lower()} "
                f"graphify={str(repo.graphify).lower()} base_branch={branch}"
            )
        sections.append("\nArchitecture documents:")
        for name in ("README.md", "docs/HDC_CANONICAL_SPEC.md"):
            path = config.source.parent / name
            if path.is_file():
                sections.append(f"[{name}]\n{path.read_text(encoding='utf-8')[:2500]}")
        sections.append("\nExisting task packets:")
        try:
            sections.extend(f"- {packet.id}: {packet.repository} — {packet.objective}" for packet in list_task_packets(tasks_dir, set(config.repositories)))
        except Exception as exc:
            sections.append(f"- task inspection unavailable: {exc}")
        graph = self._graphify(request, graphify_executable)
        if graph:
            sections.append(f"\nGraphify query evidence:\n{graph}")
        return "\n".join(sections)[: self.max_chars]

    def _graphify(self, request: str, executable: str) -> str:
        runner = self.runner or CommandRunner()
        result = runner.run([executable, "query", request, "--budget", "1000"], timeout=30.0)
        if hasattr(result, "ok") and result.ok:
            return result.stdout[:3500]
        return ""
