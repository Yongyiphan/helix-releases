"""Windows SCM adapter. Imported lazily so Linux never requires pywin32."""

import json
import contextlib
import logging
from logging.handlers import RotatingFileHandler
import os
from pathlib import Path
import sys

SERVICE_NAME = "HelixHDC"


class LogStream:
    """Send controller CLI output to the same rotated service log."""

    def __init__(self, logger, level):
        self.logger, self.level = logger, level

    def write(self, value):
        for line in value.splitlines():
            if line.strip():
                self.logger.log(self.level, line.rstrip())
        return len(value)

    def flush(self):
        pass

    def isatty(self):
        return False


class WindowsServiceManager:
    def __init__(self):
        import win32service
        import win32serviceutil
        self.api = win32service
        self.util = win32serviceutil

    @contextlib.contextmanager
    def installation_lock(self):
        import win32api
        import win32event
        handle = win32event.CreateMutex(None, False, "Global\\HelixHDC.Install")
        acquired = False
        try:
            acquired = win32event.WaitForSingleObject(handle, 0) in (0, 128)
            if not acquired:
                raise RuntimeError("Another HDC installation or maintenance operation is running")
            yield
        finally:
            if acquired:
                win32event.ReleaseMutex(handle)
            win32api.CloseHandle(handle)

    def configuration(self):
        manager = self.api.OpenSCManager(None, None, self.api.SC_MANAGER_CONNECT)
        try:
            try:
                service = self.api.OpenService(manager, SERVICE_NAME, self.api.SERVICE_QUERY_CONFIG)
            except Exception as exc:
                if getattr(exc, "winerror", None) == 1060:
                    return None
                raise
            try:
                return self.api.QueryServiceConfig(service)
            finally:
                self.api.CloseServiceHandle(service)
        finally:
            self.api.CloseServiceHandle(manager)

    def configure(self, python, settings, account=None, password=None):
        import subprocess
        command = subprocess.list2cmdline([str(python), "-I", "-m", "hdc.windows_service", str(settings)])
        manager = self.api.OpenSCManager(None, None, self.api.SC_MANAGER_ALL_ACCESS)
        try:
            if self.configuration() is None:
                if not account:
                    raise ValueError("A service account is required for first installation")
                service = self.api.CreateService(
                    manager, SERVICE_NAME, "Helix HDC Controller", self.api.SERVICE_ALL_ACCESS,
                    self.api.SERVICE_WIN32_OWN_PROCESS, self.api.SERVICE_AUTO_START,
                    self.api.SERVICE_ERROR_NORMAL, command, None, 0, None, account, password,
                )
            else:
                service = self.api.OpenService(manager, SERVICE_NAME, self.api.SERVICE_ALL_ACCESS)
                self.api.ChangeServiceConfig(service, self.api.SERVICE_NO_CHANGE,
                    self.api.SERVICE_AUTO_START, self.api.SERVICE_NO_CHANGE,
                    command, None, 0, None, None, None, "Helix HDC Controller")
            try:
                self.api.ChangeServiceConfig2(service, self.api.SERVICE_CONFIG_DELAYED_AUTO_START_INFO, True)
                self.api.ChangeServiceConfig2(service, self.api.SERVICE_CONFIG_FAILURE_ACTIONS,
                    {"ResetPeriod": 86400, "RebootMsg": "", "Command": "",
                     "Actions": [(self.api.SC_ACTION_RESTART, 10000)] * 3})
            finally:
                self.api.CloseServiceHandle(service)
        finally:
            self.api.CloseServiceHandle(manager)

    @staticmethod
    def validate_credentials(account, password):
        """Validate the same logon type SCM needs without starting any process."""
        import win32security
        domain, username = account.split("\\", 1) if "\\" in account else (None, account)
        try:
            token = win32security.LogonUser(username, domain, password,
                win32security.LOGON32_LOGON_SERVICE, win32security.LOGON32_PROVIDER_DEFAULT)
        except Exception as exc:
            code = getattr(exc, "winerror", None)
            explanations = {
                1326: "Windows rejected the account name or password. Use the account password, not a Windows Hello PIN. For a Microsoft-linked account, verify that password sign-in works on this PC before retrying.",
                1385: "Windows denied service logon. Check both Log on as a service and Deny log on as a service policies.",
                1330: "The service account password has expired.",
                1331: "The service account is disabled.",
                1909: "The service account is locked. Resolve the lockout before retrying.",
            }
            raise RuntimeError(explanations.get(code, f"Windows service-logon validation failed (error {code}).")) from None
        else:
            token.Close()

    def stop(self):
        if self.configuration() is None:
            return
        try:
            self.util.StopService(SERVICE_NAME)
        except Exception as exc:
            if getattr(exc, "winerror", None) != 1062:
                raise
        self.util.WaitForServiceStatus(SERVICE_NAME, self.api.SERVICE_STOPPED, 60)

    def start(self):
        self.util.StartService(SERVICE_NAME)
        self.util.WaitForServiceStatus(SERVICE_NAME, self.api.SERVICE_RUNNING, 60)

    def process_id(self):
        manager = self.api.OpenSCManager(None, None, self.api.SC_MANAGER_CONNECT)
        try:
            service = self.api.OpenService(manager, SERVICE_NAME, self.api.SERVICE_QUERY_STATUS)
            try:
                return self.api.QueryServiceStatusEx(service)["ProcessId"]
            finally:
                self.api.CloseServiceHandle(service)
        finally:
            self.api.CloseServiceHandle(manager)

    def remove(self):
        self.stop()
        if self.configuration() is not None:
            self.util.RemoveService(SERVICE_NAME)


def grant_service_logon(account):
    import win32security
    sid, _, _ = win32security.LookupAccountName(None, account)
    policy = win32security.LsaOpenPolicy(None, win32security.POLICY_ALL_ACCESS)
    try:
        win32security.LsaAddAccountRights(policy, sid, ("SeServiceLogonRight",))
    finally:
        win32security.LsaClose(policy)


def run_service(settings_path):
    import servicemanager
    import win32service
    import win32serviceutil

    class ControllerService(win32serviceutil.ServiceFramework):
        _svc_name_ = SERVICE_NAME
        _svc_display_name_ = "Helix HDC Controller"

        def __init__(self, args):
            super().__init__(args)
            self.runtime = None
            self.stopping = False

        def SvcStop(self):
            self.stopping = True
            self.ReportServiceStatus(win32service.SERVICE_STOP_PENDING, waitHint=60000)
            if self.runtime:
                self.runtime.stop()

        def SvcDoRun(self):
            settings = json.loads(Path(settings_path).read_text(encoding="utf-8"))
            os.environ.update(settings["environment"])
            os.chdir(settings["working_directory"])
            log_path = Path(settings["log_root"]) / "controller.log"
            handler = RotatingFileHandler(log_path, maxBytes=5_000_000, backupCount=5, encoding="utf-8")
            logging.basicConfig(level=logging.INFO, handlers=[handler], force=True)
            logger = logging.getLogger("hdc.service")
            try:
                from .config import load_config
                from .controller_runtime import ControllerRuntime
                from .paths import controller_root
                from .cli import _run_controller_work_cycle
                from .peer import build_peer_context
                from .process import CommandRunner, CommandError
                result = CommandRunner().run((sys.executable, "-I", "-m", "hdc", "doctor"), timeout=120)
                if isinstance(result, CommandError) or not result.ok:
                    logger.error("Doctor: %s", result.message if isinstance(result, CommandError) else result.stdout + result.stderr)
                    raise RuntimeError("Service-account doctor failed; verify tools, repository access and authentication")
                config = load_config()
                if config.coordination and os.getenv("HDC_GITHUB_AUTH") == "gh":
                    auth = CommandRunner().run(("gh", "auth", "status"), timeout=30)
                    if isinstance(auth, CommandError) or not auth.ok:
                        raise RuntimeError("GitHub CLI authentication is unavailable to the service account")
                self.runtime = ControllerRuntime(config.worker.identity, config.heartbeat,
                    controller_root(config.source), cycle=lambda: _run_controller_work_cycle(config),
                    peer_context_provider=lambda request: build_peer_context(config, config.worker.identity, request).to_payload())
                if self.stopping:
                    return
                logger.info("Controller starting")
                with contextlib.redirect_stdout(LogStream(logger, logging.INFO)), contextlib.redirect_stderr(LogStream(logger, logging.ERROR)):
                    self.runtime.run()
                logger.info("Controller stopped")
            except Exception:
                logger.exception("Controller service failed")
                # A nonzero process exit allows SCM failure recovery to apply.
                os._exit(1)

    servicemanager.Initialize()
    servicemanager.PrepareToHostSingle(ControllerService)
    servicemanager.StartServiceCtrlDispatcher()


if __name__ == "__main__":
    run_service(sys.argv[1])
