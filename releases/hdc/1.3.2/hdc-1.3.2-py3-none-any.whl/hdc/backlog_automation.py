"""Bounded automation from an HDC-selected issue to authorized TaskPackets."""

from dataclasses import dataclass, replace
import hashlib
from pathlib import Path

from .architect import Architect, ArchitectRequest
from .backlog_decision import DecisionResult
from .backlog_store import BacklogSnapshot
from .config import Config
from .design_context import DesignContextBuilder
from .design_sessions import write_draft_tasks
from .lifecycle import TaskLifecycle, TaskStateStore
from .task_packets import IssueReference, TaskPacket, TaskPacketError, list_task_packets


@dataclass(frozen=True)
class AutomationResult:
    status: str
    summary: str
    task_ids: tuple[str, ...] = ()


def materialize_selected_issue(
    config: Config,
    snapshot: BacklogSnapshot,
    decision: DecisionResult,
    *,
    tasks_dir: Path,
    architect: Architect,
    context_builder: DesignContextBuilder | None = None,
    state_store: TaskStateStore | None = None,
) -> AutomationResult:
    """Turn one already-vetted selection into READY packets, or stop safely.

    This function never chooses an issue. It only acts on a ``SELECTED`` result
    produced by deterministic backlog vetting, and it refuses clarification or
    malformed Architect output rather than guessing.
    """
    if decision.status != "SELECTED" or decision.issue is None:
        return AutomationResult("NO_ACTION", "No selected eligible issue is available for automation.")

    issue = _snapshot_issue(snapshot, decision.issue.repository, decision.issue.number)
    if issue is None:
        return AutomationResult("BLOCKED", "Selected issue was not present in the persisted backlog snapshot.")

    tasks_dir = Path(tasks_dir)
    existing = list_task_packets(tasks_dir, set(config.repositories))
    linked = {
        (reference.repository, reference.number)
        for packet in existing
        for reference in packet.github_issues
    }
    issue_key = (decision.issue.repository, decision.issue.number)
    if issue_key in linked:
        return AutomationResult("NO_ACTION", "Selected issue is already linked to a TaskPacket.")

    request_text = f"Implement GitHub issue {decision.issue.repository}#{decision.issue.number}: {issue['title']}"
    context = (context_builder or DesignContextBuilder()).build(config, request_text, tasks_dir=tasks_dir)
    design_id = _design_id(*issue_key)
    architect_result = architect.design(ArchitectRequest(
        design_id,
        request_text,
        context,
        issue_context=f"GitHub issue {decision.issue.repository}#{decision.issue.number}\n{issue['title']}\n{issue['body']}",
    ))
    if architect_result.status != "READY_TO_DRAFT":
        return AutomationResult(
            "BLOCKED",
            f"Automatic issue design stopped with {architect_result.status}: "
            f"{architect_result.error or architect_result.summary}",
        )

    try:
        proposed = []
        proposed_ids = {item.id for item in architect_result.proposed_tasks}
        existing_ids = {packet.id for packet in existing}
        for item in architect_result.proposed_tasks:
            packet = item.to_task_packet(set(config.repositories))
            if config.repository(packet.repository).read_only:
                raise TaskPacketError(
                    f"repository {packet.repository} is read-only; automation cannot authorize implementation"
                )
            unsupported = sorted(set(packet.required_capabilities) - set(config.worker.identity.capabilities))
            if unsupported:
                raise TaskPacketError(
                    f"task {packet.id}: unsupported required capabilities: {', '.join(unsupported)}"
                )
            unresolved = [dependency for dependency in packet.dependencies if dependency not in proposed_ids | existing_ids]
            if unresolved:
                raise TaskPacketError(
                    f"task {packet.id}: unresolved dependencies: {', '.join(unresolved)}"
                )
            proposed.append((replace(
                packet,
                github_issues=[IssueReference(decision.issue.repository, decision.issue.number)],
            ), item))
        if not proposed:
            raise TaskPacketError("Architect returned no tasks")
        tasks_dir.mkdir(parents=True, exist_ok=True)
        write_draft_tasks(tasks_dir, tuple(proposed))
    except (OSError, TaskPacketError, ValueError) as exc:
        return AutomationResult("BLOCKED", f"Automatic TaskPacket creation failed: {exc}")

    state_store = state_store or TaskStateStore()
    for packet, _ in proposed:
        state_store.save(TaskLifecycle(packet.id, "READY"))
    return AutomationResult(
        "READY",
        f"Created and authorized {len(proposed)} TaskPacket(s) for {decision.issue.repository}#{decision.issue.number}.",
        tuple(packet.id for packet, _ in proposed),
    )


def _snapshot_issue(snapshot: BacklogSnapshot, repository: str, number: int) -> dict[str, object] | None:
    return next(
        (issue for issue in snapshot.issues if issue.get("repository") == repository and issue.get("number") == number),
        None,
    )


def _design_id(repository: str, number: int) -> str:
    digest = hashlib.sha256(f"{repository}#{number}".encode()).hexdigest()[:12]
    return f"auto-design-{digest}"
