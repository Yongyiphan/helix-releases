"""Persistent foreground runtime for one HDC Controller installation."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import signal
import threading
import time
from typing import Callable

from .config import HeartbeatConfig, SchemaVersion
from .heartbeat import ControllerRegistry, HeartbeatServer, WorkerHeartbeat, register_with_seed, send_heartbeat
from .identity import WorkerIdentity


class RuntimeErrorState(RuntimeError):
    """Raised when a Controller installation cannot start safely."""


@dataclass(frozen=True)
class RuntimeStatus:
    controller_id: str
    status: str
    started_at: str
    last_heartbeat: str | None = None
    last_error: str | None = None
    last_cycle: str | None = None


class ControllerRuntime:
    """Run heartbeat serving, outbound announcements, and registry maintenance."""

    def __init__(
        self,
        identity: WorkerIdentity,
        heartbeat_config: HeartbeatConfig,
        state_root: Path,
        *,
        sleep=time.sleep,
        cycle: Callable[[], object] | None = None,
        peer_context_provider: Callable[[dict[str, object]], dict[str, object]] | None = None,
        schema_version: SchemaVersion | None = None,
        controller_version: str = "",
        advertise_urls: tuple[str, ...] = (),
        network_seeds: tuple[str, ...] = (),
    ):
        self.identity = identity
        self.config = heartbeat_config
        self.state_root = state_root
        self.registry = ControllerRegistry(state_root / "controllers")
        self.runtime_state_path = state_root / "runtime.json"
        self.sleep = sleep
        self.cycle = cycle
        self.peer_context_provider = peer_context_provider
        self.schema_version = schema_version
        self.controller_version = controller_version
        self.advertise_urls = advertise_urls
        self.network_seeds = network_seeds
        self.stop_event = threading.Event()
        self.wake_event = threading.Event()
        self.status = RuntimeStatus(identity.controller_id, "stopped", "")
        self._lock_path = state_root / "controller.lock"

    def run(self, *, cycles: int | None = None) -> RuntimeStatus:
        if not self.identity.controller_id:
            raise RuntimeErrorState("controller.id is missing; run hdc init first")
        self.state_root.mkdir(parents=True, exist_ok=True)
        self._acquire_lock()
        started = datetime.now(timezone.utc).isoformat()
        self.status = RuntimeStatus(self.identity.controller_id, "running", started)
        self._write_status()
        server = None
        server_thread = None
        try:
            server = HeartbeatServer(
                WorkerHeartbeat.from_identity(self.identity, controller_version=self.controller_version, schema_major=self.schema_version.major if self.schema_version else None, schema_minor=self.schema_version.minor if self.schema_version else None, advertise_urls=self.advertise_urls), host=self.config.bind_host, port=self.config.port,
                auth_token=self.config.auth_token, registry=self.registry,
                stale_after_seconds=self.config.stale_after_seconds, prune_after_seconds=self.config.prune_after_seconds,
                peer_context_provider=self.peer_context_provider,
            )
            server_thread = threading.Thread(target=server.serve_forever, name="hdc-heartbeat-server", daemon=True)
            server_thread.start()
            completed = 0
            while not self.stop_event.is_set() and (cycles is None or completed < cycles):
                self._tick()
                completed += 1
                if cycles is None or completed < cycles:
                    self.wake_event.wait(self.config.interval_seconds)
                    self.wake_event.clear()
        except KeyboardInterrupt:
            pass
        finally:
            if server is not None:
                server.shutdown()
            if server_thread is not None:
                server_thread.join(timeout=5)
            final_status = "restart_requested" if self.status.status == "restart_requested" else "stopped"
            self.status = RuntimeStatus(
                self.identity.controller_id, final_status, started,
                self.status.last_heartbeat, self.status.last_error, self.status.last_cycle,
            )
            self._write_status()
            self._release_lock()
        return self.status

    def stop(self) -> None:
        self.stop_event.set()

    def wake(self) -> None:
        """Wake the cycle loop after an authenticated peer notification."""
        self.wake_event.set()

    def _tick(self) -> None:
        self.registry.maintain(stale_after_seconds=self.config.stale_after_seconds)
        error = None
        heartbeat_time = None
        registration_heartbeat = WorkerHeartbeat.from_identity(
            self.identity,
            controller_version=self.controller_version,
            schema_major=self.schema_version.major if self.schema_version else None,
            schema_minor=self.schema_version.minor if self.schema_version else None,
            advertise_urls=self.advertise_urls,
        )
        for seed in self.network_seeds:
            try:
                self.registry.merge(register_with_seed(seed, registration_heartbeat, timeout_seconds=self.config.timeout_seconds, auth_token=self.config.auth_token))
            except Exception as exc:
                error = f"network registration: {exc}"
        if self.config.core_url:
            heartbeat = registration_heartbeat
            try:
                send_heartbeat(self.config.core_url, heartbeat, timeout_seconds=self.config.timeout_seconds, auth_token=self.config.auth_token)
                heartbeat_time = heartbeat.observed_at.isoformat()
            except Exception as exc:  # runtime must survive temporary network failure
                error = str(exc)
        cycle_time = self.status.last_cycle
        mismatch = self._version_mismatch()
        if self.cycle is not None and mismatch is None:
            try:
                self.cycle()
                cycle_time = datetime.now(timezone.utc).isoformat()
            except Exception as exc:  # one failed work cycle must not kill the Controller
                error = f"{error}; cycle: {exc}" if error else f"cycle: {exc}"
        if mismatch:
            error = f"version mismatch: {mismatch}"
        self.status = RuntimeStatus(
            self.status.controller_id, "degraded" if mismatch else "running", self.status.started_at,
            heartbeat_time or self.status.last_heartbeat, error, cycle_time,
        )
        self._write_status()

    def _version_mismatch(self) -> str | None:
        """Keep communications alive while preventing work on schema disagreement."""
        if self.schema_version is None:
            return None
        for heartbeat in self.registry.list():
            if heartbeat.controller_id == self.identity.controller_id or not heartbeat.is_fresh(timeout_seconds=self.config.stale_after_seconds):
                continue
            if (heartbeat.schema_major, heartbeat.schema_minor) != (self.schema_version.major, self.schema_version.minor):
                remote = "unknown" if heartbeat.schema_major is None else f"{heartbeat.schema_major}.{heartbeat.schema_minor}"
                return f"local {self.schema_version.major}.{self.schema_version.minor}, {heartbeat.worker_id} {remote}"
        return None

    def _acquire_lock(self) -> None:
        try:
            self._lock_path.parent.mkdir(parents=True, exist_ok=True)
            if self._lock_path.exists():
                try:
                    pid = int(self._lock_path.read_text(encoding="utf-8").strip())
                    if _process_exists(pid):
                        raise RuntimeErrorState(f"another Controller runtime is already active: {self._lock_path}")
                    self._lock_path.unlink(missing_ok=True)
                except ProcessLookupError:
                    self._lock_path.unlink(missing_ok=True)
                except ValueError:
                    raise RuntimeErrorState(f"invalid Controller runtime lock: {self._lock_path}")
            descriptor = os.open(self._lock_path, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
            with os.fdopen(descriptor, "w", encoding="utf-8", newline="") as handle:
                handle.write(str(os.getpid()) + "\n")
        except FileExistsError as exc:
            raise RuntimeErrorState(f"another Controller runtime is already active: {self._lock_path}") from exc
        except OSError as exc:
            raise RuntimeErrorState(f"cannot create Controller runtime lock: {self._lock_path}") from exc

    def _release_lock(self) -> None:
        try:
            self._lock_path.unlink(missing_ok=True)
        except OSError:
            pass

    def _write_status(self) -> None:
        self.runtime_state_path.parent.mkdir(parents=True, exist_ok=True)
        self.runtime_state_path.write_text(json.dumps(self.status.__dict__, sort_keys=True, indent=2) + "\n", encoding="utf-8")


def stop_runtime(state_root: Path) -> str:
    """Request termination of the runtime recorded by its local lock."""
    lock_path = state_root / "controller.lock"
    if not lock_path.exists():
        return "not running"
    try:
        pid = int(lock_path.read_text(encoding="utf-8").strip())
        _terminate_process(pid)
    except ProcessLookupError:
        lock_path.unlink(missing_ok=True)
        return "stale lock removed"
    except (OSError, ValueError) as exc:
        raise RuntimeErrorState(f"cannot stop Controller process from {lock_path}: {exc}") from exc
    return f"stop requested for pid {pid}"


def _process_exists(pid: int) -> bool:
    if os.name != "nt":
        try:
            os.kill(pid, 0)
            return True
        except ProcessLookupError:
            return False
    import ctypes
    handle = ctypes.windll.kernel32.OpenProcess(0x1000, False, pid)
    if not handle:
        return False
    ctypes.windll.kernel32.CloseHandle(handle)
    return True


def _terminate_process(pid: int) -> None:
    if os.name != "nt":
        os.kill(pid, signal.SIGTERM)
        return
    import ctypes
    handle = ctypes.windll.kernel32.OpenProcess(0x0001 | 0x1000, False, pid)
    if not handle:
        raise ProcessLookupError(pid)
    try:
        if not ctypes.windll.kernel32.TerminateProcess(handle, 0):
            raise OSError("Windows TerminateProcess failed")
    finally:
        ctypes.windll.kernel32.CloseHandle(handle)


def read_runtime_status(state_root: Path) -> RuntimeStatus | None:
    path = state_root / "runtime.json"
    if not path.exists():
        return None
    raw = json.loads(path.read_text(encoding="utf-8"))
    return RuntimeStatus(
        str(raw["controller_id"]), str(raw["status"]), str(raw["started_at"]),
        raw.get("last_heartbeat"), raw.get("last_error"), raw.get("last_cycle"),
    )
