"""Durable local backlog snapshots and decision records."""

from dataclasses import asdict, dataclass
from datetime import datetime, timezone
import json
from pathlib import Path

from .backlog_decision import BacklogCandidate, DecisionResult
from .github import GitHubIssue


@dataclass(frozen=True)
class BacklogSnapshot:
    snapshot_id: str
    captured_at: str
    repositories: tuple[str, ...]
    issues: tuple[dict[str, object], ...]
    candidates: tuple[dict[str, object], ...]


@dataclass(frozen=True)
class BacklogDecisionRecord:
    decision_id: str
    snapshot_id: str
    decided_at: str
    status: str
    summary: str
    issue: str = ""
    attempts: int = 0
    rejection_reasons: tuple[str, ...] = ()


@dataclass(frozen=True)
class BacklogAutomationRecord:
    issue: str
    snapshot_id: str
    recorded_at: str
    status: str
    summary: str
    attempts: int = 0


class BacklogStore:
    """Persist bounded backlog context independently from task/run state."""

    def __init__(self, root: Path | str):
        self.root = Path(root)
        self.snapshots = self.root / "snapshots"
        self.decisions = self.root / "decisions"
        self.automation = self.root / "automation"

    def save_snapshot(self, repositories: tuple[str, ...], issues: tuple[GitHubIssue, ...], candidates: tuple[BacklogCandidate, ...], *, now: datetime | None = None) -> BacklogSnapshot:
        captured_at = (now or datetime.now(timezone.utc)).isoformat()
        snapshot_id = _record_id("snapshot", captured_at)
        snapshot = BacklogSnapshot(
            snapshot_id, captured_at, repositories,
            tuple(_issue_record(issue) for issue in issues),
            tuple(_candidate_record(candidate) for candidate in candidates),
        )
        _write(self.snapshots / f"{snapshot_id}.json", asdict(snapshot))
        _write(self.root / "latest-snapshot.json", asdict(snapshot))
        return snapshot

    def save_decision(self, snapshot: BacklogSnapshot, result: DecisionResult, *, now: datetime | None = None) -> BacklogDecisionRecord:
        decided_at = (now or datetime.now(timezone.utc)).isoformat()
        decision_id = _record_id("decision", decided_at)
        record = BacklogDecisionRecord(
            decision_id, snapshot.snapshot_id, decided_at, result.status, result.summary,
            f"{result.issue.repository}#{result.issue.number}" if result.issue else "",
            result.attempts, result.rejection_reasons,
        )
        _write(self.decisions / f"{decision_id}.json", asdict(record))
        _write(self.root / "latest-decision.json", asdict(record))
        return record

    def latest_snapshot(self) -> BacklogSnapshot | None:
        return _load_snapshot(self.root / "latest-snapshot.json")

    def latest_decision(self) -> BacklogDecisionRecord | None:
        path = self.root / "latest-decision.json"
        if not path.is_file():
            return None
        raw = json.loads(path.read_text(encoding="utf-8"))
        return BacklogDecisionRecord(**raw)

    def save_automation(self, snapshot: BacklogSnapshot, repository: str, number: int, status: str, summary: str, *, now: datetime | None = None) -> BacklogAutomationRecord:
        recorded_at = (now or datetime.now(timezone.utc)).isoformat()
        previous = self.latest_automation()
        attempts = previous.attempts + 1 if previous is not None and previous.issue == f"{repository}#{number}" else 1
        record = BacklogAutomationRecord(f"{repository}#{number}", snapshot.snapshot_id, recorded_at, status, summary, attempts)
        _write(self.automation / f"automation-{_record_id('', recorded_at).lstrip('-')}.json", asdict(record))
        _write(self.root / "latest-automation.json", asdict(record))
        return record

    def latest_automation(self) -> BacklogAutomationRecord | None:
        path = self.root / "latest-automation.json"
        if not path.is_file():
            return None
        return BacklogAutomationRecord(**json.loads(path.read_text(encoding="utf-8")))


def _issue_record(issue: GitHubIssue) -> dict[str, object]:
    return {
        "repository": issue.repository, "number": issue.number, "title": issue.title,
        "body": issue.body, "state": issue.state, "url": issue.url, "labels": list(issue.labels),
    }


def _candidate_record(candidate: BacklogCandidate) -> dict[str, object]:
    return {
        "issue": f"{candidate.issue.repository}#{candidate.issue.number}",
        "repository": candidate.repository, "worker_id": candidate.worker_id,
        "available": candidate.available, "context_only": candidate.context_only,
        "eligible": candidate.eligible, "reasons": list(candidate.reasons),
    }


def _load_snapshot(path: Path) -> BacklogSnapshot | None:
    if not path.is_file():
        return None
    raw = json.loads(path.read_text(encoding="utf-8"))
    return BacklogSnapshot(
        raw["snapshot_id"], raw["captured_at"], tuple(raw["repositories"]),
        tuple(raw["issues"]), tuple(raw["candidates"]),
    )


def _record_id(prefix: str, timestamp: str) -> str:
    return f"{prefix}-{timestamp.replace(':', '').replace('-', '').replace('+00:00', 'z').replace('.', '')}"


def _write(path: Path, value: dict[str, object]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, sort_keys=True, ensure_ascii=False) + "\n", encoding="utf-8")
