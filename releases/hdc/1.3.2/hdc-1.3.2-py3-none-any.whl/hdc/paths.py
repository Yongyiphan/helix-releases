"""Platform-neutral paths for one local HDC installation."""

from pathlib import Path
import os
import tomllib


def installation_root(config_file: Path | str | None = None) -> Path:
    """Return the directory that owns a local HDC configuration."""
    return Path(config_file).expanduser().resolve().parent if config_file else Path.cwd().resolve()


def local_state_root(config_file: Path | str | None = None) -> Path:
    """Return the private, machine-local HDC state directory."""
    configured = os.getenv("HDC_STATE_ROOT")
    if configured:
        return Path(configured).expanduser()
    if config_file:
        source = Path(config_file)
        try:
            with source.open("rb") as handle:
                raw = tomllib.load(handle)
            paths = raw.get("paths", {})
            active = paths.get("active") if isinstance(paths, dict) else None
            context = paths.get(active, {}) if active in {"development", "deployment"} else {}
            state = context.get("state_root") if isinstance(context, dict) else None
            if isinstance(state, str) and state:
                value = Path(state)
                return value if value.is_absolute() else source.parent / value
        except (OSError, TypeError, tomllib.TOMLDecodeError):
            pass
    return installation_root(config_file) / ".hdc"


def workspace_root(config_file: Path | str | None = None) -> Path:
    return installation_root(config_file) / "workspaces"


def design_root(config_file: Path | str | None = None) -> Path:
    return local_state_root(config_file) / "designs"


def task_state_root(config_file: Path | str | None = None) -> Path:
    return local_state_root(config_file) / "tasks"


def runs_root(config_file: Path | str | None = None) -> Path:
    return local_state_root(config_file) / "runs"


def diagnostics_root(config_file: Path | str | None = None) -> Path:
    return local_state_root(config_file) / "diagnostics"


def controller_root(config_file: Path | str | None = None) -> Path:
    return local_state_root(config_file) / "controller"
