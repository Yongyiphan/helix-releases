"""Durable HDC release requests, recipes, locks, and incident policy.

This module deliberately contains no GitHub or privileged installation code.
HDC owns the source-of-truth request and recipe; HR consumes the recipe and
HU consumes the resulting published manifest.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import platform
import sys
import tomllib
import uuid

from .adapters import GitAdapter
from .config import Config
from .paths import local_state_root


RELEASE_PROTOCOL_VERSION = 1
MAX_HOTFIX_ATTEMPTS = 2


class ReleaseWorkflowError(ValueError):
    """A release request cannot safely proceed."""


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _request_id() -> str:
    return f"release-{uuid.uuid4().hex}"


@dataclass(frozen=True)
class ReleaseRequest:
    request_id: str
    component: str
    repository: str
    version: str
    channel: str
    artifact_format: str
    owner_controller: str
    created_at: str
    state: str = "LOCKED"
    hotfix_attempts: int = 0
    source_commit: str | None = None

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass(frozen=True)
class ReleaseRecipe:
    protocol: int
    request_id: str
    component: str
    repository: str
    source_root: str
    source_commit: str
    version: str
    channel: str
    artifact_format: str
    source_files: tuple[str, ...]
    build_command: tuple[str, ...]
    test_commands: tuple[tuple[str, ...], ...]
    owner_controller: str
    generated_at: str
    recipe_digest: str

    def to_dict(self) -> dict:
        value = asdict(self)
        value["source_files"] = list(self.source_files)
        value["build_command"] = list(self.build_command)
        value["test_commands"] = [list(command) for command in self.test_commands]
        return value


@dataclass(frozen=True)
class ReleaseHandoff:
    protocol: int
    handoff_id: str
    contract_id: str
    contract_hash: str
    contract: dict
    component: str
    repository: str
    branch: str
    source_root: str
    source_commit: str
    version: str
    channel: str
    artifact_format: str
    platforms: tuple[str, ...]
    source_files: tuple[str, ...]
    required_paths: tuple[str, ...]
    build_command: tuple[str, ...]
    test_commands: tuple[tuple[str, ...], ...]
    owner_controller: str
    verification: dict
    generated_at: str
    handoff_digest: str

    def to_dict(self) -> dict:
        value = asdict(self)
        for key in ("platforms", "source_files", "required_paths", "build_command"):
            value[key] = list(getattr(self, key))
        value["test_commands"] = [list(command) for command in self.test_commands]
        return value


@dataclass(frozen=True)
class IncidentRecord:
    request_id: str
    state: str
    hotfix_attempts: int
    reinvestigation_count: int
    diagnostics: tuple[str, ...] = ()
    updated_at: str = field(default_factory=_now)

    def to_dict(self) -> dict:
        value = asdict(self)
        value["diagnostics"] = list(self.diagnostics)
        return value


class ReleaseStore:
    """Atomic JSON storage for release requests and incident decisions."""

    def __init__(self, root: Path):
        self.root = root
        self.root.mkdir(parents=True, exist_ok=True)
        self.requests = self.root / "requests"
        self.recipes = self.root / "recipes"
        self.handoffs = self.root / "handoffs"
        self.incidents = self.root / "incidents"
        for directory in (self.requests, self.recipes, self.handoffs, self.incidents):
            directory.mkdir(parents=True, exist_ok=True)

    @classmethod
    def for_config(cls, config: Config) -> "ReleaseStore":
        return cls(local_state_root(config.source) / "releases")

    def _write(self, path: Path, value: dict) -> None:
        temporary = path.with_suffix(path.suffix + ".new")
        temporary.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n", encoding="utf-8")
        temporary.replace(path)

    def save_request(self, request: ReleaseRequest) -> None:
        self._write(self.requests / f"{request.request_id}.json", request.to_dict())

    def load_request(self, request_id: str) -> ReleaseRequest:
        try:
            raw = json.loads((self.requests / f"{request_id}.json").read_text(encoding="utf-8"))
            return ReleaseRequest(**raw)
        except (OSError, json.JSONDecodeError, TypeError) as exc:
            raise ReleaseWorkflowError(f"release request not found or invalid: {request_id}") from exc

    def save_recipe(self, recipe: ReleaseRecipe) -> None:
        self._write(self.recipes / f"{recipe.request_id}.json", recipe.to_dict())

    def save_handoff(self, handoff: ReleaseHandoff) -> None:
        self._write(self.handoffs / f"{handoff.handoff_id}.json", handoff.to_dict())

    def load_recipe(self, request_id: str) -> dict:
        try:
            return json.loads((self.recipes / f"{request_id}.json").read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            raise ReleaseWorkflowError(f"release recipe not found: {request_id}") from exc

    def save_incident(self, incident: IncidentRecord) -> None:
        self._write(self.incidents / f"{incident.request_id}.json", incident.to_dict())

    def load_incident(self, request_id: str) -> IncidentRecord:
        path = self.incidents / f"{request_id}.json"
        if not path.exists():
            return IncidentRecord(request_id, "OBSERVING", 0, 0)
        try:
            raw = json.loads(path.read_text(encoding="utf-8"))
            return IncidentRecord(
                request_id=str(raw["request_id"]), state=str(raw["state"]),
                hotfix_attempts=int(raw["hotfix_attempts"]),
                reinvestigation_count=int(raw.get("reinvestigation_count", 0)),
                diagnostics=tuple(str(item) for item in raw.get("diagnostics", [])),
                updated_at=str(raw.get("updated_at", _now())),
            )
        except (OSError, json.JSONDecodeError, KeyError, TypeError, ValueError) as exc:
            raise ReleaseWorkflowError(f"invalid release incident record: {request_id}") from exc

    def active_for_component(self, component: str) -> ReleaseRequest | None:
        for path in sorted(self.requests.glob("release-*.json")):
            try:
                request = self.load_request(path.stem)
            except ReleaseWorkflowError:
                continue
            if request.component == component and request.state in {"LOCKED", "BUILDING", "PUBLISHED", "OBSERVING", "REINVESTIGATION_REQUIRED"}:
                return request
        return None

    def active_requests(self) -> tuple[ReleaseRequest, ...]:
        values = []
        for path in sorted(self.requests.glob("release-*.json")):
            try:
                request = self.load_request(path.stem)
            except ReleaseWorkflowError:
                continue
            if request.state in {"LOCKED", "BUILDING", "BUILD_FAILED", "PUBLISHED", "OBSERVING", "REINVESTIGATION_REQUIRED", "REINVESTIGATING", "REQUIRE_HUMAN_INTERVENTION"}:
                values.append(request)
        return tuple(values)

    def update_request(self, request: ReleaseRequest, **changes) -> ReleaseRequest:
        updated = ReleaseRequest(**{**request.to_dict(), **changes})
        self.save_request(updated)
        return updated


def _git_output(git: GitAdapter, path: Path, *arguments: str) -> str:
    result = git.runner.run([git.executable, "-C", str(path), *arguments], timeout=30.0)
    if not hasattr(result, "ok") or not result.ok:
        detail = getattr(result, "message", "git command failed")
        raise ReleaseWorkflowError(f"cannot inspect release source: {detail}")
    return result.stdout.strip()


def _version_from_project(path: Path) -> str | None:
    project = path / "pyproject.toml"
    if not project.is_file():
        return None
    import tomllib

    try:
        raw = tomllib.loads(project.read_text(encoding="utf-8"))
    except (OSError, tomllib.TOMLDecodeError):
        return None
    value = raw.get("project", {}).get("version")
    return value.strip() if isinstance(value, str) and value.strip() else None


def create_release_request(
    config: Config,
    component: str,
    *,
    version: str | None = None,
    channel: str = "dev",
    artifact_format: str = "python_wheel",
    git: GitAdapter | None = None,
) -> ReleaseRequest:
    if artifact_format != "python_wheel":
        raise ReleaseWorkflowError("the first release contract supports python_wheel only")
    load_hr_contract(config)
    repository = config.repository(component)
    if repository.path is None:
        raise ReleaseWorkflowError(f"component {component!r} has no local source checkout")
    git = git or GitAdapter()
    if not git.repository_valid(repository.path):
        raise ReleaseWorkflowError(f"component source is not a Git worktree: {repository.path}")
    status = git.repository_status(repository.path)
    dirty = [line for line in status.splitlines() if line and not line.startswith("##")]
    if dirty:
        raise ReleaseWorkflowError(f"release source is dirty; commit or stash changes first: {component}")
    resolved_version = version or _version_from_project(repository.path)
    if not resolved_version:
        raise ReleaseWorkflowError("release version is required when pyproject.toml has no static project.version")
    controller_id = config.worker.identity.controller_id
    store = ReleaseStore.for_config(config)
    active = store.active_for_component(component)
    if active is not None:
        raise ReleaseWorkflowError(f"component is already release-locked by {active.request_id}")
    request = ReleaseRequest(
        request_id=_request_id(), component=component, repository=component,
        version=resolved_version, channel=channel.strip(), artifact_format=artifact_format,
        owner_controller=controller_id, created_at=_now(),
        source_commit=_git_output(git, repository.path, "rev-parse", "HEAD"),
    )
    store.save_request(request)
    return request


def _hr_contract_path(config: Config) -> Path:
    configured = __import__("os").environ.get("HDC_HR_CONTRACT")
    candidates = [Path(configured).expanduser()] if configured else []
    hr = config.repositories.get("hr")
    if hr and hr.path:
        candidates.append(hr.path / "contracts" / "python-wheel-v1.toml")
    candidates.extend((
        config.source.parent / "helix-releases" / "contracts" / "python-wheel-v1.toml",
        config.source.parent.parent / "helix-releases" / "contracts" / "python-wheel-v1.toml",
    ))
    for candidate in candidates:
        if candidate.is_file():
            return candidate.resolve()
    raise ReleaseWorkflowError("HR packaging contract was not found; configure the hr repository or HDC_HR_CONTRACT")


def load_hr_contract(config: Config) -> tuple[dict, str]:
    path = _hr_contract_path(config)
    try:
        raw = tomllib.loads(path.read_text(encoding="utf-8"))
    except (OSError, tomllib.TOMLDecodeError) as exc:
        raise ReleaseWorkflowError(f"cannot read HR contract: {path}") from exc
    contract = raw.get("contract")
    if not isinstance(contract, dict) or not isinstance(contract.get("id"), str):
        raise ReleaseWorkflowError("HR contract must contain a [contract] table with id")
    digest = hashlib.sha256(json.dumps(contract, sort_keys=True).encode("utf-8")).hexdigest()
    return contract, digest


def build_handoff(config: Config, request: ReleaseRequest, *, hermes_validated: bool = True, git: GitAdapter | None = None) -> ReleaseHandoff:
    contract, contract_hash = load_hr_contract(config)
    repository = config.repository(request.component)
    if repository.path is None:
        raise ReleaseWorkflowError(f"component {request.component!r} has no local source checkout")
    git = git or GitAdapter()
    current_commit = _git_output(git, repository.path, "rev-parse", "HEAD")
    if request.source_commit and current_commit != request.source_commit:
        raise ReleaseWorkflowError("source commit changed after the release request was locked")
    status = git.repository_status(repository.path)
    if any(line and not line.startswith("##") for line in status.splitlines()):
        raise ReleaseWorkflowError("release source became dirty after the release request was locked")
    tracked = tuple(item for item in _git_output(git, repository.path, "ls-files", "-z").split("\0") if item)
    required_paths = tuple(str(item) for item in contract.get("required_paths", []))
    if not required_paths:
        raise ReleaseWorkflowError("HR contract must declare required_paths")
    for relative in required_paths:
        candidate = repository.path / relative
        if not candidate.exists():
            raise ReleaseWorkflowError(f"contract-required path is missing: {relative}")
    build_command = tuple(str(item).replace("python", sys.executable, 1) if index == 0 else str(item) for index, item in enumerate(contract.get("build_command", [])))
    test_commands = tuple(tuple(str(item).replace("python", sys.executable, 1) if index == 0 else str(item) for index, item in enumerate(command)) for command in contract.get("test_commands", []))
    if not build_command or not test_commands:
        raise ReleaseWorkflowError("HR contract must declare a build command and test commands")
    branch = git.current_branch(repository.path) or repository.base_branch or "unknown"
    payload = {
        "protocol": RELEASE_PROTOCOL_VERSION, "handoff_id": request.request_id,
        "contract_id": contract["id"], "contract_hash": contract_hash, "contract": contract,
        "component": request.component, "repository": request.repository, "branch": branch,
        "source_root": str(repository.path.resolve()), "source_commit": current_commit,
        "version": request.version, "channel": request.channel, "artifact_format": request.artifact_format,
        "platforms": list(contract.get("supported_platforms", [])), "source_files": list(tracked),
        "required_paths": list(required_paths), "build_command": list(build_command),
        "test_commands": [list(command) for command in test_commands],
        "owner_controller": request.owner_controller,
        "verification": {"hermes": "passed" if hermes_validated else "not_run", "working_tree": "clean", "source_commit": current_commit},
    }
    digest = hashlib.sha256(json.dumps(payload, sort_keys=True).encode("utf-8")).hexdigest()
    handoff = ReleaseHandoff(
        protocol=RELEASE_PROTOCOL_VERSION, handoff_id=request.request_id,
        contract_id=str(contract["id"]), contract_hash=contract_hash, contract=contract,
        component=request.component, repository=request.repository, branch=branch,
        source_root=str(repository.path.resolve()), source_commit=current_commit,
        version=request.version, channel=request.channel, artifact_format=request.artifact_format,
        platforms=tuple(str(item) for item in contract.get("supported_platforms", [])),
        source_files=tracked, required_paths=required_paths, build_command=build_command,
        test_commands=test_commands, owner_controller=request.owner_controller,
        verification=payload["verification"], generated_at=_now(), handoff_digest=digest,
    )
    ReleaseStore.for_config(config).save_handoff(handoff)
    return handoff


def build_recipe(config: Config, request: ReleaseRequest, *, git: GitAdapter | None = None) -> ReleaseRecipe:
    repository = config.repository(request.component)
    if repository.path is None:
        raise ReleaseWorkflowError(f"component {request.component!r} has no local source checkout")
    git = git or GitAdapter()
    current_commit = _git_output(git, repository.path, "rev-parse", "HEAD")
    if request.source_commit and current_commit != request.source_commit:
        raise ReleaseWorkflowError("source commit changed after the release request was locked")
    status = git.repository_status(repository.path)
    if any(line and not line.startswith("##") for line in status.splitlines()):
        raise ReleaseWorkflowError("release source became dirty after the release request was locked")
    tracked = tuple(item for item in _git_output(git, repository.path, "ls-files", "-z").split("\0") if item)
    if not tracked:
        raise ReleaseWorkflowError("release source has no tracked files")
    python = sys.executable
    build_command = (python, "-m", "pip", "wheel", "--no-build-isolation", "--no-deps", "--wheel-dir", "{output}", ".")
    test_commands: tuple[tuple[str, ...], ...] = ((python, "-m", "pytest", "-q"),)
    payload = {
        "protocol": RELEASE_PROTOCOL_VERSION, "request_id": request.request_id,
        "component": request.component, "repository": request.repository,
        "source_root": str(repository.path.resolve()), "source_commit": current_commit,
        "version": request.version, "channel": request.channel,
        "artifact_format": request.artifact_format, "source_files": list(tracked),
        "build_command": list(build_command), "test_commands": [list(item) for item in test_commands],
        "owner_controller": request.owner_controller,
    }
    digest = hashlib.sha256(json.dumps(payload, sort_keys=True).encode("utf-8")).hexdigest()
    recipe = ReleaseRecipe(
        protocol=RELEASE_PROTOCOL_VERSION, request_id=request.request_id,
        component=request.component, repository=request.repository,
        source_root=str(repository.path.resolve()), source_commit=current_commit,
        version=request.version, channel=request.channel, artifact_format=request.artifact_format,
        source_files=tracked, build_command=build_command, test_commands=test_commands,
        owner_controller=request.owner_controller, generated_at=_now(), recipe_digest=digest,
    )
    ReleaseStore.for_config(config).save_recipe(recipe)
    return recipe


def record_hotfix(config: Config, request_id: str, diagnostic: str) -> IncidentRecord:
    store = ReleaseStore.for_config(config)
    request = store.load_request(request_id)
    incident = store.load_incident(request_id)
    if incident.hotfix_attempts >= MAX_HOTFIX_ATTEMPTS or incident.state == "REINVESTIGATION_REQUIRED":
        raise ReleaseWorkflowError("hotfix budget exhausted; reinvestigation is required")
    attempts = incident.hotfix_attempts + 1
    state = "HOTFIX_ALLOWED" if attempts < MAX_HOTFIX_ATTEMPTS else "REINVESTIGATION_REQUIRED"
    updated = IncidentRecord(request_id, state, attempts, incident.reinvestigation_count, (*incident.diagnostics, diagnostic))
    store.save_incident(updated)
    store.update_request(request, state="REINVESTIGATION_REQUIRED" if state == "REINVESTIGATION_REQUIRED" else "OBSERVING", hotfix_attempts=attempts)
    return updated


def start_reinvestigation(config: Config, request_id: str, diagnostic: str) -> IncidentRecord:
    store = ReleaseStore.for_config(config)
    request = store.load_request(request_id)
    current = store.load_incident(request_id)
    updated = IncidentRecord(request_id, "REINVESTIGATING", current.hotfix_attempts, current.reinvestigation_count + 1, (*current.diagnostics, diagnostic))
    store.save_incident(updated)
    store.update_request(request, state="REINVESTIGATING")
    return updated


def require_human(config: Config, request_id: str, diagnostic: str) -> IncidentRecord:
    store = ReleaseStore.for_config(config)
    request = store.load_request(request_id)
    current = store.load_incident(request_id)
    updated = IncidentRecord(request_id, "REQUIRE_HUMAN_INTERVENTION", current.hotfix_attempts, current.reinvestigation_count, (*current.diagnostics, diagnostic))
    store.save_incident(updated)
    store.update_request(request, state="REQUIRE_HUMAN_INTERVENTION")
    return updated


def finish_observation(config: Config, request_id: str, outcome: str) -> ReleaseRequest:
    store = ReleaseStore.for_config(config)
    request = store.load_request(request_id)
    transitions = {"pass": "DONE", "rollback": "ROLLED_BACK", "incident": "OBSERVING"}
    try:
        state = transitions[outcome]
    except KeyError as exc:
        raise ReleaseWorkflowError("observation outcome must be pass, rollback, or incident") from exc
    return store.update_request(request, state=state)


def collect_diagnostics(config: Config, request_id: str, *, git: GitAdapter | None = None) -> Path:
    """Collect repeatable evidence so an operator is not asked for commands manually."""
    store = ReleaseStore.for_config(config)
    request = store.load_request(request_id)
    repository = config.repository(request.component)
    git = git or GitAdapter()
    output_dir = store.root / "diagnostics" / request_id
    output_dir.mkdir(parents=True, exist_ok=True)
    values = {
        "request": request.to_dict(),
        "host": platform.node(), "platform": platform.platform(),
        "python": sys.version, "repository": str(repository.path) if repository.path else None,
        "git_status": git.repository_status(repository.path) if repository.path else "unavailable",
        "git_commit": _git_output(git, repository.path, "rev-parse", "HEAD") if repository.path else None,
        "git_diff_stat": _git_output(git, repository.path, "diff", "--stat", "HEAD") if repository.path else "unavailable",
    }
    path = output_dir / "diagnostics.json"
    path.write_text(json.dumps(values, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return path
