"""Versioned Windows wheel installation with a native SCM service adapter."""

from datetime import datetime, timezone
from contextlib import nullcontext
from functools import wraps
from email.parser import BytesParser
import getpass
import hashlib
import json
import os
from pathlib import Path
import shutil
import sys
import time
import uuid
import zipfile

from .config import load_config, create_controller_id
from .deployment_support import deployment_path, render_deployment_config
from .installer import InstallError
from .process import CommandRunner, CommandError


def read_manifest(root):
    path = Path(root) / "installation.json"
    if not path.exists():
        return None
    value = json.loads(path.read_text(encoding="utf-8"))
    if value.get("owner") != "HelixHDC" or value.get("schema") != 1:
        raise InstallError("Unrecognized installation manifest")
    for release in value.get("releases", []):
        owned_release(root, Path(release))
    if value.get("active") not in value.get("releases", []):
        raise InstallError("Active release is absent from installation manifest")
    return value


def owned_release(root, release):
    root = Path(root).resolve() / "releases"
    release = Path(release)
    if release.is_symlink() or (hasattr(release, "is_junction") and release.is_junction()) or release.resolve().parent != root or release.resolve() == root:
        raise InstallError(f"Release escapes installer-owned directory: {release}")
    return release


def atomic_json(path, value):
    path = Path(path)
    temporary = path.with_suffix(path.suffix + ".new")
    temporary.write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8")
    os.replace(temporary, path)


def wheel_version(artifact):
    if Path(artifact).suffix.lower() != ".whl":
        raise InstallError("Installation requires a .whl artifact")
    try:
        with zipfile.ZipFile(artifact) as wheel:
            names = [name for name in wheel.namelist() if name.endswith(".dist-info/METADATA")]
            if len(names) != 1:
                raise InstallError("Expected one wheel metadata file")
            metadata = BytesParser().parsebytes(wheel.read(names[0]))
            if metadata["Name"].lower() != "hdc":
                raise InstallError("Wheel must contain the hdc distribution")
            return str(metadata["Version"])
    except (OSError, zipfile.BadZipFile, AttributeError) as exc:
        raise InstallError(f"Invalid HDC wheel: {artifact}") from exc


def serialized(operation):
    @wraps(operation)
    def invoke(self, *args, **kwargs):
        if operation.__name__ == "install":
            wheel_version(args[0] if args else kwargs["artifact"])
        service = self._manager()
        with getattr(service, "installation_lock", nullcontext)():
            return operation(self, *args, **kwargs)
    return invoke


class WindowsInstaller:
    def __init__(self, *, runner=None, service=None, health=None):
        self.runner = runner or CommandRunner()
        self.service = service
        self.health = health or self._health

    def _manager(self):
        if self.service is None:
            import ctypes
            if os.name != "nt" or not ctypes.windll.shell32.IsUserAnAdmin():
                raise InstallError("Run the Windows installer as administrator")
            from .windows_service import WindowsServiceManager
            self.service = WindowsServiceManager()
        return self.service

    def _run(self, args, **kwargs):
        result = self.runner.run(tuple(str(arg) for arg in args), timeout=300, **kwargs)
        if isinstance(result, CommandError) or not result.ok:
            detail = result.message if isinstance(result, CommandError) else result.stderr or result.stdout
            raise InstallError(f"Installation command failed: {detail}")
        return result

    def _acl(self, path, account, permission):
        self._run(("icacls.exe", path, "/inheritance:r", "/grant:r",
            "*S-1-5-18:(OI)(CI)F", "*S-1-5-32-544:(OI)(CI)F", f"{account}:(OI)(CI){permission}"))

    @serialized
    def install(self, artifact, config, *, progress=None):
        artifact = Path(artifact).resolve()
        version = wheel_version(artifact)
        service = self._manager()
        paths = config.deployment_paths
        if paths is None:
            raise InstallError("Deployment paths are required")
        root = paths.application_root.resolve()
        # Application releases must never contain persistent data or the checkout.
        for path in (paths.configuration_root, paths.state_root, paths.workspace_root, paths.log_root, config.source.parent):
            if path.resolve().is_relative_to(root):
                raise InstallError("Application root must be separate from configuration, state, workspaces, logs and checkout")
        if root == Path(root.anchor) or len(root.parts) < 3:
            raise InstallError("Application root must be a dedicated HDC directory")
        previous = read_manifest(root)
        existing_service = service.configuration()
        if existing_service and not previous:
            raise InstallError("HelixHDC service exists without an owned installation manifest")
        if previous and not existing_service:
            raise InstallError("Installation manifest exists but HelixHDC service is missing; repair registration first")
        marker = root / "owner.json"
        owned = marker.is_file() and json.loads(marker.read_text(encoding="utf-8")) == {"owner": "HelixHDC", "root": str(root)}
        if root.exists() and any(root.iterdir()) and previous is None and not owned:
            raise InstallError(f"Refusing an unmanaged application directory: {root}")
        active_config = paths.configuration_root / "hdc.toml"
        if active_config.exists():
            config = load_config(active_config)
            if config.deployment_paths.application_root.resolve() != root:
                raise InstallError("Existing configuration points to a different application root")
            paths = config.deployment_paths
        account = previous["account"] if previous else os.getenv("HDC_SERVICE_USER", "").strip()
        if not account:
            raise InstallError("HDC_SERVICE_USER must identify the Windows service account")
        password = None
        if not previous:
            # Password stays in memory and goes directly to SCM, never a subprocess.
            password = getpass.getpass(f"Windows password for service account {account} (not PIN): ")
            from .windows_service import grant_service_logon
            grant_service_logon(account)
            service.validate_credentials(account, password)
        root.mkdir(parents=True, exist_ok=True)
        self._acl(root, account, "RX")
        atomic_json(marker, {"owner": "HelixHDC", "root": str(root)})
        paths.configuration_root.mkdir(parents=True, exist_ok=True)
        self._acl(paths.configuration_root, account, "RX")
        for path in (paths.state_root, paths.workspace_root, paths.log_root):
            path.mkdir(parents=True, exist_ok=True)
            self._acl(path, account, "M")
        if not active_config.exists():
            active_config.write_text(render_deployment_config(config), encoding="utf-8")
        identity = paths.configuration_root / "controller.id"
        if not identity.exists():
            source = config.controller.id_path
            if source and source.exists():
                shutil.copy2(source, identity)
            else:
                create_controller_id(identity)
        release = root / "releases" / (datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S") + "-" + uuid.uuid4().hex[:12])
        release.mkdir(parents=True)
        owned_release(root, release)
        runtime_python = release / ".venv/Scripts/python.exe"
        settings_path = release / "service.json"
        environment = {"HDC_CONFIG": str(active_config), "HDC_STATE_ROOT": str(paths.state_root), "PATH": deployment_path()}
        if previous:
            old_settings = json.loads((Path(previous["active"]) / "service.json").read_text(encoding="utf-8"))
            environment.update(old_settings["environment"])
        else:
            environment["HDC_GITHUB_AUTH"] = os.getenv("HDC_GITHUB_AUTH", "gh")
            environment["GH_CONFIG_DIR"] = os.getenv("GH_CONFIG_DIR", str(Path(os.environ.get("APPDATA", "")) / "GitHub CLI"))
            for key in ("USERPROFILE", "APPDATA", "LOCALAPPDATA", "HOME"):
                if os.getenv(key):
                    environment[key] = os.environ[key]
        atomic_json(settings_path, {"environment": environment, "working_directory": str(release), "log_root": str(paths.log_root)})
        artifact_info = {"version": version, "sha256": hashlib.sha256(artifact.read_bytes()).hexdigest()}
        atomic_json(release / "artifact.json", artifact_info)
        activation_attempted = False
        try:
            if progress:
                progress(f"Building private runtime in {release}")
            self._run((sys.executable, "-m", "venv", release / ".venv"))
            self._run((runtime_python, "-m", "pip", "install", "--no-cache-dir", artifact))
            env = os.environ.copy()
            env.update(environment)
            self._run((runtime_python, "-I", "-m", "hdc", "doctor"), env=env)
            # Validate the service dependency in the installed interpreter too.
            self._run((runtime_python, "-I", "-c", "import win32service, servicemanager; import hdc.windows_service"))
            activation_attempted = True
            service.stop()
            service.configure(runtime_python, settings_path, account, password)
            password = None
            service.start()
            self.health(config, release)
            manifest = {"schema": 1, "owner": "HelixHDC", "account": account, "active": str(release),
                **artifact_info,
                "releases": [str(release)] + (previous["releases"] if previous else [])}
            atomic_json(root / "installation.json", manifest)
            self._launchers(root, release, active_config)
        except Exception as exc:
            if activation_attempted:
                try:
                    service.stop()
                    if previous:
                        old = Path(previous["active"])
                        service.configure(old / ".venv/Scripts/python.exe", old / "service.json")
                        service.start()
                        self.health(config, old)
                        atomic_json(root / "installation.json", previous)
                        self._launchers(root, old, active_config)
                    else:
                        service.remove()
                except Exception as recovery:
                    raise InstallError(f"Installation failed: {exc}; recovery also failed: {recovery}. Release retained at {release}") from exc
            shutil.rmtree(owned_release(root, release))
            raise InstallError(f"Installation failed; previous service restored where present: {exc}") from exc
        # Retention errors must not undo an already healthy activation.
        try:
            self.cleanup(config, keep=config.deployment.release_retention)
        except Exception as exc:
            if progress:
                progress(f"Installed successfully, but release cleanup needs attention: {exc}")
        if progress:
            progress(f"HelixHDC running; configuration: {active_config}; logs: {paths.log_root}")
        return release

    @staticmethod
    def _launchers(root, release, config):
        for name, module in (("hdc", "hdc"), ("hdc-admin", "hdc.installer")):
            values = (str(config), str(release / ".venv/Scripts/python.exe"))
            if any(any(char in value for char in '%\r\n"') for value in values):
                raise InstallError("Launcher paths cannot contain percent signs, quotes or newlines")
            path = root / f"{name}.cmd"
            path.write_text(f'@echo off\nsetlocal\nset "HDC_CONFIG={config}"\n"{values[1]}" -I -m {module} %*\nexit /b %errorlevel%\n', encoding="utf-8")

    def _health(self, config, release):
        from .controller_runtime import read_runtime_status, _process_exists
        from .heartbeat import request_heartbeat
        from .paths import controller_root
        deployed = load_config(config.deployment_paths.configuration_root / "hdc.toml")
        state = controller_root(deployed.source)
        deadline = time.monotonic() + 90
        while time.monotonic() < deadline:
            try:
                status = read_runtime_status(state)
                pid = int((state / "controller.lock").read_text().strip())
                if status and status.status == "running" and pid == self._manager().process_id() and _process_exists(pid):
                    # Status is written before socket bind; also require a live HTTP endpoint.
                    host = deployed.heartbeat.bind_host
                    host = "127.0.0.1" if host == "0.0.0.0" else "[::1]" if host == "::" else host
                    heartbeat = request_heartbeat(f"http://{host}:{deployed.heartbeat.port}",
                        timeout_seconds=2, auth_token=deployed.heartbeat.auth_token)
                    if heartbeat.controller_id == deployed.worker.identity.controller_id:
                        return
            except (OSError, ValueError, KeyError):
                pass
            time.sleep(1)
        raise InstallError("Controller health check timed out; inspect controller.log")

    @serialized
    def cleanup(self, config, *, keep=3):
        if keep < 2:
            raise InstallError("Retain at least two releases")
        self._manager()
        root = config.deployment_paths.application_root
        manifest = read_manifest(root)
        if not manifest:
            return ()
        protected = [manifest["active"]] + [r for r in manifest["releases"] if r != manifest["active"]][:keep - 1]
        removed = []
        for entry in manifest["releases"]:
            if entry not in protected:
                path = owned_release(root, Path(entry))
                if Path(sys.prefix).resolve().is_relative_to(path.resolve()):
                    protected.append(entry)
                    continue
                if path.exists():
                    shutil.rmtree(path)
                removed.append(path)
        manifest["releases"] = protected
        atomic_json(root / "installation.json", manifest)
        return tuple(removed)

    @serialized
    def rollback(self, config):
        service = self._manager()
        root = config.deployment_paths.application_root
        manifest = read_manifest(root)
        if not manifest or len(manifest["releases"]) < 2:
            raise InstallError("No previous release is available")
        old = Path(manifest["active"])
        target = next(Path(r) for r in manifest["releases"] if r != str(old))
        owned_release(root, target)
        try:
            service.stop()
            service.configure(target / ".venv/Scripts/python.exe", target / "service.json")
            service.start()
            self.health(config, target)
            updated = dict(manifest, active=str(target), releases=[str(target), str(old)] + [r for r in manifest["releases"] if r not in (str(target), str(old))])
            artifact_info = target / "artifact.json"
            updated.pop("version", None)
            updated.pop("sha256", None)
            if artifact_info.exists():
                updated.update(json.loads(artifact_info.read_text(encoding="utf-8")))
            atomic_json(root / "installation.json", updated)
            self._launchers(root, target, config.source)
            return target
        except Exception:
            service.stop()
            service.configure(old / ".venv/Scripts/python.exe", old / "service.json")
            service.start()
            self.health(config, old)
            atomic_json(root / "installation.json", manifest)
            self._launchers(root, old, config.source)
            raise

    @serialized
    def uninstall(self, config):
        if config.worker.identity.platform != "windows":
            raise InstallError("This uninstall command supports Windows only")
        service = self._manager()
        root = config.deployment_paths.application_root
        manifest = read_manifest(root)
        if not manifest:
            raise InstallError("No owned Windows installation found")
        releases = [owned_release(root, Path(r)) for r in manifest["releases"]]
        if any(Path(sys.prefix).resolve().is_relative_to(r.resolve()) for r in releases):
            raise InstallError("Run uninstall from the checkout interpreter so the active Python files can be removed")
        service.remove()
        for release in releases:
            if release.exists():
                shutil.rmtree(release)
        for name in ("hdc.cmd", "hdc-admin.cmd", "installation.json", "owner.json"):
            (root / name).unlink(missing_ok=True)
        releases_root = root / "releases"
        if releases_root.exists() and not any(releases_root.iterdir()):
            releases_root.rmdir()
        if root.exists() and not any(root.iterdir()):
            root.rmdir()
