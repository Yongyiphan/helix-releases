"""GitHub Contents-backed implementation of the shared coordination contract."""

import base64
import json
from dataclasses import replace
from datetime import datetime, timedelta
from typing import Any

from .coordination import ClaimResult, CoordinationBackend, RemoteTask, ResultPublication, TaskClaim, utc_now
from .github import GitHubError, GitHubTransport
from .identity import WorkerIdentity
from .task_packets import TaskPacket


class GitHubCoordinationBackend(CoordinationBackend):
    """Store coordination projections in a shared control repository.

    GitHub Contents ``sha`` updates provide the optimistic concurrency boundary:
    only one worker can successfully replace a record read at the same version.
    Canonical TaskPacket TOML remains in the control repository; these JSON files
    contain only the shared lifecycle/claim projection.
    """

    def __init__(self, transport: GitHubTransport, repository: str, *, branch: str = "main", state_root: str = ".hdc/coordination/tasks"):
        self.transport = transport
        self.repository = repository
        self.branch = branch
        self.state_root = state_root.strip("/")

    def _path(self, task_id: str) -> str:
        return f"/repos/{self.repository}/contents/{self.state_root}/{task_id}.json?ref={self.branch}"

    def _directory_path(self) -> str:
        return f"/repos/{self.repository}/contents/{self.state_root}?ref={self.branch}"

    def _read(self, task_id: str) -> tuple[RemoteTask, str]:
        response = self.transport.request("GET", self._path(task_id))
        if not isinstance(response, dict) or not isinstance(response.get("content"), str) or not isinstance(response.get("sha"), str):
            raise GitHubError(f"invalid coordination record for {task_id}")
        try:
            raw = json.loads(base64.b64decode(response["content"]).decode("utf-8"))
            return self._decode(raw), response["sha"]
        except (ValueError, KeyError, TypeError, json.JSONDecodeError) as exc:
            raise GitHubError(f"invalid coordination JSON for {task_id}: {exc}") from exc

    def _write(self, task: RemoteTask, sha: str | None) -> bool:
        payload = {
            "message": f"hdc: update coordination for {task.task_id}",
            "content": base64.b64encode(json.dumps(self._encode(task), sort_keys=True, separators=(",", ":")).encode()).decode(),
            "branch": self.branch,
        }
        if sha is not None:
            payload["sha"] = sha
        try:
            self.transport.request("PUT", self._path(task.task_id), payload)
        except GitHubError:
            return False
        return True

    def sync_task(self, packet: TaskPacket) -> bool:
        """Create/update a projection without changing authorization state."""
        try:
            current, sha = self._read(packet.id)
        except GitHubError as exc:
            if "404" not in str(exc):
                return False
            current, sha = RemoteTask(
                packet.id, packet.repository, tuple(packet.required_capabilities), tuple(packet.dependencies),
            ), None
        if current.claim is not None or current.state in {"CLAIMED", "RUNNING"}:
            if current.repository != packet.repository or current.required_capabilities != tuple(packet.required_capabilities) or current.dependencies != tuple(packet.dependencies):
                return False
        updated = replace(
            current,
            repository=packet.repository,
            required_capabilities=tuple(packet.required_capabilities),
            dependencies=tuple(packet.dependencies),
            version=current.version + (1 if sha is not None else 0),
        )
        return self._write(updated, sha)

    def authorize_task(self, task_id: str) -> bool:
        """Authorize only a fresh, unclaimed projection for automatic execution."""
        try:
            current, sha = self._read(task_id)
        except GitHubError:
            return False
        if current.state != "DRAFT" or current.claim is not None or current.result is not None:
            return False
        return self._write(replace(current, state="READY", version=current.version + 1), sha)

    def _list(self) -> list[RemoteTask]:
        response = self.transport.request("GET", self._directory_path())
        if not isinstance(response, list):
            raise GitHubError("coordination directory response must be a list")
        tasks = []
        for entry in sorted(response, key=lambda item: item.get("name", "")):
            name = entry.get("name", "") if isinstance(entry, dict) else ""
            if name.endswith(".json"):
                tasks.append(self._read(name[:-5])[0])
        return tasks

    def discover_tasks(self, worker: WorkerIdentity, now: datetime | None = None) -> list[RemoteTask]:
        current = now or utc_now()
        tasks = self._list()
        by_id = {task.task_id: task for task in tasks}
        return [task for task in sorted(tasks, key=lambda item: item.task_id) if self._routable(task, worker, by_id, current)]

    def claim_task(self, task_id: str, worker: WorkerIdentity, *, now: datetime | None = None, lease_seconds: int = 900) -> ClaimResult:
        current = now or utc_now()
        task, sha = self._read(task_id)
        all_tasks = {item.task_id: item for item in self._list()}
        if not self._routable(task, worker, all_tasks, current):
            return ClaimResult(False, reason="task is not READY, routable, or dependency-complete")
        claim = TaskClaim(task_id, worker.worker_id, current, current + timedelta(seconds=lease_seconds), task.version + 1, task.attempt + 1)
        updated = replace(task, state="CLAIMED", claim=claim, version=claim.version, attempt=claim.attempt)
        return ClaimResult(True, claim, "claimed") if self._write(updated, sha) else ClaimResult(False, reason="coordination record changed concurrently")

    def renew_claim(self, claim: TaskClaim, worker: WorkerIdentity, *, now: datetime | None = None, lease_seconds: int = 900) -> ClaimResult:
        current = now or utc_now()
        task, sha = self._read(claim.task_id)
        if task.claim != claim or claim.worker_id != worker.worker_id or not claim.is_active(current):
            return ClaimResult(False, reason="claim is not owned by this worker or has expired")
        renewed = TaskClaim(claim.task_id, worker.worker_id, claim.claimed_at, current + timedelta(seconds=lease_seconds), task.version + 1, claim.attempt)
        updated = replace(task, claim=renewed, version=renewed.version)
        return ClaimResult(True, renewed, "renewed") if self._write(updated, sha) else ClaimResult(False, reason="coordination record changed concurrently")

    def recover_expired_claim(self, task_id: str, *, now: datetime | None = None) -> bool:
        current = now or utc_now()
        task, sha = self._read(task_id)
        if task.claim is None or task.claim.is_active(current):
            return False
        return self._write(replace(task, state="READY", claim=None, version=task.version + 1), sha)

    def publish_result(self, task_id: str, claim: TaskClaim, worker: WorkerIdentity, result: ResultPublication, *, now: datetime | None = None) -> bool:
        task, sha = self._read(task_id)
        if task.claim != claim or claim.worker_id != worker.worker_id or not claim.is_active(now or utc_now()):
            return False
        state = "ACCEPTED" if result.integration_ready else ("REVIEW" if result.outcome == "completed" else "BLOCKED")
        updated = replace(task, state=state, integration_ready=result.integration_ready, claim=None, result=result, version=task.version + 1)
        return self._write(updated, sha)

    @staticmethod
    def _routable(task: RemoteTask, worker: WorkerIdentity, tasks: dict[str, RemoteTask], now: datetime) -> bool:
        return (
            task.state == "READY"
            and worker.owns_repository(task.repository)
            and worker.supports(task.required_capabilities)
            and all(
                (dependency := tasks.get(dependency_id)) is not None
                and dependency.state == "ACCEPTED"
                and dependency.integration_ready
                for dependency_id in task.dependencies
            )
            and (task.claim is None or not task.claim.is_active(now))
        )

    @staticmethod
    def _encode(task: RemoteTask) -> dict[str, Any]:
        return {
            "task_id": task.task_id, "repository": task.repository,
            "required_capabilities": list(task.required_capabilities), "dependencies": list(task.dependencies),
            "state": task.state, "integration_ready": task.integration_ready,
            "version": task.version, "attempt": task.attempt,
            "result": None if task.result is None else {
                "run_id": task.result.run_id, "worker_id": task.result.worker_id,
                "outcome": task.result.outcome, "summary": task.result.summary,
                "branch": task.result.branch, "pull_request_url": task.result.pull_request_url,
                "blocked_reason": task.result.blocked_reason,
                "integration_ready": task.result.integration_ready,
            },
            "claim": None if task.claim is None else {
                "task_id": task.claim.task_id, "worker_id": task.claim.worker_id,
                "claimed_at": task.claim.claimed_at.isoformat(), "expires_at": task.claim.expires_at.isoformat(),
                "version": task.claim.version, "attempt": task.claim.attempt,
            },
        }

    @staticmethod
    def _decode(raw: dict[str, Any]) -> RemoteTask:
        result_raw = raw.get("result")
        result = None if result_raw is None else ResultPublication(
            str(result_raw["run_id"]), str(result_raw["worker_id"]), str(result_raw["outcome"]),
            str(result_raw["summary"]), str(result_raw.get("branch", "")),
            str(result_raw.get("pull_request_url", "")), result_raw.get("blocked_reason"),
            bool(result_raw.get("integration_ready", False)),
        )
        claim_raw = raw.get("claim")
        claim = None if claim_raw is None else TaskClaim(
            claim_raw["task_id"], claim_raw["worker_id"], datetime.fromisoformat(claim_raw["claimed_at"]),
            datetime.fromisoformat(claim_raw["expires_at"]), int(claim_raw["version"]), int(claim_raw["attempt"]),
        )
        return RemoteTask(
            raw["task_id"], raw["repository"], tuple(raw.get("required_capabilities", ())),
            tuple(raw.get("dependencies", ())), raw.get("state", "DRAFT"), bool(raw.get("integration_ready", False)),
            claim, int(raw.get("version", 0)), int(raw.get("attempt", 0)),
            result,
        )
