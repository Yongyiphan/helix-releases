"""TOML configuration loading and validation."""

from dataclasses import dataclass
from pathlib import Path, PureWindowsPath
import sys
import tomllib
import uuid
import json
import os
from urllib.parse import urlsplit

from .identity import WorkerIdentity, WorkerIdentityError


class ConfigError(ValueError):
    pass


SCHEMA_MAJOR = 1
SCHEMA_MINOR = 2


@dataclass(frozen=True)
class SchemaVersion:
    major: int
    minor: int


@dataclass(frozen=True)
class RepositoryConfig:
    name: str
    path: Path | None
    read_only: bool
    graphify: bool
    base_branch: str | None = None
    github_repository: str | None = None


@dataclass(frozen=True)
class WorkerConfig:
    identity: WorkerIdentity
    workspace_root: Path
    base_branch: str = "main"


@dataclass(frozen=True)
class ControllerConfig:
    name: str
    advertise_urls: tuple[str, ...] = ()
    peer_urls: dict[str, str] | None = None
    id_path: Path | None = None
    hermes_enabled: bool = True
    max_workers: int = 1
    network_seeds: tuple[str, ...] = ()


@dataclass(frozen=True)
class CoordinationConfig:
    provider: str
    repository: str
    branch: str = "main"
    state_root: str = ".hdc/coordination/tasks"


@dataclass(frozen=True)
class PollingConfig:
    backlog_interval_seconds: int = 43200
    worker_health_interval_seconds: int = 300
    lease_renewal_interval_seconds: int = 120
    event_debounce_seconds: int = 30
    refresh_on_start: bool = True


@dataclass(frozen=True)
class HeartbeatConfig:
    interval_seconds: int = 300
    stale_after_seconds: int = 900
    # Deprecated compatibility setting. Controller records are never auto-purged.
    prune_after_seconds: int = 2592000
    core_url: str | None = None
    bind_host: str = "127.0.0.1"
    port: int = 8765
    timeout_seconds: int = 10
    auth_token: str | None = None


@dataclass(frozen=True)
class PathContext:
    application_root: Path
    configuration_root: Path
    state_root: Path
    workspace_root: Path
    log_root: Path


@dataclass(frozen=True)
class DeploymentConfig:
    release_retention: int = 3


@dataclass(frozen=True)
class Config:
    repositories: dict[str, RepositoryConfig]
    source: Path
    worker: WorkerConfig
    coordination: CoordinationConfig | None = None
    polling: PollingConfig = PollingConfig()
    controller: ControllerConfig | None = None
    heartbeat: HeartbeatConfig = HeartbeatConfig()
    development_paths: PathContext | None = None
    deployment_paths: PathContext | None = None
    deployment: DeploymentConfig = DeploymentConfig()
    schema_version: SchemaVersion = SchemaVersion(SCHEMA_MAJOR, 0)

    def repository(self, name: str) -> RepositoryConfig:
        try:
            return self.repositories[name]
        except KeyError as exc:
            raise ConfigError(f"unknown repository: {name}") from exc

    def hosted_repositories(self) -> tuple[str, ...]:
        """Return projects this Controller can operate on locally."""
        return tuple(name for name, repository in self.repositories.items() if repository.path is not None)


def load_config(path: Path | str | None = None) -> Config:
    source = resolve_config_path(path)
    try:
        with source.open("rb") as handle:
            raw = tomllib.load(handle)
    except FileNotFoundError as exc:
        raise ConfigError(f"configuration file not found: {source}") from exc
    except tomllib.TOMLDecodeError as exc:
        raise ConfigError(f"malformed TOML in {source}: {exc}") from exc
    # Existing hand-written configs omitted the field; retain that compatibility as 1.0.
    schema_version = _schema_version(raw.get("schema_version", 1))

    entries = raw.get("repositories")
    if not isinstance(entries, dict) or not entries:
        raise ConfigError("configuration must contain [repositories] entries")
    repositories: dict[str, RepositoryConfig] = {}
    for name, value in entries.items():
        if not isinstance(value, dict):
            raise ConfigError(f"repository {name!r} must be a table")
        required = {"read_only", "graphify"}
        optional = {"base_branch", "github_repository"}
        if set(value) - {"path"} - required - optional or not required.issubset(value):
            raise ConfigError(f"repository {name!r} must define read_only, graphify, and may define path/base_branch/github_repository")
        if "path" in value and (not isinstance(value["path"], str) or not value["path"].strip()):
            raise ConfigError(f"repository {name!r}.path must be a non-empty path string when provided")
        if not isinstance(value["read_only"], bool) or not isinstance(value["graphify"], bool):
            raise ConfigError(f"repository {name!r} has invalid field types")
        base_branch = value.get("base_branch")
        if base_branch is not None and (not isinstance(base_branch, str) or not base_branch.strip() or Path(base_branch).name != base_branch):
            raise ConfigError(f"repository {name!r} has invalid base_branch")
        github_repository = value.get("github_repository")
        if github_repository is not None and (not isinstance(github_repository, str) or github_repository.count("/") != 1 or any(not part.strip() for part in github_repository.split("/"))):
            raise ConfigError(f"repository {name!r} has invalid github_repository")
        repository_path = _config_path(value["path"], source.parent) if "path" in value else None
        repositories[name] = RepositoryConfig(name, repository_path, value["read_only"], value["graphify"], base_branch.strip() if base_branch else None, github_repository.strip() if github_repository else None)

    raw_controller = raw.get("controller", {})
    if raw_controller and not isinstance(raw_controller, dict):
        raise ConfigError("controller must be a table")
    allowed_controller = {"name", "host", "platform", "roles", "advertise_urls", "peer_urls", "network_seeds", "id_path", "workspace_root", "base_branch", "repositories", "capabilities", "hermes_enabled", "max_workers"}
    if set(raw_controller) - allowed_controller:
        raise ConfigError(f"controller has unexpected fields: {', '.join(sorted(set(raw_controller) - allowed_controller))}")
    raw_worker = raw.get("worker", {})
    if not isinstance(raw_worker, dict):
        raise ConfigError("worker must be a table")
    allowed_worker = {"id", "host", "platform", "repositories", "capabilities", "workspace_root", "base_branch"}
    if set(raw_worker) - allowed_worker:
        raise ConfigError(f"worker has unexpected fields: {', '.join(sorted(set(raw_worker) - allowed_worker))}")
    source_identity = raw_controller if raw_controller else raw_worker
    prefix = "controller" if raw_controller else "worker"
    worker_repositories = _string_tuple(source_identity.get("repositories", list(repositories)), f"{prefix}.repositories")
    unknown = set(worker_repositories) - set(repositories)
    if unknown:
        raise ConfigError(f"{prefix}.repositories references unknown repositories: {', '.join(sorted(unknown))}")
    hosted_repositories = tuple(name for name in worker_repositories if repositories[name].path is not None)
    if not hosted_repositories:
        raise ConfigError(f"{prefix}.repositories must include at least one locally hosted repository")
    capabilities = _string_tuple(source_identity.get("capabilities", []), f"{prefix}.capabilities", allow_empty=True)
    worker_id = _string_value(source_identity.get("name", source_identity.get("id", "local-hdc")), f"{prefix}.name")
    host = _string_value(source_identity.get("host", "local"), f"{prefix}.host")
    platform = _string_value(source_identity.get("platform", _platform()), f"{prefix}.platform")
    workspace_root = _config_path(_path_value(source_identity.get("workspace_root", str(source.parent / "workspaces")), f"{prefix}.workspace_root"), source.parent)
    base_branch = _string_value(source_identity.get("base_branch", "main"), f"{prefix}.base_branch")
    roles = _string_tuple(source_identity.get("roles", []), f"{prefix}.roles", allow_empty=True)
    advertise_urls = _string_tuple(source_identity.get("advertise_urls", []), "controller.advertise_urls", allow_empty=True)
    network_seeds = _endpoint_tuple(source_identity.get("network_seeds", []), "controller.network_seeds")
    if network_seeds and not advertise_urls:
        raise ConfigError("controller.advertise_urls must be configured when network_seeds is used")
    peer_urls_raw = source_identity.get("peer_urls", {})
    if not isinstance(peer_urls_raw, dict) or not all(isinstance(k, str) and isinstance(v, str) and k.strip() and v.strip() for k, v in peer_urls_raw.items()):
        raise ConfigError("controller.peer_urls must be a table of non-empty strings")
    id_path = _config_path(_path_value(source_identity.get("id_path", str(source.parent / "controller.id")), "controller.id_path"), source.parent)
    hermes_enabled = source_identity.get("hermes_enabled", True)
    if not isinstance(hermes_enabled, bool):
        raise ConfigError(f"{prefix}.hermes_enabled must be boolean")
    max_workers = source_identity.get("max_workers", 1)
    if isinstance(max_workers, bool) or not isinstance(max_workers, int) or max_workers < 0 or max_workers > 64:
        raise ConfigError(f"{prefix}.max_workers must be an integer between 0 and 64")
    controller_id = _load_controller_id(id_path)
    try:
        identity = WorkerIdentity(worker_id, host, platform, hosted_repositories, capabilities, controller_id, roles)
    except WorkerIdentityError as exc:
        raise ConfigError(str(exc)) from exc
    raw_coordination = raw.get("coordination")
    coordination = None
    if raw_coordination is not None:
        if not isinstance(raw_coordination, dict):
            raise ConfigError("coordination must be a table")
        allowed = {"provider", "repository", "branch", "state_root"}
        if set(raw_coordination) - allowed:
            raise ConfigError(f"coordination has unexpected fields: {', '.join(sorted(set(raw_coordination) - allowed))}")
        provider = _string_value(raw_coordination.get("provider", "github"), "coordination.provider")
        if provider != "github":
            raise ConfigError("coordination.provider must be github")
        repository = _string_value(raw_coordination.get("repository"), "coordination.repository")
        branch = _string_value(raw_coordination.get("branch", "main"), "coordination.branch")
        state_root = _string_value(raw_coordination.get("state_root", ".hdc/coordination/tasks"), "coordination.state_root")
        coordination = CoordinationConfig(provider, repository, branch, state_root.strip("/"))
    raw_polling = raw.get("polling", {})
    polling = _polling_config(raw_polling)
    controller = ControllerConfig(worker_id, advertise_urls, dict(peer_urls_raw), id_path, hermes_enabled, max_workers, network_seeds)
    heartbeat = _heartbeat_config(raw.get("heartbeat", {}))
    raw_paths = raw.get("paths", {})
    if not isinstance(raw_paths, dict):
        raise ConfigError("paths must be a table")
    development_paths = _path_context(
        raw_paths.get("development"), "paths.development", source.parent,
        PathContext(source.parent, source.parent, source.parent / ".hdc", workspace_root, source.parent / ".hdc" / "logs"),
    )
    deployment_defaults = _deployment_path_defaults(platform)
    deployment_paths = _path_context(raw_paths.get("deployment"), "paths.deployment", source.parent, deployment_defaults)
    raw_deployment = raw.get("deployment", {})
    if not isinstance(raw_deployment, dict):
        raise ConfigError("deployment must be a table")
    unexpected_deployment = set(raw_deployment) - {"release_retention"}
    if unexpected_deployment:
        raise ConfigError(f"deployment has unexpected fields: {', '.join(sorted(unexpected_deployment))}")
    retention = raw_deployment.get("release_retention", 3)
    if isinstance(retention, bool) or not isinstance(retention, int) or retention < 2:
        raise ConfigError("deployment.release_retention must be an integer >= 2")
    # Production release discovery and installation belong to helix-updater.
    # Ignore a legacy [updates] block so existing HDC configurations remain
    # readable during the handoff without keeping an HDC updater contract.
    return Config(
        repositories, source, WorkerConfig(identity, workspace_root, base_branch), coordination,
        polling, controller, heartbeat, development_paths, deployment_paths, DeploymentConfig(retention),
        schema_version,
    )


def _endpoint_tuple(value: object, field: str) -> tuple[str, ...]:
    values = _string_tuple(value, field, allow_empty=True)
    normalized = []
    for endpoint in values:
        candidate = endpoint if "://" in endpoint else f"http://{endpoint}"
        parsed = urlsplit(candidate)
        if parsed.scheme not in {"http", "https"} or not parsed.netloc:
            raise ConfigError(f"{field} contains an invalid endpoint: {endpoint}")
        normalized.append(candidate.rstrip("/"))
    return tuple(normalized)


def resolve_config_path(path: Path | str | None = None) -> Path:
    """Resolve configuration for development and installed operation."""
    configured_path = path or os.getenv("HDC_CONFIG")
    if configured_path:
        return Path(configured_path).expanduser()
    local = Path.cwd() / "hdc.toml"
    installed = Path(os.getenv("ProgramData", "C:/ProgramData")) / "Helix/HDC/hdc.toml" if os.name == "nt" else Path("/etc/helix/hdc/hdc.toml")
    # The installed launcher must operate HDC, even when invoked from inside
    # the development checkout. Module execution from a checkout remains local.
    if installed.is_file() and _running_installed_runtime(installed):
        return installed
    if local.is_file():
        return local
    if installed.is_file():
        return installed
    return local


def _running_installed_runtime(config_path: Path) -> bool:
    """Return whether this interpreter belongs to the config's active release."""
    try:
        with config_path.open("rb") as handle:
            raw = tomllib.load(handle)
        paths = raw.get("paths", {})
        deployment = paths.get("deployment", {}) if isinstance(paths, dict) else {}
        application_root = deployment.get("application_root") if isinstance(deployment, dict) else None
        if not isinstance(application_root, str):
            return False
        runtime = Path(sys.prefix).expanduser().resolve()
        root = Path(application_root).expanduser().resolve()
        candidates = {root / ".venv", root / "current" / ".venv"}
        current = root / "current"
        if current.is_symlink():
            candidates.add(current.resolve() / ".venv")
        manifest_path = root / "installation.json"
        if manifest_path.is_file():
            manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
            active = Path(manifest.get("active", "")).resolve()
            if manifest.get("owner") == "HelixHDC" and active.parent == root / "releases":
                candidates.add(active / ".venv")
        return runtime in {candidate.resolve() for candidate in candidates}
    except (OSError, TypeError, ValueError):
        return False


def _load_controller_id(path: Path) -> str:
    if path.exists():
        value = path.read_text(encoding="utf-8").strip()
        try:
            return str(uuid.UUID(value))
        except ValueError as exc:
            raise ConfigError(f"controller.id is not a valid UUID: {path}") from exc
    return ""


def _schema_version(raw: object) -> SchemaVersion:
    """Parse the versioned config envelope, retaining legacy integer support."""
    if isinstance(raw, int) and not isinstance(raw, bool):
        version = SchemaVersion(raw, 0)
    elif isinstance(raw, dict):
        if set(raw) != {"major", "minor"}:
            raise ConfigError("schema_version must define exactly major and minor")
        major, minor = raw["major"], raw["minor"]
        if any(isinstance(value, bool) or not isinstance(value, int) or value < 0 for value in (major, minor)):
            raise ConfigError("schema_version.major and schema_version.minor must be non-negative integers")
        version = SchemaVersion(major, minor)
    else:
        raise ConfigError("schema_version must be an integer or a { major, minor } table")
    if version.major != SCHEMA_MAJOR:
        raise ConfigError(f"unsupported schema major version: {version.major}; supported major is {SCHEMA_MAJOR}")
    if version.minor > SCHEMA_MINOR:
        raise ConfigError(f"unsupported schema minor version: {version.minor}; supported through {SCHEMA_MAJOR}.{SCHEMA_MINOR}")
    return version


def create_controller_id(path: Path) -> str:
    """Create the installation identity file, refusing to replace identity."""
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        return _load_controller_id(path)
    value = str(uuid.uuid4())
    path.write_text(value + "\n", encoding="utf-8")
    return value


def initialize_config(path: Path | str) -> tuple[Path, Path, bool]:
    """Create or validate a schema-1.x local hdc.toml and its identity."""
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    if target.exists():
        try:
            raw = tomllib.loads(target.read_text(encoding="utf-8"))
        except tomllib.TOMLDecodeError as exc:
            raise ConfigError(f"cannot validate malformed TOML in {target}: {exc}") from exc
        if "schema_version" in raw and _schema_version(raw["schema_version"]):
            id_path = target.parent / "controller.id"
            create_controller_id(id_path)
            return target, id_path, False
        raise ConfigError(f"configuration is not schema version 1.x: {target}; remove it and run init again")
    repository_path = str(target.parent)
    lines = [
        "schema_version = { major = 1, minor = 2 }", "", "[controller]", 'name = "local-hdc"', 'host = "local"',
        f'platform = {json.dumps(_platform())}', "roles = []", "advertise_urls = []", "peer_urls = {}",
        'repositories = ["hdc"]', "capabilities = []", f"workspace_root = {json.dumps(str(target.parent / 'workspaces'))}",
        'base_branch = "main"', "", "[repositories.hdc]", f"path = {json.dumps(repository_path)}",
        "read_only = false", "graphify = true", "",
    ]
    target.write_text("\n".join(lines), encoding="utf-8")
    id_path = target.parent / "controller.id"
    create_controller_id(id_path)
    return target, id_path, True


def _polling_config(raw: object) -> PollingConfig:
    if not isinstance(raw, dict):
        raise ConfigError("polling must be a table")
    allowed = {"backlog_interval_seconds", "worker_health_interval_seconds", "lease_renewal_interval_seconds", "event_debounce_seconds", "refresh_on_start"}
    unexpected = set(raw) - allowed
    if unexpected:
        raise ConfigError(f"polling has unexpected fields: {', '.join(sorted(unexpected))}")
    values = {name: raw.get(name, default) for name, default in {
        "backlog_interval_seconds": 43200, "worker_health_interval_seconds": 300,
        "lease_renewal_interval_seconds": 120, "event_debounce_seconds": 30,
        "refresh_on_start": True,
    }.items()}
    for name in allowed - {"refresh_on_start"}:
        if isinstance(values[name], bool) or not isinstance(values[name], int) or values[name] <= 0:
            raise ConfigError(f"polling.{name} must be a positive integer")
    if not isinstance(values["refresh_on_start"], bool):
        raise ConfigError("polling.refresh_on_start must be a boolean")
    return PollingConfig(**values)


def _heartbeat_config(raw: object) -> HeartbeatConfig:
    if not isinstance(raw, dict):
        raise ConfigError("heartbeat must be a table")
    allowed = {"interval_seconds", "stale_after_seconds", "prune_after_seconds", "core_url", "bind_host", "port", "timeout_seconds", "auth_token"}
    unexpected = set(raw) - allowed
    if unexpected:
        raise ConfigError(f"heartbeat has unexpected fields: {', '.join(sorted(unexpected))}")
    interval = raw.get("interval_seconds", 300)
    stale = raw.get("stale_after_seconds", 900)
    prune = raw.get("prune_after_seconds", 2592000)
    for name, value in (("interval_seconds", interval), ("stale_after_seconds", stale), ("prune_after_seconds", prune)):
        if isinstance(value, bool) or not isinstance(value, int) or value <= 0:
            raise ConfigError(f"heartbeat.{name} must be a positive integer")
    if stale < interval or prune < stale:
        raise ConfigError("heartbeat intervals must satisfy interval <= stale_after <= prune_after")
    core_url = raw.get("core_url")
    if core_url is not None and (not isinstance(core_url, str) or not core_url.strip()):
        raise ConfigError("heartbeat.core_url must be a non-empty string when provided")
    bind_host = _string_value(raw.get("bind_host", "127.0.0.1"), "heartbeat.bind_host")
    port = raw.get("port", 8765)
    timeout = raw.get("timeout_seconds", 10)
    if isinstance(port, bool) or not isinstance(port, int) or not 1 <= port <= 65535:
        raise ConfigError("heartbeat.port must be between 1 and 65535")
    if isinstance(timeout, bool) or not isinstance(timeout, int) or timeout <= 0:
        raise ConfigError("heartbeat.timeout_seconds must be a positive integer")
    token = raw.get("auth_token")
    if token is not None and (not isinstance(token, str) or not token.strip()):
        raise ConfigError("heartbeat.auth_token must be a non-empty string when provided")
    return HeartbeatConfig(interval, stale, prune, core_url.strip() if core_url else None, bind_host, port, timeout, token.strip() if token else None)


def _path_context(raw: object, field: str, base: Path, defaults: PathContext) -> PathContext:
    if raw is None:
        return defaults
    if not isinstance(raw, dict):
        raise ConfigError(f"{field} must be a table")
    allowed = {"application_root", "configuration_root", "state_root", "workspace_root", "log_root"}
    unexpected = set(raw) - allowed
    if unexpected:
        raise ConfigError(f"{field} has unexpected fields: {', '.join(sorted(unexpected))}")
    values: dict[str, Path] = {}
    for name in allowed:
        value = raw.get(name, str(getattr(defaults, name)))
        values[name] = _config_path(_path_value(value, f"{field}.{name}"), base)
    return PathContext(**values)


def _deployment_path_defaults(platform: str) -> PathContext:
    if platform.lower() == "windows":
        application = Path(os.getenv("ProgramFiles", "C:/Program Files")) / "Helix/HDC"
        configuration = Path(os.getenv("ProgramData", "C:/ProgramData")) / "Helix/HDC"
        state = configuration / "state"
        logs = configuration / "logs"
    else:
        application = Path("/opt/helix/hdc")
        configuration = Path("/etc/helix/hdc")
        state = Path("/var/lib/helix/hdc")
        logs = Path("/var/log/helix/hdc")
    return PathContext(application, configuration, state, state / "workspaces", logs)


def _string_value(value: object, field: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise ConfigError(f"{field} must be a non-empty string")
    return value.strip()


def _string_tuple(value: object, field: str, *, allow_empty: bool = False) -> tuple[str, ...]:
    if not isinstance(value, list) or (not allow_empty and not value) or not all(isinstance(item, str) and item.strip() for item in value):
        raise ConfigError(f"{field} must be a {'possibly empty ' if allow_empty else ''}list of non-empty strings")
    result = tuple(item.strip() for item in value)
    if len(set(result)) != len(result):
        raise ConfigError(f"{field} must not contain duplicates")
    return result


def _path_value(value: object, field: str) -> Path:
    if not isinstance(value, str) or not value.strip():
        raise ConfigError(f"{field} must be a non-empty path string")
    return Path(value)


def _config_path(value: str | Path, base: Path) -> Path:
    """Resolve relative paths beside hdc.toml on every supported platform."""
    path = Path(value)
    raw = str(value)
    if path.is_absolute() or PureWindowsPath(raw).is_absolute():
        return path
    return base / path


def _platform() -> str:
    if sys.platform.startswith("win"):
        return "windows"
    if sys.platform == "darwin":
        return "macos"
    return "linux"
