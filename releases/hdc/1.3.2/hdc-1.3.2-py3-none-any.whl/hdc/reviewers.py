"""Replaceable independent-reviewer boundary for HDC."""

from dataclasses import dataclass
import json
from pathlib import Path
from typing import Literal, Protocol

from .execution_plan import ExecutionPlan
from .process import CommandError, CommandRunner
from .task_packets import TaskPacket
from .validation import ValidationSummary

ReviewVerdict = Literal["PASS", "FAIL", "BLOCKED"]


@dataclass(frozen=True)
class ReviewFinding:
    severity: str
    evidence: str
    recommendation: str


@dataclass(frozen=True)
class ReviewRequest:
    task: TaskPacket
    plan: ExecutionPlan
    workspace: Path
    git_diff: str
    validation: ValidationSummary
    repository_instructions: tuple[str, ...] = ()
    graphify_context: str | None = None


@dataclass(frozen=True)
class ReviewResult:
    verdict: ReviewVerdict
    summary: str
    findings: tuple[ReviewFinding, ...] = ()
    error: str | None = None


class Reviewer(Protocol):
    def review(self, request: ReviewRequest) -> ReviewResult:
        """Review one validated implementation without editing it."""
        ...


def build_review_prompt(request: ReviewRequest) -> str:
    task = request.task
    lines = [
        "You are HDC's independent reviewer. Review the implementation read-only; do not edit files.",
        "Return ONLY JSON with verdict PASS, FAIL, or BLOCKED; summary; and findings.",
        "Each finding must contain severity, evidence, and recommendation.",
        "",
        f"Task ID: {task.id}",
        f"Objective: {task.objective}",
        "Acceptance criteria:",
        *(f"- {item}" for item in task.acceptance),
        "Repository instructions:",
        *(f"- {item}" for item in request.repository_instructions),
        "",
        "Validation summary:",
        *(f"- {result.command}: {'PASS' if result.passed else 'FAIL'}" for result in request.validation.results),
        "",
        "Git diff:",
        request.git_diff,
    ]
    if request.graphify_context:
        lines.extend(["", "Selected Graphify context:", request.graphify_context])
    return "\n".join(lines)


class HermesReviewer(Reviewer):
    """Run one read-only Hermes review and parse its structured response."""

    def __init__(self, runner: CommandRunner | None = None, hermes_executable: str = "hermes", timeout: float = 1800.0):
        self.runner = runner or CommandRunner()
        self.hermes_executable = hermes_executable
        self.timeout = timeout

    def review(self, request: ReviewRequest) -> ReviewResult:
        result = self.runner.run([
            self.hermes_executable,
            "--safe-mode",
            "--oneshot",
            build_review_prompt(request),
            "--in",
            str(request.workspace),
        ], timeout=self.timeout)
        if isinstance(result, CommandError):
            return ReviewResult("BLOCKED", "Hermes review did not complete", error=result.message)
        if not result.ok:
            return ReviewResult("BLOCKED", "Hermes review exited unsuccessfully", error=result.stderr.strip() or f"exit code {result.returncode}")
        return self._parse(result.stdout)

    @staticmethod
    def _parse(output: str) -> ReviewResult:
        try:
            raw = json.loads(output)
            verdict = raw["verdict"]
            summary = raw["summary"]
            findings = tuple(ReviewFinding(item["severity"], item["evidence"], item["recommendation"]) for item in raw.get("findings", []))
            if verdict not in {"PASS", "FAIL", "BLOCKED"} or not isinstance(summary, str):
                raise ValueError("invalid review verdict or summary")
            return ReviewResult(verdict, summary, findings)
        except (json.JSONDecodeError, KeyError, TypeError, ValueError) as exc:
            return ReviewResult("BLOCKED", "Hermes returned an invalid structured review", error=str(exc))
