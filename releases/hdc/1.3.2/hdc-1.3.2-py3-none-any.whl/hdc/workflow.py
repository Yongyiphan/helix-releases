"""Foreground orchestration for one bounded HDC implementation run."""

from dataclasses import asdict, dataclass, replace
from datetime import datetime, timezone
import uuid

from .config import Config
from .execution_plan import ExecutionPlan, build_execution_plan
from .run_records import RunRecord, RunStore
from .task_packets import TaskPacket
from .validation import ValidationRunner
from .workers import DevelopmentWorker, WorkerRequest
from .codex_worker import CodexWorker
from .workspaces import WorkspaceManager, WorkspaceError
from .reviewers import Reviewer, ReviewRequest
from .lifecycle import TaskLifecycle
from .paths import runs_root


@dataclass(frozen=True)
class RepairBudget:
    validation_repairs: int = 3
    review_repairs: int = 2


class WorkflowError(RuntimeError):
    """Raised when a run cannot proceed safely."""


def start_run(
    config: Config,
    packet: TaskPacket,
    *,
    plan: ExecutionPlan | None = None,
    worker: DevelopmentWorker | None = None,
    workspace_manager: WorkspaceManager | None = None,
    validator: ValidationRunner | None = None,
    store: RunStore | None = None,
    run_id: str | None = None,
    reviewer: Reviewer | None = None,
    budget: RepairBudget = RepairBudget(),
    lifecycle: TaskLifecycle | None = None,
) -> RunRecord:
    """Run bounded implementation, validation, and optional review/repair cycles."""
    plan = plan or build_execution_plan(config, packet, require_hermes=reviewer is not None)
    if not plan.execution_permitted:
        reasons = "; ".join(plan.denial_reasons) or "execution is not permitted"
        raise WorkflowError(f"run denied: {reasons}")
    if lifecycle is not None and not lifecycle.execution_authorized:
        raise WorkflowError(f"run denied: task lifecycle is {lifecycle.state}; only READY authorizes execution")
    workspace_manager = workspace_manager or WorkspaceManager(root=plan.proposed_workspace.parent)
    validator = validator or ValidationRunner()
    store = store or RunStore(runs_root(config.source))
    worker = worker or CodexWorker()
    run_id = run_id or f"{packet.id}-{uuid.uuid4().hex[:12]}"

    record = store.create(run_id, plan)
    try:
        workspace = workspace_manager.create(plan)
    except WorkspaceError as exc:
        record = _updated(record, "BLOCKED", terminal_status="BLOCKED")
        store.save(record)
        raise WorkflowError(str(exc)) from exc
    record = _updated(record, "WORKSPACE_READY")
    store.save(record)

    implementation_attempt = 0
    validation_repairs = 0
    review_repairs = 0
    feedback: str | None = None
    while True:
        implementation_attempt += 1
        attempts = {
            "implementation": implementation_attempt,
            "validation_repair": validation_repairs,
            "review_repair": review_repairs,
        }
        record = _updated(record, "IMPLEMENTING", attempts=attempts)
        store.save(record)
        try:
            worker_result = worker.execute(WorkerRequest(
                task=packet,
                plan=plan,
                workspace=workspace.path,
                attempt=implementation_attempt,
                validation_expectations=tuple(packet.validation),
                previous_failure_feedback=feedback,
            ))
        except KeyboardInterrupt:
            record = _updated(record, "CANCELLED", terminal_status="CANCELLED", attempts=attempts)
            store.save(record)
            return record
        store.save_artifact(run_id, f"worker-{implementation_attempt}.json", asdict(worker_result))
        store.save_artifact(run_id, "worker.json", asdict(worker_result))
        if worker_result.outcome != "completed":
            terminal = "BLOCKED" if worker_result.outcome == "blocked" else "FAILED"
            record = _updated(record, terminal, terminal_status=terminal, attempts=attempts)
            store.save(record)
            return record

        record = _updated(record, "VALIDATING", attempts=attempts)
        store.save(record)
        validation = validator.run(packet.validation, cwd=str(workspace.path))
        store.save_artifact(run_id, f"validation-{implementation_attempt}.json", asdict(validation))
        store.save_artifact(run_id, "validation.json", asdict(validation))
        if not validation.passed:
            if validation_repairs >= budget.validation_repairs:
                record = _updated(record, "BLOCKED", terminal_status="BLOCKED", attempts=attempts)
                store.save(record)
                return record
            validation_repairs += 1
            feedback = _validation_feedback(validation)
            continue

        if reviewer is None:
            record = _updated(record, "READY_FOR_ACCEPTANCE", terminal_status="READY_FOR_ACCEPTANCE", attempts=attempts)
            store.save(record)
            return record

        record = _updated(record, "REVIEWING", attempts=attempts)
        store.save(record)
        git = getattr(workspace_manager, "git", None)
        git_diff = git.diff(workspace.path) if git is not None and hasattr(git, "diff") else ""
        review_result = reviewer.review(ReviewRequest(packet, plan, workspace.path, git_diff, validation))
        store.save_artifact(run_id, f"review-{implementation_attempt}.json", asdict(review_result))
        store.save_artifact(run_id, "review.json", asdict(review_result))
        if review_result.verdict == "PASS":
            record = _updated(record, "READY_FOR_ACCEPTANCE", terminal_status="READY_FOR_ACCEPTANCE", attempts=attempts)
            store.save(record)
            return record
        if review_result.verdict == "BLOCKED" or review_repairs >= budget.review_repairs:
            record = _updated(record, "BLOCKED", terminal_status="BLOCKED", attempts=attempts)
            store.save(record)
            return record
        review_repairs += 1
        feedback = _review_feedback(review_result)


def _updated(record: RunRecord, phase: str, *, terminal_status: str | None = None, attempts: dict[str, int] | None = None) -> RunRecord:
    return replace(
        record,
        updated_at=datetime.now(timezone.utc).isoformat(),
        phase=phase,
        terminal_status=terminal_status,
        attempt_counts=attempts if attempts is not None else record.attempt_counts,
    )


def _validation_feedback(summary) -> str:
    return "\n".join(f"{result.command}: {result.stderr or result.stdout or 'failed'}" for result in summary.results if not result.passed)


def _review_feedback(result) -> str:
    return "\n".join(f"{finding.severity}: {finding.evidence} -> {finding.recommendation}" for finding in result.findings) or (result.error or result.summary)
