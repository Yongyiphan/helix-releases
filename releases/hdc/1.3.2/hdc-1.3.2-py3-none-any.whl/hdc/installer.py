"""Privileged installation of versioned HDC wheel releases."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import re
import shutil
import sys
import tomllib
import typer

from .config import Config, load_config
from .deployment_support import deployment_path, render_deployment_config, render_update_helper, render_updates_config
from .process import CommandRunner, CommandError
from .service import render_cli_launcher, render_service_descriptor


class InstallError(RuntimeError):
    pass


@dataclass(frozen=True)
class InstallLayout:
    application_root: Path
    configuration_root: Path
    state_root: Path
    log_root: Path
    retention: int = 3

    @property
    def releases_root(self) -> Path:
        return self.application_root / "releases"

    @property
    def current_link(self) -> Path:
        return self.application_root / "current"


def _read_toml_table(path: Path) -> dict[str, object]:
    try:
        with path.open("rb") as handle:
            value = tomllib.load(handle)
    except (OSError, tomllib.TOMLDecodeError) as exc:
        raise InstallError(f"cannot inspect deployment configuration: {path}") from exc
    if not isinstance(value, dict):
        raise InstallError(f"deployment configuration must be a TOML table: {path}")
    return value


class VersionedInstaller:
    """Install one wheel while preserving the active release and data."""

    def __init__(self, *, runner: CommandRunner | None = None):
        self.runner = runner or CommandRunner()

    def install(self, artifact: Path, config: Config, *, progress=None, drain: bool = True, restart: bool = True, development: bool = False) -> Path:
        if config.worker.identity.platform.lower() == "windows":
            from .windows_installer import WindowsInstaller
            return WindowsInstaller(runner=self.runner).install(artifact, config, progress=progress)
        artifact = Path(artifact).expanduser().resolve()
        if not artifact.is_file() or artifact.suffix != ".whl":
            raise InstallError(f"wheel artifact does not exist: {artifact}")
        if config.worker.identity.platform.lower() != "linux":
            raise InstallError("wheel installation currently supports Linux only")
        paths = config.development_paths if development else config.deployment_paths
        if paths is None:
            raise InstallError("installation path context is unavailable")
        if development and paths.application_root.resolve() == config.source.resolve():
            application_root = paths.state_root / "runtime"
            configuration_root = paths.state_root / "runtime-config"
        else:
            application_root = paths.application_root
            configuration_root = paths.configuration_root
        layout = InstallLayout(application_root, configuration_root, paths.state_root, paths.log_root, config.deployment.release_retention)
        layout.application_root.parent.mkdir(parents=True, exist_ok=True)
        layout.releases_root.mkdir(parents=True, exist_ok=True)
        if layout.application_root.exists() and not (layout.application_root / "releases").is_dir():
            raise InstallError(
                f"application target is not a clean versioned-install root: {layout.application_root}; "
                "remove the old application tree before installing a wheel"
            )
        stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
        version = _release_name(artifact, stamp)
        release = layout.releases_root / version
        if release.exists():
            raise InstallError(f"release already exists: {release}")
        current_target = _read_link(layout.current_link)
        if drain:
            self._drain()
            self._report(progress, "Drain Controller before installation")
        if development:
            self._prepare_development_configuration(layout, config)
        else:
            self._prepare_configuration(layout, config)
        self._report(progress, "Create isolated release runtime")
        # Create the venv at its final path. POSIX venv scripts contain an
        # absolute interpreter path and would break if the directory were renamed.
        release.mkdir(parents=True)
        activated = False
        try:
            runtime = release / ".venv"
            self._run(("python3", "-m", "venv", str(runtime)))
            runtime_python = runtime / "bin" / "python"
            self._run((str(runtime_python), "-m", "pip", "install", "--no-cache-dir", "--timeout", "30", "--retries", "2", str(artifact)))
            self._report(progress, "Install wheel into release")
            if drain:
                self._drain()
            if development:
                self._activate(layout, release, install_launchers=False)
            else:
                self._activate(layout, release)
            activated = True
            if not development:
                self._install_service(layout, config)
                self._run(("systemctl", "daemon-reload"))
                self._install_update_helper(layout, config)
            env = os.environ.copy()
            env.update({"HDC_CONFIG": str(layout.configuration_root / "hdc.toml"), "HDC_STATE_ROOT": str(layout.state_root), "PATH": deployment_path()})
            self._run((str(release / ".venv" / "bin" / "hdc"), "doctor"), env=env)
            if restart and not development:
                self._run(("systemctl", "enable", "hdc-controller.service"))
                self._run(("systemctl", "restart", "hdc-controller.service"))
                self._run(("systemctl", "is-active", "--quiet", "hdc-controller.service"))
                self._report(progress, "Restart and validate Controller")
            else:
                self._report(progress, "Activate validated development release; restart pending" if development else "Activate validated release; restart pending")
            self._cleanup(layout, keep=layout.retention)
            self._report(progress, "Finalize release retention")
            return release
        except Exception:
            active_after_failure = _read_link(layout.current_link)
            if active_after_failure == release:
                if current_target is not None and current_target.exists():
                    if development:
                        self._activate(layout, current_target, install_launchers=False)
                    else:
                        self._activate(layout, current_target)
                    if not development:
                        try:
                            self._run(("systemctl", "restart", "hdc-controller.service"))
                        except InstallError:
                            pass
                else:
                    layout.current_link.unlink(missing_ok=True)
                    try:
                        self._run(("systemctl", "stop", "hdc-controller.service"))
                    except InstallError:
                        pass
            if release.exists() and _read_link(layout.current_link) != release:
                shutil.rmtree(release)
            raise

    def cleanup(self, config: Config, *, keep: int = 3) -> tuple[Path, ...]:
        if config.worker.identity.platform.lower() == "windows":
            from .windows_installer import WindowsInstaller
            return WindowsInstaller(runner=self.runner).cleanup(config, keep=keep)
        paths = config.deployment_paths
        if paths is None:
            raise InstallError("deployment path context is unavailable")
        layout = InstallLayout(paths.application_root, paths.configuration_root, paths.state_root, paths.log_root, keep)
        return self._cleanup(layout, keep=keep)

    def rollback(self, config: Config) -> Path:
        if config.worker.identity.platform.lower() == "windows":
            from .windows_installer import WindowsInstaller
            return WindowsInstaller(runner=self.runner).rollback(config)
        paths = config.deployment_paths
        if paths is None:
            raise InstallError("deployment path context is unavailable")
        if config.worker.identity.platform.lower() != "linux":
            raise InstallError("wheel rollback currently supports Linux only")
        layout = InstallLayout(paths.application_root, paths.configuration_root, paths.state_root, paths.log_root)
        current = _read_link(layout.current_link)
        releases = sorted((path for path in layout.releases_root.iterdir() if path.is_dir() and path != current), key=lambda path: path.stat().st_mtime, reverse=True)
        if not releases:
            raise InstallError("no previous release is available for rollback")
        self._drain()
        self._activate(layout, releases[0])
        self._run(("systemctl", "daemon-reload"))
        self._run(("systemctl", "restart", "hdc-controller.service"))
        self._run(("systemctl", "is-active", "--quiet", "hdc-controller.service"))
        env = os.environ.copy()
        env.update({"HDC_CONFIG": str(layout.configuration_root / "hdc.toml"), "HDC_STATE_ROOT": str(layout.state_root), "PATH": deployment_path()})
        self._run((str(releases[0] / ".venv" / "bin" / "hdc"), "doctor"), env=env)
        return releases[0]

    def _prepare_configuration(self, layout, config):
        layout.configuration_root.mkdir(parents=True, exist_ok=True)
        active = layout.configuration_root / "hdc.toml"
        if active.exists():
            load_config(active)
            # Deployment configuration is operator-owned runtime state. An
            # automatic release must validate it but never rewrite it.
            if "updates" not in _read_toml_table(active) and config.updates.enabled and config.updates.repository:
                with active.open("a", encoding="utf-8") as handle:
                    handle.write("\n" + render_updates_config(config))
        else:
            active.write_text(render_deployment_config(config), encoding="utf-8")
        identity = layout.configuration_root / "controller.id"
        source_identity = config.source.parent / "controller.id"
        if not identity.exists() and source_identity.exists():
            shutil.copy2(source_identity, identity)
        self._prepare_authentication(layout)
        self._prepare_runtime_directories(config)

    @staticmethod
    def _prepare_development_configuration(layout, config):
        layout.configuration_root.mkdir(parents=True, exist_ok=True)
        active = layout.configuration_root / "hdc.toml"
        shutil.copy2(config.source, active)
        source_identity = config.source.parent / "controller.id"
        identity = layout.configuration_root / "controller.id"
        if source_identity.exists() and not identity.exists():
            shutil.copy2(source_identity, identity)

    @staticmethod
    def _prepare_authentication(layout) -> None:
        """Materialize non-secret gh settings without overwriting existing credentials."""
        auth_mode = os.getenv("HDC_GITHUB_AUTH", "").strip().lower()
        if auth_mode != "gh":
            return
        env_file = layout.configuration_root / "hdc.env"
        config_dir = os.getenv("GH_CONFIG_DIR", "").strip()
        if not config_dir:
            raise InstallError("HDC_GITHUB_AUTH=gh requires GH_CONFIG_DIR for the service")
        desired = f"HDC_GITHUB_AUTH=gh\nGH_CONFIG_DIR={config_dir}\n"
        if env_file.exists():
            try:
                existing = [line.strip() for line in env_file.read_text(encoding="utf-8").splitlines() if line.strip()]
            except PermissionError:
                # The service may be able to consume a protected environment
                # file without being allowed to read it during an upgrade.
                # Preserve it; authentication state is operator-owned.
                return
            except OSError as exc:
                raise InstallError(f"cannot read GitHub service environment: {env_file}") from exc
            # Refresh only the non-secret, gh-mode environment created by HDC.
            # Never overwrite a file containing a token or another user setting.
            keys = {line.split("=", 1)[0] for line in existing if "=" in line}
            if keys.issubset({"HDC_GITHUB_AUTH", "GH_CONFIG_DIR"}) and "HDC_GITHUB_AUTH=gh" in existing:
                env_file.write_text(desired, encoding="utf-8")
            return
        env_file.write_text(desired, encoding="utf-8")
        env_file.chmod(0o600)

    @staticmethod
    def _prepare_runtime_directories(config: Config) -> None:
        """Make HDC state/workspace/log roots writable by the service account."""
        service_user = os.getenv("HDC_SERVICE_USER", "").strip()
        if not service_user or config.deployment_paths is None:
            return
        paths = config.deployment_paths
        roots = (paths.state_root, paths.workspace_root, paths.log_root)
        for root in roots:
            root.mkdir(parents=True, exist_ok=True)
            for directory, directories, files in os.walk(root):
                shutil.chown(directory, user=service_user)
                for filename in files:
                    shutil.chown(Path(directory) / filename, user=service_user)

    def _activate(self, layout, release, *, install_launchers=True):
        temporary = layout.application_root / ".current.new"
        if temporary.exists() or temporary.is_symlink():
            temporary.unlink()
        temporary.symlink_to(release)
        os.replace(temporary, layout.current_link)
        if install_launchers:
            launcher = Path("/usr/local/bin/hdc")
            admin = Path("/usr/local/sbin/hdc-admin")
            for destination, script in ((launcher, render_cli_launcher(layout.application_root / "current")), (admin, render_cli_launcher(layout.application_root / "current", "hdc-admin"))):
                destination.parent.mkdir(parents=True, exist_ok=True)
                temporary = destination.with_name(f".{destination.name}.new")
                temporary.write_text(script, encoding="utf-8")
                temporary.chmod(0o755)
                os.replace(temporary, destination)

    def _install_service(self, layout, config):
        service = Path("/etc/systemd/system/hdc-controller.service")
        service.parent.mkdir(parents=True, exist_ok=True)
        service.write_text(render_service_descriptor(
            config,
            python_executable=str(layout.current_link / ".venv" / "bin" / "python"),
            config_file=layout.configuration_root / "hdc.toml",
            working_directory=layout.current_link,
            environment_path=deployment_path(),
            service_user=os.getenv("HDC_SERVICE_USER") or None,
        ), encoding="utf-8")

    @staticmethod
    def _install_update_helper(layout, config):
        """Install the root-owned, fixed-purpose updater entrypoint."""
        service_user = os.getenv("HDC_SERVICE_USER", "").strip()
        if not service_user:
            raise InstallError("HDC_SERVICE_USER is required to install the production update helper")
        helper = Path("/usr/local/sbin/hdc-update-install")
        helper.parent.mkdir(parents=True, exist_ok=True)
        temporary = helper.with_name(f".{helper.name}.new")
        temporary.write_text(render_update_helper(layout.application_root), encoding="utf-8")
        temporary.chmod(0o755)
        os.replace(temporary, helper)
        sudoers = Path("/etc/sudoers.d/hdc-update-install")
        sudoers.parent.mkdir(parents=True, exist_ok=True)
        sudoers.write_text(f"{service_user} ALL=(root) NOPASSWD: {helper}\n", encoding="utf-8")
        sudoers.chmod(0o440)

    def _cleanup(self, layout, *, keep):
        if not layout.releases_root.exists():
            return ()
        current = _read_link(layout.current_link)
        releases = sorted((path for path in layout.releases_root.iterdir() if path.is_dir()), key=lambda path: path.stat().st_mtime, reverse=True)
        protected = {current} if current else set()
        protected.update(releases[:max(keep, 1)])
        removed = []
        for path in releases:
            if path not in protected:
                shutil.rmtree(path)
                removed.append(path)
        return tuple(removed)

    def _drain(self):
        result = self.runner.run(("systemctl", "is-active", "--quiet", "hdc-controller.service"))
        if not isinstance(result, CommandError) and result.ok:
            self._run(("systemctl", "stop", "hdc-controller.service"))

    def _run(self, command, *, env=None):
        result = self.runner.run(command, timeout=300, env=env)
        if isinstance(result, CommandError) or not result.ok:
            detail = result.message if isinstance(result, CommandError) else (result.stderr.strip() or result.stdout.strip())
            raise InstallError(f"command failed: {' '.join(command)}: {detail}")

    @staticmethod
    def _report(progress, text):
        if progress:
            progress(text)


def _read_link(path: Path) -> Path | None:
    if not path.is_symlink():
        return None
    target = Path(os.readlink(path))
    return target if target.is_absolute() else (path.parent / target).resolve()


def _release_name(artifact: Path, stamp: str) -> str:
    stem = re.sub(r"[^A-Za-z0-9_.+-]", "-", artifact.stem)
    return f"{stem}-{stamp}"


app = typer.Typer(help="Install and maintain versioned HDC releases")


@app.command("install")
def install(artifact: Path = typer.Argument(..., exists=True, dir_okay=False)):
    config = load_config()
    try:
        release = VersionedInstaller().install(artifact, config, progress=lambda text: typer.echo(f"OK  {text}"))
    except Exception as exc:
        typer.echo(f"INSTALL ERROR: {exc}", err=True)
        raise typer.Exit(1)
    typer.echo(f"INSTALLED {release}")


@app.command("update-install")
def update_install(
    artifact: Path = typer.Argument(..., exists=True, dir_okay=False),
    sha256: str = typer.Argument(...),
):
    """Install one queued production wheel through the privileged helper."""
    if os.geteuid() != 0:
        typer.echo("UPDATE INSTALL ERROR: this operation must run as root", err=True)
        raise typer.Exit(1)
    config = load_config()
    if config.worker.identity.platform.lower() != "linux" or config.deployment_paths is None:
        typer.echo("UPDATE INSTALL ERROR: Linux deployment paths are required", err=True)
        raise typer.Exit(1)
    queue_root = config.deployment_paths.state_root / "updates" / "incoming"
    try:
        resolved = artifact.expanduser().resolve()
        if resolved.parent != queue_root.resolve() or resolved.suffix != ".whl":
            raise InstallError("artifact must be a wheel directly inside the production update inbox")
        if len(sha256) != 64 or any(character not in "0123456789abcdefABCDEF" for character in sha256):
            raise InstallError("sha256 must be a 64-character hexadecimal digest")
        import hashlib
        actual = hashlib.sha256(resolved.read_bytes()).hexdigest()
        if actual != sha256.lower():
            raise InstallError(f"artifact digest mismatch: expected {sha256.lower()}, got {actual}")
        release = VersionedInstaller().install(resolved, config, progress=lambda text: typer.echo(f"OK  {text}"), drain=False, restart=False)
    except Exception as exc:
        typer.echo(f"UPDATE INSTALL ERROR: {exc}", err=True)
        raise typer.Exit(1)
    typer.echo(f"UPDATE INSTALLED {release}")


@app.command("update-status")
def update_status():
    """Show durable Linux queued-update state."""
    config = load_config()
    if config.worker.identity.platform.lower() != "linux":
        raise typer.BadParameter("queued update status is currently Linux-only")
    if config.deployment_paths is None:
        raise typer.BadParameter("deployment path context is unavailable")
    from .updates import LinuxUpdateQueue
    try:
        status = LinuxUpdateQueue(config.deployment_paths.state_root).read_status()
    except Exception as exc:
        typer.echo(f"UPDATE STATUS ERROR: {exc}", err=True)
        raise typer.Exit(1)
    typer.echo(json.dumps(status, sort_keys=True, indent=2) if status else "NO UPDATE STATUS")


@app.command("cleanup")
def cleanup(keep: int = typer.Option(3, min=1)):
    try:
        removed = VersionedInstaller().cleanup(load_config(), keep=keep)
    except Exception as exc:
        typer.echo(f"CLEANUP ERROR: {exc}", err=True)
        raise typer.Exit(1)
    typer.echo(f"REMOVED {len(removed)} release(s)")


@app.command("list")
def list_releases():
    """List installed HDC releases and identify the active one."""
    config = load_config()
    paths = config.deployment_paths
    if paths is None:
        raise typer.Exit(1)
    root = paths.application_root / "releases"
    current = _read_link(paths.application_root / "current")
    if config.worker.identity.platform.lower() == "windows":
        from .windows_installer import read_manifest
        manifest = read_manifest(paths.application_root)
        current = Path(manifest["active"]) if manifest else None
    if not root.exists():
        typer.echo("No versioned releases installed.")
        return
    for release in sorted((item for item in root.iterdir() if item.is_dir()), key=lambda item: item.stat().st_mtime, reverse=True):
        marker = "CURRENT" if current == release.resolve() else ""
        typer.echo(f"{release.name}\t{marker}".rstrip())


@app.command("rollback")
def rollback():
    try:
        release = VersionedInstaller().rollback(load_config())
    except Exception as exc:
        typer.echo(f"ROLLBACK ERROR: {exc}", err=True)
        raise typer.Exit(1)
    typer.echo(f"ROLLED BACK TO {release}")


@app.command("uninstall")
def uninstall():
    """Remove the Windows service and owned releases, preserving all data."""
    from .windows_installer import WindowsInstaller
    try:
        WindowsInstaller().uninstall(load_config())
    except Exception as exc:
        typer.echo(f"UNINSTALL ERROR: {exc}", err=True)
        raise typer.Exit(1)
    typer.echo("UNINSTALLED; configuration, identity, state, workspaces and logs retained")


if __name__ == "__main__":
    app()
