"""Render platform service descriptors for the persistent Controller."""

from pathlib import Path
import sys
import re

from .config import Config


def _controller_command(python_executable: str | None = None) -> str:
    executable = python_executable or sys.executable
    return f'"{executable}" -m hdc controller run'


def render_cli_launcher(application_root: Path | str, executable: str = "hdc") -> str:
    """Return the stable POSIX command wrapper for the installed HDC release."""
    runtime_hdc = Path(application_root) / ".venv" / "bin" / "hdc"
    runtime_command = runtime_hdc.with_name(executable)
    return "#!/bin/sh\n" f'exec "{runtime_command}" "$@"\n'


def render_service_descriptor(
    config: Config,
    *,
    python_executable: str | None = None,
    config_file: Path | str | None = None,
    working_directory: Path | str | None = None,
    environment_path: str | None = None,
    service_user: str | None = None,
) -> str:
    """Return a service descriptor without registering or starting a service."""
    platform = config.worker.identity.platform.lower()
    root = config.source.parent
    active_config = Path(config_file or config.source)
    service_root = Path(working_directory or root)
    state_root = config.deployment_paths.state_root if config.deployment_paths is not None else Path("/var/lib/helix/hdc")
    configuration_root = config.deployment_paths.configuration_root if config.deployment_paths is not None else Path("/etc/helix/hdc")
    command = _controller_command(python_executable)
    if platform == "linux":
        if service_user is not None and not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_.-]*", service_user):
            raise ValueError("service_user must be a valid system account name")
        return "\n".join([
            "[Unit]",
            "Description=HDC Controller",
            "After=network-online.target",
            "Wants=network-online.target",
            "",
            "[Service]",
            "Type=simple",
            *( [f"User={service_user}"] if service_user else [] ),
            f"WorkingDirectory={service_root}",
            f"Environment=HDC_CONFIG={active_config}",
            f"Environment=HDC_STATE_ROOT={state_root}",
            f"EnvironmentFile=-{configuration_root / 'hdc.env'}",
            *( [f"Environment=HDC_SERVICE_USER={service_user}"] if service_user else [] ),
            *( [f"Environment=PATH={environment_path}"] if environment_path else [] ),
            f"ExecStart={command}",
            "Restart=on-failure",
            "RestartSec=10",
            "PrivateTmp=true",
            "ProtectSystem=full",
            "UMask=0077",
            "",
            "[Install]",
            "WantedBy=multi-user.target",
            "",
        ])
    if platform == "windows":
        escaped_root = str(service_root).replace("'", "''")
        return "\n".join([
            "# HDC Controller foreground service wrapper for Windows.",
            "# Register this command with the chosen service manager after review.",
            f"$HdcRoot = '{escaped_root}'",
            f"$env:HDC_CONFIG = '{str(active_config).replace(chr(39), chr(39) * 2)}'",
            f"$env:HDC_STATE_ROOT = '{str(state_root).replace(chr(39), chr(39) * 2)}'",
            "Set-Location -LiteralPath $HdcRoot",
            f"& {command}",
            "exit $LASTEXITCODE",
            "",
        ])
    raise ValueError(f"unsupported service platform: {config.worker.identity.platform}")


def service_descriptor_suffix(platform: str) -> str:
    normalized = platform.lower()
    if normalized == "linux":
        return ".service"
    if normalized == "windows":
        return ".ps1"
    raise ValueError(f"unsupported service platform: {platform}")


def write_service_descriptor(config: Config, output: Path, *, python_executable: str | None = None) -> Path:
    """Write a reviewed descriptor to an explicit user-selected path."""
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(render_service_descriptor(config, python_executable=python_executable), encoding="utf-8", newline="\n")
    return output
