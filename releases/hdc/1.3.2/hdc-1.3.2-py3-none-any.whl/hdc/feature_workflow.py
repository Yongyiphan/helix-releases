"""Durable local boundary for one selected feature and its TaskPacket batch."""

from dataclasses import asdict, dataclass
from datetime import datetime, timezone
import json
from pathlib import Path


ACTIVE_STATES = {"PLANNING", "RUNNING", "READY_FOR_REVIEW", "UX_READY"}


@dataclass(frozen=True)
class FeatureWorkflow:
    workflow_id: str
    issue: str
    snapshot_id: str
    task_ids: tuple[str, ...]
    state: str = "RUNNING"
    created_at: str = ""
    updated_at: str = ""


class FeatureWorkflowStore:
    """Store the single local feature workflow owned by a Controller."""

    def __init__(self, root: Path | str):
        self.root = Path(root)
        self.path = self.root / "current.json"

    def load(self) -> FeatureWorkflow | None:
        if not self.path.is_file():
            return None
        raw = json.loads(self.path.read_text(encoding="utf-8"))
        workflow = FeatureWorkflow(
            str(raw["workflow_id"]), str(raw["issue"]), str(raw["snapshot_id"]),
            tuple(str(item) for item in raw["task_ids"]), str(raw["state"]),
            str(raw.get("created_at", "")), str(raw.get("updated_at", "")),
        )
        if not workflow.workflow_id or not workflow.issue or not workflow.task_ids:
            raise ValueError(f"invalid feature workflow record: {self.path}")
        if workflow.state not in ACTIVE_STATES | {"BLOCKED", "PUBLISHED", "DONE"}:
            raise ValueError(f"invalid feature workflow state: {workflow.state}")
        return workflow

    def save(self, workflow: FeatureWorkflow) -> None:
        if workflow.state not in ACTIVE_STATES | {"BLOCKED", "PUBLISHED", "DONE"}:
            raise ValueError(f"invalid feature workflow state: {workflow.state}")
        now = datetime.now(timezone.utc).isoformat()
        created = workflow.created_at or now
        self.root.mkdir(parents=True, exist_ok=True)
        self.path.write_text(json.dumps(asdict(FeatureWorkflow(
            workflow.workflow_id, workflow.issue, workflow.snapshot_id,
            tuple(workflow.task_ids), workflow.state, created, now,
        )), indent=2, sort_keys=True) + "\n", encoding="utf-8")

    def start(self, workflow: FeatureWorkflow) -> None:
        current = self.load()
        if current is not None and current.state in ACTIVE_STATES:
            raise ValueError(f"active feature workflow already exists: {current.workflow_id}")
        self.save(workflow)
