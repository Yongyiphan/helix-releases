"""Independent, shell-free validation execution for HDC."""

from dataclasses import dataclass
import shlex
import shutil
import time
from typing import Sequence

from .process import CommandError, CommandRunner

_SHELL_OPERATORS = {"|", "||", ";", "&", "&&", ">", ">>", "<", "<<"}


@dataclass(frozen=True)
class ValidationResult:
    command: str
    exit_code: int | None
    stdout: str
    stderr: str
    duration: float
    timeout: bool
    passed: bool


@dataclass(frozen=True)
class ValidationSummary:
    results: tuple[ValidationResult, ...]

    @property
    def passed(self) -> bool:
        return bool(self.results) and all(result.passed for result in self.results)


class ValidationRunner:
    """Run each validation command independently without a shell."""

    def __init__(self, runner: CommandRunner | None = None, timeout: float = 300.0):
        self.runner = runner or CommandRunner()
        self.timeout = timeout

    def run(self, commands: Sequence[str], *, cwd: str | None = None) -> ValidationSummary:
        results = tuple(self._run_one(command, cwd=cwd) for command in commands)
        return ValidationSummary(results)

    def _run_one(self, command: str, *, cwd: str | None) -> ValidationResult:
        started = time.monotonic()
        try:
            args = shlex.split(command)
        except ValueError as exc:
            return ValidationResult(command, None, "", str(exc), time.monotonic() - started, False, False)
        if not args or any(token in _SHELL_OPERATORS for token in args):
            return ValidationResult(command, None, "", "validation command must be a simple argument list", time.monotonic() - started, False, False)
        args = self._resolve_portable_executable(args)
        result = self.runner.run(args, timeout=self.timeout, cwd=cwd) if cwd is not None else self.runner.run(args, timeout=self.timeout)
        duration = time.monotonic() - started
        if isinstance(result, CommandError):
            return ValidationResult(command, None, "", result.message, duration, result.kind == "timeout", False)
        return ValidationResult(command, result.returncode, result.stdout, result.stderr, duration, False, result.ok)

    @staticmethod
    def _resolve_portable_executable(args: list[str]) -> list[str]:
        """Resolve ``python`` when a minimal host exposes only ``python3``."""
        if args and args[0] == "python" and shutil.which("python") is None and shutil.which("python3"):
            return ["python3", *args[1:]]
        return args
