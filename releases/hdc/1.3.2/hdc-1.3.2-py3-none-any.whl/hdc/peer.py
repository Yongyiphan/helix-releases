"""Authenticated, on-demand Controller-to-Controller context exchange."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
import json
from urllib.request import Request, urlopen
from uuid import uuid4

from .config import Config
from .identity import WorkerIdentity

PEER_PROTOCOL_VERSION = 1
PEER_CONTEXT_PATH = "/hdc/peer/context"


@dataclass(frozen=True)
class PeerContextRequest:
    requester_controller_id: str
    requested_repositories: tuple[str, ...] = ()
    request_id: str = ""
    protocol_version: int = PEER_PROTOCOL_VERSION

    def to_payload(self) -> dict[str, object]:
        return {
            "protocol_version": self.protocol_version,
            "request_id": self.request_id or str(uuid4()),
            "requester_controller_id": self.requester_controller_id,
            "requested_repositories": list(self.requested_repositories),
        }


@dataclass(frozen=True)
class PeerProject:
    name: str
    github_repository: str | None
    hosted: bool
    read_only: bool
    graphify: bool
    base_branch: str


@dataclass(frozen=True)
class PeerContext:
    request_id: str
    controller_id: str
    controller_name: str
    host: str
    platform: str
    status: str
    capabilities: tuple[str, ...]
    projects: tuple[PeerProject, ...]
    observed_at: datetime
    protocol_version: int = PEER_PROTOCOL_VERSION
    controller_version: str = ""
    schema_major: int | None = None
    schema_minor: int | None = None

    def to_payload(self) -> dict[str, object]:
        return {
            "protocol_version": self.protocol_version,
            "request_id": self.request_id,
            "controller_id": self.controller_id,
            "controller_name": self.controller_name,
            "host": self.host,
            "platform": self.platform,
            "status": self.status,
            "capabilities": list(self.capabilities),
            "projects": [
                {
                    "name": project.name,
                    "github_repository": project.github_repository,
                    "hosted": project.hosted,
                    "read_only": project.read_only,
                    "graphify": project.graphify,
                    "base_branch": project.base_branch,
                }
                for project in self.projects
            ],
            "observed_at": self.observed_at.isoformat(),
            "controller_version": self.controller_version,
            "schema_version": {"major": self.schema_major, "minor": self.schema_minor},
        }


def build_peer_context(config: Config, identity: WorkerIdentity, request: dict[str, object]) -> PeerContext:
    """Build public project capability context without exposing local paths."""
    request_id = _non_empty_string(request.get("request_id"), "request_id")
    requested = _string_tuple(request.get("requested_repositories", []), "requested_repositories")
    unknown = set(requested) - set(config.repositories)
    if unknown:
        raise ValueError(f"unknown requested repositories: {', '.join(sorted(unknown))}")
    names = requested or tuple(config.repositories)
    projects = tuple(
        PeerProject(
            name,
            repository.github_repository,
            repository.path is not None,
            repository.read_only,
            repository.graphify,
            repository.base_branch or config.worker.base_branch,
        )
        for name in names
        for repository in [config.repositories[name]]
    )
    return PeerContext(
        request_id,
        identity.controller_id,
        identity.worker_id,
        identity.host,
        identity.platform,
        "available",
        identity.capabilities,
        projects,
        datetime.now(timezone.utc),
        controller_version=_package_version(),
        schema_major=config.schema_version.major,
        schema_minor=config.schema_version.minor,
    )


def request_peer_context(
    url: str,
    request: PeerContextRequest,
    *,
    timeout_seconds: float = 10.0,
    auth_token: str | None = None,
) -> PeerContext:
    target = url.rstrip("/")
    if not target.endswith(PEER_CONTEXT_PATH):
        target += PEER_CONTEXT_PATH
    body = json.dumps(request.to_payload(), sort_keys=True).encode("utf-8")
    headers = {"Accept": "application/json", "Content-Type": "application/json"}
    if auth_token:
        headers["Authorization"] = f"Bearer {auth_token}"
    http_request = Request(target, data=body, method="POST", headers=headers)
    with urlopen(http_request, timeout=timeout_seconds) as response:
        if response.status != 200:
            raise ValueError(f"peer context request returned HTTP {response.status}")
        return peer_context_from_payload(json.loads(response.read().decode("utf-8")))


def peer_context_from_payload(raw: object) -> PeerContext:
    if not isinstance(raw, dict):
        raise ValueError("peer context response must be an object")
    version = raw.get("protocol_version")
    if version != PEER_PROTOCOL_VERSION:
        raise ValueError(f"unsupported peer protocol version: {version}")
    projects_raw = raw.get("projects")
    if not isinstance(projects_raw, list):
        raise ValueError("peer context projects must be a list")
    projects = tuple(
        PeerProject(
            _non_empty_string(item.get("name"), "project.name"),
            _optional_string(item.get("github_repository"), "project.github_repository"),
            _bool_value(item.get("hosted"), "project.hosted"),
            _bool_value(item.get("read_only"), "project.read_only"),
            _bool_value(item.get("graphify"), "project.graphify"),
            _non_empty_string(item.get("base_branch"), "project.base_branch"),
        )
        for item in projects_raw
        if isinstance(item, dict)
    )
    if len(projects) != len(projects_raw):
        raise ValueError("peer context projects must contain objects")
    return PeerContext(
        _non_empty_string(raw.get("request_id"), "request_id"),
        _non_empty_string(raw.get("controller_id"), "controller_id"),
        _non_empty_string(raw.get("controller_name"), "controller_name"),
        _non_empty_string(raw.get("host"), "host"),
        _non_empty_string(raw.get("platform"), "platform"),
        _non_empty_string(raw.get("status"), "status"),
        _string_tuple(raw.get("capabilities"), "capabilities"),
        projects,
        datetime.fromisoformat(_non_empty_string(raw.get("observed_at"), "observed_at")),
        controller_version=_non_empty_string(raw.get("controller_version"), "controller_version"),
        schema_major=_schema_value(raw.get("schema_version"), "major"),
        schema_minor=_schema_value(raw.get("schema_version"), "minor"),
    )


def _package_version() -> str:
    from importlib.metadata import PackageNotFoundError, version
    try:
        return version("hdc")
    except PackageNotFoundError:
        return "development"


def _schema_value(raw: object, key: str) -> int:
    if not isinstance(raw, dict) or isinstance(raw.get(key), bool) or not isinstance(raw.get(key), int):
        raise ValueError(f"schema_version.{key} must be an integer")
    return raw[key]


def _non_empty_string(value: object, field: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"{field} must be a non-empty string")
    return value.strip()


def _optional_string(value: object, field: str) -> str | None:
    if value in (None, ""):
        return None
    return _non_empty_string(value, field)


def _optional_non_empty_string(value: object, field: str) -> str:
    if value in (None, ""):
        return ""
    return _non_empty_string(value, field)


def _bool_value(value: object, field: str) -> bool:
    if not isinstance(value, bool):
        raise ValueError(f"{field} must be boolean")
    return value


def _string_tuple(value: object, field: str) -> tuple[str, ...]:
    if not isinstance(value, list) or not all(isinstance(item, str) and item.strip() for item in value):
        raise ValueError(f"{field} must be a list of non-empty strings")
    result = tuple(item.strip() for item in value)
    if len(set(result)) != len(result):
        raise ValueError(f"{field} must not contain duplicates")
    return result
