"""Human-readable acceptance reports for durable HDC runs."""

import json

from .run_records import RunRecord, RunStore
from .task_packets import TaskPacket


def render_acceptance_report(record: RunRecord, packet: TaskPacket, store: RunStore) -> str:
    worker = store.read_artifact(record.run_id, "worker.json") or {}
    validation = store.read_artifact(record.run_id, "validation.json") or {}
    review = store.read_artifact(record.run_id, "review.json")
    lines = [
        f"HDC ACCEPTANCE REPORT: {record.run_id}",
        "",
        f"Task ID: {packet.id}",
        f"Objective: {packet.objective}",
        f"Repository: {record.repository}",
        f"Workspace: {record.workspace}",
        f"Branch: {record.branch}",
        f"Status: {record.phase}",
        "",
        "Files changed:",
    ]
    changed_files = worker.get("changed_files", [])
    lines.extend(f"- {path}" for path in changed_files) if changed_files else lines.append("- none recorded")
    lines.extend(["", "Validation:"])
    results = validation.get("results", [])
    if results:
        lines.extend(f"- {'PASS' if result.get('passed') else 'FAIL'}: {result.get('command', '')}" for result in results)
    else:
        lines.append("- not recorded")
    lines.extend(["", "Reviewer:"])
    if review:
        lines.append(f"- {review.get('verdict', 'UNKNOWN')}: {review.get('summary', '')}")
        for finding in review.get("findings", []):
            lines.append(f"- {finding.get('severity', 'unknown')}: {finding.get('evidence', '')}")
    else:
        lines.append("- not run")
    lines.extend(["", "Limitations and warnings:"])
    if record.phase != "READY_FOR_ACCEPTANCE":
        lines.append(f"- Run did not reach acceptance: {record.phase}")
    if not review:
        lines.append("- Independent Hermes review was not part of this run.")
    if record.phase == "READY_FOR_ACCEPTANCE" and review and review.get("verdict") != "PASS":
        lines.append("- Reviewer evidence is not a PASS.")
    if len(lines) == 0:
        lines.append("- none")
    lines.extend(["", "Manual acceptance procedure:"])
    lines.extend(f"1. Confirm: {criterion}" for criterion in packet.acceptance)
    lines.extend(f"2. Re-run validation: {command}" for command in packet.validation)
    lines.append(f"3. Inspect the workspace and branch before any human-authorized promotion: {record.workspace}")
    return "\n".join(lines) + "\n"
