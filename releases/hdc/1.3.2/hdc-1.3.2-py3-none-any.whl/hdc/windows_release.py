"""Build from a checkout, then elevate the freshly built wheel's installer."""

import argparse
import base64
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

from .config import load_config
from .packaging import build_wheel
from .process import CommandRunner, CommandError


def elevated_command(python, arguments):
    """Quote one Windows command line, then a PowerShell literal."""
    executable = str(python).replace("'", "''")
    command_line = subprocess.list2cmdline(arguments).replace("'", "''")
    source = ("$ErrorActionPreference = 'Stop'; try { "
              f"$p = Start-Process -FilePath '{executable}' -ArgumentList '{command_line}' "
              "-Verb RunAs -Wait -PassThru; exit $p.ExitCode "
              "} catch { [Console]::Error.WriteLine($_.Exception.Message); exit 1 }")
    return ("powershell.exe", "-NoProfile", "-EncodedCommand", base64.b64encode(source.encode("utf-16le")).decode("ascii"))


def main():
    parser = argparse.ArgumentParser(description="Build and install the Helix HDC Windows service")
    parser.add_argument("--wheel", type=Path, help="Use a wheel instead of building the checkout")
    parser.add_argument("--config", type=Path)
    parser.add_argument("--service-user", help="Windows account; defaults to the invoking account")
    parser.add_argument("--plan", action="store_true", help="Validate configuration and show destinations without building or installing")
    parser.add_argument("--apply", action="store_true", help=argparse.SUPPRESS)
    parser.add_argument("--gh-config", help=argparse.SUPPRESS)
    parser.add_argument("--tool-path", help=argparse.SUPPRESS)
    parser.add_argument("--profile", help=argparse.SUPPRESS)
    args = parser.parse_args()
    if args.wheel:
        args.wheel = args.wheel.resolve()
    if os.name != "nt" or sys.version_info < (3, 11):
        parser.error("Windows and Python 3.11 or newer are required")
    if args.apply:
        try:
            from .windows_installer import WindowsInstaller
            if args.service_user:
                os.environ["HDC_SERVICE_USER"] = args.service_user
            if args.gh_config:
                os.environ.update(HDC_GITHUB_AUTH="gh", GH_CONFIG_DIR=args.gh_config)
            if args.tool_path:
                os.environ["PATH"] = args.tool_path
            if args.profile:
                profile = json.loads(args.profile)
                if set(profile) - {"USERPROFILE", "APPDATA", "LOCALAPPDATA", "HOME"}:
                    raise ValueError("Unexpected service profile settings")
                os.environ.update(profile)
            os.environ.pop("PYTHONPATH", None)
            release = WindowsInstaller().install(args.wheel, load_config(args.config), progress=lambda message: print(message, flush=True))
            print(f"INSTALLED: {release}")
            print("Service: HelixHDC. Manage it with Windows Services or the installed hdc.cmd.")
            return 0
        except Exception as exc:
            print(f"HDC INSTALL ERROR: {exc}", file=sys.stderr)
            return 1
        finally:
            if sys.stdin.isatty():
                input("Press Enter to close the installer window...")
    root = Path(__file__).resolve().parents[2]
    config_path = (args.config or root / "hdc.toml").resolve()
    if not config_path.exists():
        shutil.copy2(root / "hdc.toml.example", config_path)
        print(f"Edit {config_path} for this Windows endpoint, then rerun hdc-install.bat.")
        return 2
    config = load_config(config_path)
    if config.worker.identity.platform != "windows":
        raise ValueError("controller.platform must be windows")
    import tomllib
    raw = tomllib.loads(config_path.read_text(encoding="utf-8"))
    def placeholders(value):
        if isinstance(value, dict):
            return any(placeholders(item) for item in value.values())
        if isinstance(value, list):
            return any(placeholders(item) for item in value)
        return isinstance(value, str) and ("replace-" in value or "<core-" in value)
    if placeholders(raw):
        raise ValueError("Replace the example placeholders in hdc.toml before installation")
    if args.plan:
        print(f"Build: {root / 'dist'}\nApplication: {config.deployment_paths.application_root}\nConfiguration: {config.deployment_paths.configuration_root}\nState: {config.deployment_paths.state_root}\nWorkspaces: {config.deployment_paths.workspace_root}\nLogs: {config.deployment_paths.log_root}\nService: HelixHDC (automatic delayed start)")
        print("Installation starts the controller, including its configured work cycles.")
        return 0
    runner = CommandRunner()
    def run(command, environment=None):
        env = os.environ.copy()
        env.update(environment or {})
        env.pop("PYTHONPATH", None)
        result = runner.run(command, timeout=3600, cwd=root, env=env)
        if isinstance(result, CommandError) or not result.ok:
            detail = result.message if isinstance(result, CommandError) else result.stderr or result.stdout
            raise RuntimeError(detail or f"Command exited with code {result.returncode}; inspect the elevated installer window")
        return result
    os.chdir(root)
    if args.wheel:
        wheel = args.wheel.resolve()
    else:
        print("Building HDC wheel through the same packaging code as hdc-release.sh...", flush=True)
        wheel = build_wheel(root / "dist", runner=runner)[0].resolve()
    print(f"HDC RELEASE ARTIFACT: {wheel}", flush=True)
    print(f"Application: {config.deployment_paths.application_root}\nConfiguration: {config.deployment_paths.configuration_root}", flush=True)
    bootstrap = root / ".hdc/installer-runtime"
    python = bootstrap / "Scripts/python.exe"
    if not python.exists():
        run((sys.executable, "-m", "venv", str(bootstrap)))
    print("Preparing wheel installer and its dependencies...", flush=True)
    run((str(python), "-m", "pip", "install", "--upgrade", "--force-reinstall", str(wheel)))
    account = args.service_user or os.getenv("HDC_SERVICE_USER")
    invoking_account = run(("whoami.exe",)).stdout.strip()
    if account and account.lower() != invoking_account.lower():
        raise ValueError("Run hdc-install.bat under the intended service account so its tool profile and authentication can be captured correctly")
    account = account or invoking_account
    gh_config = os.getenv("GH_CONFIG_DIR", str(Path(os.environ["APPDATA"]) / "GitHub CLI"))
    print("Checking endpoint tools and configuration before requesting elevation...", flush=True)
    preflight = run((str(python), "-I", "-m", "hdc", "doctor"),
        {"HDC_CONFIG": str(config_path), "HDC_GITHUB_AUTH": "gh", "GH_CONFIG_DIR": gh_config})
    print(preflight.stdout, end="", flush=True)
    arguments = ["-I", "-m", "hdc.windows_release", "--apply", "--wheel", str(wheel), "--config", str(config_path),
                 "--service-user", account, "--gh-config", gh_config, "--tool-path", os.environ.get("PATH", ""),
                 "--profile", json.dumps({key: os.environ[key] for key in ("USERPROFILE", "APPDATA", "LOCALAPPDATA", "HOME") if key in os.environ})]
    print(f"Requesting elevation to install/start HelixHDC as {account}. First install requires the account password.", flush=True)
    print("Starting this service enables the controller's configured work cycles, including eligible task processing.", flush=True)
    run(elevated_command(python, arguments))
    print("HDC installation completed. Service: HelixHDC", flush=True)
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as exc:
        print(f"HDC INSTALL ERROR: {exc}", file=sys.stderr)
        raise SystemExit(1)
