"""Replaceable implementation-worker boundary for HDC."""

from dataclasses import dataclass
from pathlib import Path
from typing import Literal, Protocol

from .execution_plan import ExecutionPlan
from .task_packets import TaskPacket

WorkerOutcome = Literal["completed", "failed", "blocked"]


@dataclass(frozen=True)
class WorkerRequest:
    """Stable context HDC supplies for one implementation attempt."""

    task: TaskPacket
    plan: ExecutionPlan
    workspace: Path
    attempt: int
    repository_instructions: tuple[str, ...] = ()
    validation_expectations: tuple[str, ...] = ()
    previous_failure_feedback: str | None = None


@dataclass(frozen=True)
class WorkerResult:
    """Structured worker evidence; HDC owns lifecycle interpretation."""

    outcome: WorkerOutcome
    summary: str
    exit_code: int | None = None
    changed_files: tuple[str, ...] = ()
    error: str | None = None
    blocked_reason: str | None = None


class DevelopmentWorker(Protocol):
    """Interface for Codex or a future implementation worker."""

    def execute(self, request: WorkerRequest) -> WorkerResult:
        """Perform one bounded implementation attempt."""
        ...
