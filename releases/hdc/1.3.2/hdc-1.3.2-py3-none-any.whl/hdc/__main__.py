"""Allow the development checkout to run HDC as ``python -m hdc``."""

from .cli import app


if __name__ == "__main__":
    app()
