"""Event-aware, low-frequency backlog polling for the HDC Controller."""

from dataclasses import dataclass, replace
from datetime import datetime
import hashlib
import json
from pathlib import Path
from threading import Event, Lock
import time
from typing import Callable

from .backlog_decision import DecisionResult, IssueSelector, WorkerAvailability, build_candidates, decide_next_issue
from .backlog_store import BacklogDecisionRecord, BacklogSnapshot, BacklogStore
from .config import Config
from .github import GitHubAdapter, GitHubIssue
from .heartbeat import HeartbeatBackend
from .task_packets import list_task_packets


@dataclass(frozen=True)
class PollResult:
    changed: bool
    snapshot: BacklogSnapshot
    decision: BacklogDecisionRecord | None
    reason: str
    selection: DecisionResult | None = None


class BacklogPoller:
    """Refresh backlog context and decide only when context or an event requires it."""

    def __init__(self, config: Config, repositories: tuple[str, ...], *, github: GitHubAdapter, selector: IssueSelector, store: BacklogStore, availability: dict[str, WorkerAvailability] | None = None, heartbeat_backend: HeartbeatBackend | None = None, heartbeat_timeout_seconds: int = 900, tasks_dir: Path | None = None):
        self.config = config
        self.repositories = repositories
        self.github = github
        self.selector = selector
        self.store = store
        self.availability = availability or {}
        self.heartbeat_backend = heartbeat_backend
        self.heartbeat_timeout_seconds = heartbeat_timeout_seconds
        self.tasks_dir = tasks_dir or (config.source.parent / "tasks")
        self._wake = Event()
        self._event_lock = Lock()
        self._events: list[str] = []

    def notify(self, reason: str) -> None:
        """Wake the Controller for an event-driven refresh after local state changes."""
        if not reason.strip():
            raise ValueError("event reason must not be empty")
        with self._event_lock:
            if reason not in self._events:
                self._events.append(reason)
        self._wake.set()

    def poll_once(self, *, force: bool = False) -> PollResult:
        issues = tuple(self.github.search_issues(self.repositories))
        packets = list_task_packets(self.tasks_dir, set(self.config.repositories))
        availability = dict(self.availability)
        if self.heartbeat_backend is not None:
            now = datetime.now().astimezone()
            for heartbeat in self.heartbeat_backend.list():
                availability[heartbeat.worker_id] = WorkerAvailability(
                    heartbeat.worker_id, heartbeat.is_fresh(now=now, timeout_seconds=self.heartbeat_timeout_seconds),
                    "fresh heartbeat" if heartbeat.is_fresh(now=now, timeout_seconds=self.heartbeat_timeout_seconds) else "heartbeat is stale",
                )
        candidates = build_candidates(self.config, issues, packets, availability)
        previous = self.store.latest_snapshot()
        changed = force or previous is None or _snapshot_fingerprint(previous.issues, previous.candidates) != _candidate_fingerprint(issues, candidates)
        if not changed:
            decision = self.store.latest_decision()
            automation = self.store.latest_automation()
            if decision is not None and decision.status == "SELECTED" and automation is not None and automation.issue == decision.issue and automation.status == "BLOCKED" and automation.attempts >= 3:
                exhausted = tuple(
                    replace(candidate, eligible=False, reasons=(*candidate.reasons, "previous issue exhausted bounded automation retries"))
                    if f"{candidate.issue.repository}#{candidate.issue.number}" == decision.issue else candidate
                    for candidate in candidates
                )
                result = decide_next_issue(self.selector, exhausted)
                decision = self.store.save_decision(previous, result)
                return PollResult(False, previous, decision, "advanced past exhausted automation", result)
            retry = self._retry_selection(previous, decision, automation)
            return PollResult(False, previous, decision, "retrying bounded automation" if retry else "backlog unchanged", retry)
        snapshot = self.store.save_snapshot(self.repositories, issues, candidates)
        result = decide_next_issue(self.selector, candidates)
        decision = self.store.save_decision(snapshot, result)
        return PollResult(True, snapshot, decision, "backlog changed" if previous else "initial backlog snapshot", result)

    @staticmethod
    def _retry_selection(snapshot: BacklogSnapshot, decision: BacklogDecisionRecord | None, automation) -> DecisionResult | None:
        if decision is None or decision.status != "SELECTED" or not decision.issue:
            return None
        if automation is not None and automation.issue == decision.issue and (automation.status != "BLOCKED" or automation.attempts >= 3):
            return None
        repository, separator, raw_number = decision.issue.rpartition("#")
        if not separator or not raw_number.isdigit():
            return None
        issue = next((item for item in snapshot.issues if item.get("repository") == repository and item.get("number") == int(raw_number)), None)
        if issue is None:
            return None
        github_issue = GitHubIssue(repository, int(raw_number), str(issue.get("title", "")), str(issue.get("body", "")), str(issue.get("state", "open")), str(issue.get("url", "")), tuple(str(label) for label in issue.get("labels", [])))
        return DecisionResult("SELECTED", decision.summary, github_issue, None, decision.attempts, decision.rejection_reasons)

    def run(self, *, cycles: int | None = None, interval_seconds: int | None = None, stop: Event | None = None, sleep: Callable[[float], None] = time.sleep) -> list[PollResult]:
        """Run an initial refresh followed by low-frequency refreshes.

        Execution is intentionally absent; this Controller stage only caches and decides.
        """
        interval = interval_seconds or self.config.polling.backlog_interval_seconds
        if interval <= 0:
            raise ValueError("interval_seconds must be positive")
        results: list[PollResult] = []
        count = 0
        while cycles is None or count < cycles:
            event_reason = self._take_event()
            result = self.poll_once(force=(count == 0 and self.config.polling.refresh_on_start) or bool(event_reason))
            if event_reason:
                result = PollResult(result.changed, result.snapshot, result.decision, f"event: {event_reason}", result.selection)
            results.append(result)
            count += 1
            if cycles is not None and count >= cycles:
                break
            if stop is not None and stop.is_set():
                break
            if stop is None and sleep is not time.sleep:
                sleep(interval)
                continue
            if self._wake.wait(interval):
                self._wake.clear()
                if stop is not None and stop.is_set():
                    break
        return results

    def _take_event(self) -> str:
        with self._event_lock:
            reason = "; ".join(self._events)
            self._events.clear()
            return reason


def _candidate_fingerprint(issues: tuple[GitHubIssue, ...], candidates: tuple) -> str:
    raw = {
        "issues": [{
            "repository": issue.repository, "number": issue.number, "title": issue.title,
            "body": issue.body, "state": issue.state, "url": issue.url, "labels": list(issue.labels),
        } for issue in issues],
        "candidates": [{
            "issue": _issue_key(item.issue), "repository": item.repository,
            "worker_id": item.worker_id, "available": item.available,
            "context_only": item.context_only, "eligible": item.eligible,
            "reasons": list(item.reasons),
        } for item in candidates],
    }
    return _digest(raw)


def _snapshot_fingerprint(issues: tuple[dict[str, object], ...], candidates: tuple[dict[str, object], ...]) -> str:
    return _digest({"issues": issues, "candidates": candidates})


def _issue_key(issue: GitHubIssue) -> str:
    return f"{issue.repository}#{issue.number}"


def _digest(value: object) -> str:
    return hashlib.sha256(json.dumps(value, sort_keys=True, default=list, ensure_ascii=False).encode()).hexdigest()
