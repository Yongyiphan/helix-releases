"""Foreground selection of explicitly READY HDC tasks."""

from pathlib import Path
from concurrent.futures import ThreadPoolExecutor

from .config import Config
from .coordination import CoordinationBackend, RemoteTask, TaskClaim
from .lifecycle import TaskLifecycle, TaskStateStore
from .run_records import RunRecord
from .task_packets import TaskPacket, list_task_packets
from .workflow import WorkflowError, start_run
from .paths import task_state_root


def select_ready_tasks(config: Config, tasks_dir: Path, state_store: TaskStateStore | None = None) -> list[tuple[TaskPacket, TaskLifecycle]]:
    state_store = state_store or TaskStateStore(task_state_root(config.source))
    packets = list_task_packets(tasks_dir, set(config.repositories))
    states = {packet.id: state_store.load(packet.id) for packet in packets}
    return [
        (packet, lifecycle)
        for packet in packets
        if (lifecycle := states[packet.id]).execution_authorized
        and all(states.get(dependency, TaskLifecycle(dependency)).state == "DONE" for dependency in packet.dependencies)
    ]


def discover_routable_tasks(config: Config, tasks_dir: Path, coordination: CoordinationBackend, *, now=None) -> list[tuple[TaskPacket, RemoteTask]]:
    """Pair shared READY projections with local canonical TaskPackets."""
    packets = {packet.id: packet for packet in list_task_packets(tasks_dir, set(config.repositories))}
    result = []
    for remote in coordination.discover_tasks(config.worker.identity, now):
        packet = packets.get(remote.task_id)
        if packet is None or packet.repository != remote.repository:
            continue
        if tuple(packet.required_capabilities) != remote.required_capabilities or tuple(packet.dependencies) != remote.dependencies:
            continue
        result.append((packet, remote))
    return result


def claim_routable_tasks(config: Config, tasks_dir: Path, coordination: CoordinationBackend, *, now=None, lease_seconds: int = 900) -> list[tuple[TaskPacket, TaskClaim]]:
    """Claim discovered tasks without starting implementation."""
    claimed = []
    for packet, _ in discover_routable_tasks(config, tasks_dir, coordination, now=now):
        result = coordination.claim_task(packet.id, config.worker.identity, now=now, lease_seconds=lease_seconds)
        if result.acquired and result.claim is not None:
            claimed.append((packet, result.claim))
    return claimed


def run_ready_tasks(config: Config, tasks_dir: Path, state_store: TaskStateStore | None = None, *, max_tasks: int = 1, task_ids: set[str] | None = None) -> list[RunRecord]:
    """Run at most ``max_tasks`` explicitly READY local tasks.

    The Controller default is deliberately one task. A feature workflow owns the
    next task; scanning the whole task directory would allow unrelated work to
    start while that workflow is still active.
    """
    if max_tasks < 1:
        raise ValueError("max_tasks must be positive")
    state_store = state_store or TaskStateStore(task_state_root(config.source))
    records: list[RunRecord] = []
    selected = select_ready_tasks(config, tasks_dir, state_store)
    if task_ids is not None:
        selected = [(packet, ready) for packet, ready in selected if packet.id in task_ids]
    authorized = []
    for packet, ready in selected[:max_tasks]:
        claimed = ready.transition("CLAIMED").transition("RUNNING")
        state_store.save(claimed)
        authorized.append((packet, ready, claimed))

    def execute(item: tuple[TaskPacket, TaskLifecycle, TaskLifecycle]) -> RunRecord | None:
        packet, ready, claimed = item
        try:
            record = start_run(config, packet, lifecycle=ready)
        except WorkflowError:
            state_store.save(claimed.transition("BLOCKED"))
            return None
        if record.phase == "READY_FOR_ACCEPTANCE":
            state_store.save(claimed.transition("REVIEW").transition("ACCEPTANCE"))
        else:
            state_store.save(claimed.transition("BLOCKED"))
        return record

    with ThreadPoolExecutor(max_workers=max_tasks, thread_name_prefix="hdc-worker") as executor:
        for record in executor.map(execute, authorized):
            if record is not None:
                records.append(record)
    return records
