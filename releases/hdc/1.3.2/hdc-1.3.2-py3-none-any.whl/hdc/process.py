"""Safe, mockable execution of external commands."""

from dataclasses import dataclass
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import subprocess
import time
from typing import Mapping, Sequence


@dataclass(frozen=True)
class CommandResult:
    args: tuple[str, ...]
    returncode: int
    stdout: str
    stderr: str

    @property
    def ok(self) -> bool:
        return self.returncode == 0


@dataclass(frozen=True)
class BinaryCommandResult:
    args: tuple[str, ...]
    returncode: int
    stdout: bytes
    stderr: bytes

    @property
    def ok(self) -> bool:
        return self.returncode == 0


@dataclass(frozen=True)
class CommandError:
    kind: str
    message: str


class CommandRunner:
    @staticmethod
    def _audit_args(args: tuple[str, ...]) -> list[str]:
        """Keep audit records useful without persisting large prompts or secrets."""
        audited: list[str] = []
        for arg in args:
            if len(arg) <= 512:
                audited.append(arg)
                continue
            digest = hashlib.sha256(arg.encode("utf-8")).hexdigest()
            audited.append(f"<redacted:{len(arg)} chars sha256={digest}>")
        return audited

    @classmethod
    def _audit(cls, event: dict[str, object]) -> None:
        target = os.getenv("HDC_AUDIT_LOG", "").strip()
        if not target:
            return
        record = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            **event,
        }
        try:
            path = Path(target)
            path.parent.mkdir(parents=True, exist_ok=True)
            with path.open("a", encoding="utf-8") as handle:
                handle.write(json.dumps(record, sort_keys=True) + "\n")
        except OSError:
            # Observability must never change HDC's command behavior.
            return

    def run(
        self,
        args: Sequence[str],
        timeout: float = 10.0,
        cwd: Path | str | None = None,
        env: Mapping[str, str] | None = None,
        input_text: str | None = None,
    ) -> CommandResult | CommandError:
        normalized = tuple(str(arg) for arg in args)
        started = time.monotonic()
        audit_base: dict[str, object] = {
            "event": "external_command",
            "argv": self._audit_args(normalized),
            "cwd": str(cwd) if cwd is not None else None,
            "timeout_seconds": timeout,
        }
        try:
            completed = subprocess.run(
                normalized,
                capture_output=True,
                text=True,
                timeout=timeout,
                check=False,
                shell=False,
                cwd=str(cwd) if cwd is not None else None,
                env=dict(env) if env is not None else None,
                input=input_text,
            )
        except FileNotFoundError:
            error = CommandError("not_found", f"executable not found: {normalized[0]}")
            self._audit({**audit_base, "outcome": error.kind, "error": error.message, "duration_ms": round((time.monotonic() - started) * 1000, 3)})
            return error
        except subprocess.TimeoutExpired:
            error = CommandError("timeout", f"command timed out after {timeout:g}s")
            self._audit({**audit_base, "outcome": error.kind, "error": error.message, "duration_ms": round((time.monotonic() - started) * 1000, 3)})
            return error
        except OSError as exc:
            error = CommandError("os_error", str(exc))
            self._audit({**audit_base, "outcome": error.kind, "error": error.message, "duration_ms": round((time.monotonic() - started) * 1000, 3)})
            return error
        result = CommandResult(normalized, completed.returncode, completed.stdout, completed.stderr)
        self._audit({
            **audit_base,
            "outcome": "ok" if result.ok else "exit_nonzero",
            "returncode": result.returncode,
            "stdout_chars": len(result.stdout),
            "stderr_chars": len(result.stderr),
            "duration_ms": round((time.monotonic() - started) * 1000, 3),
        })
        return result

    def run_binary(
        self,
        args: Sequence[str],
        timeout: float = 10.0,
        cwd: Path | str | None = None,
        env: Mapping[str, str] | None = None,
    ) -> BinaryCommandResult | CommandError:
        """Run a command while preserving binary stdout exactly."""
        normalized = tuple(str(arg) for arg in args)
        try:
            completed = subprocess.run(
                normalized,
                capture_output=True,
                timeout=timeout,
                check=False,
                shell=False,
                cwd=str(cwd) if cwd is not None else None,
                env=dict(env) if env is not None else None,
            )
        except FileNotFoundError:
            return CommandError("not_found", f"executable not found: {normalized[0]}")
        except subprocess.TimeoutExpired:
            return CommandError("timeout", f"command timed out after {timeout:g}s")
        except OSError as exc:
            return CommandError("os_error", str(exc))
        return BinaryCommandResult(normalized, completed.returncode, completed.stdout, completed.stderr)
