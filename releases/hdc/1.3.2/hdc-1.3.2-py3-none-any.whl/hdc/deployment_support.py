"""Helpers used by the wheel installer to materialize deployment configuration."""

import json
import os
from pathlib import Path
import tomllib

from .config import Config, PathContext
from .tool_discovery import find_executable, tool_search_paths


class DeploymentSupportError(RuntimeError):
    pass


def deployment_path() -> str:
    """Build a stable PATH from directories where HDC tools were actually found."""
    paths = list(tool_search_paths())
    for executable in ("codex", "hermes", "graphify"):
        found = find_executable(executable)
        if found:
            parent = Path(found).parent
            if parent not in paths:
                paths.append(parent)
    return os.pathsep.join(str(path) for path in paths)


def render_deployment_config(config: Config, *, source_path: Path | None = None) -> str:
    """Materialize the deployment path context into the active production config."""
    if config.deployment_paths is None:
        raise DeploymentSupportError("deployment path context is unavailable")
    with (source_path or config.source).open("rb") as handle:
        raw = tomllib.load(handle)
    paths = raw.setdefault("paths", {})
    paths["active"] = "deployment"
    paths["development"] = _path_context_values(config.development_paths)
    paths["deployment"] = _path_context_values(config.deployment_paths)
    identity_section = "controller" if "controller" in raw else "worker"
    raw.setdefault(identity_section, {})["workspace_root"] = str(config.deployment_paths.workspace_root)
    raw[identity_section]["id_path"] = str(config.deployment_paths.configuration_root / "controller.id")
    for name, repository in config.repositories.items():
        if repository.path is None:
            raw["repositories"][name].pop("path", None)
        else:
            raw["repositories"][name]["path"] = str(repository.path.resolve())
    return _render_toml(raw)


def _path_context_values(context: PathContext | None) -> dict[str, str]:
    if context is None:
        raise DeploymentSupportError("path context is unavailable")
    return {name: str(getattr(context, name)) for name in (
        "application_root", "configuration_root", "state_root", "workspace_root", "log_root",
    )}


def _render_toml(raw: dict[str, object]) -> str:
    lines: list[str] = []

    def emit_table(values: dict[str, object], prefix: tuple[str, ...] = ()) -> None:
        scalars = [(key, value) for key, value in values.items() if not isinstance(value, dict)]
        tables = [(key, value) for key, value in values.items() if isinstance(value, dict)]
        if prefix:
            lines.append(f"[{'.'.join(_toml_key(part) for part in prefix)}]")
        for key, value in scalars:
            lines.append(f"{_toml_key(key)} = {_toml_value(value)}")
        if prefix and (scalars or tables):
            lines.append("")
        for key, value in tables:
            emit_table(value, prefix + (key,))

    emit_table(raw)
    return "\n".join(lines).rstrip() + "\n"


def _toml_key(value: str) -> str:
    return value if value.replace("_", "").isalnum() else json.dumps(value)


def _toml_value(value: object) -> str:
    if isinstance(value, str):
        return json.dumps(value)
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, (int, float)):
        return str(value)
    if isinstance(value, list):
        return "[" + ", ".join(_toml_value(item) for item in value) + "]"
    raise DeploymentSupportError(f"unsupported TOML value in deployment config: {type(value).__name__}")
