"""Deterministic worker identity and capability matching."""

from dataclasses import dataclass
from pathlib import PurePath
from typing import Literal

WorkerPlatform = Literal["linux", "windows", "macos"]
WORKER_PLATFORMS = {"linux", "windows", "macos"}
CONTROLLER_ROLES = {"core", "endpoint"}


class WorkerIdentityError(ValueError):
    """Raised when worker identity or capability configuration is invalid."""


@dataclass(frozen=True)
class WorkerIdentity:
    worker_id: str
    host: str
    platform: WorkerPlatform
    repositories: tuple[str, ...]
    capabilities: tuple[str, ...]
    controller_id: str = ""
    roles: tuple[str, ...] = ()

    def __post_init__(self) -> None:
        for field, value in (("worker_id", self.worker_id), ("host", self.host)):
            if not value or PurePath(value).name != value:
                raise WorkerIdentityError(f"{field} must be a simple non-empty identifier")
        if self.platform not in WORKER_PLATFORMS:
            raise WorkerIdentityError(f"platform must be one of: {', '.join(sorted(WORKER_PLATFORMS))}")
        _unique_non_empty(self.repositories, "repositories")
        _unique_non_empty(self.capabilities, "capabilities", allow_empty=True)
        if self.controller_id and (len(self.controller_id) != 36 or self.controller_id.count("-") != 4):
            raise WorkerIdentityError("controller_id must be a UUID")
        _unique_non_empty(self.roles, "roles", allow_empty=True)
        if set(self.roles) - CONTROLLER_ROLES:
            raise WorkerIdentityError("roles must be drawn from: core, endpoint")

    def owns_repository(self, repository: str) -> bool:
        return repository in self.repositories

    def supports(self, required_capabilities: tuple[str, ...] | list[str] = ()) -> bool:
        return set(required_capabilities).issubset(self.capabilities)


def _unique_non_empty(values: tuple[str, ...], field: str, *, allow_empty: bool = False) -> None:
    if (not allow_empty and not values) or not all(isinstance(value, str) and value.strip() for value in values):
        raise WorkerIdentityError(f"{field} must be a non-empty list of strings")
    if len(set(values)) != len(values):
        raise WorkerIdentityError(f"{field} must not contain duplicates")
