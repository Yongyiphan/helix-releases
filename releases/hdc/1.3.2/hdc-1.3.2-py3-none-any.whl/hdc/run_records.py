"""Durable local HDC run records."""

from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
import json
from pathlib import Path
from typing import Literal

from .execution_plan import ExecutionPlan
from .paths import runs_root

RunPhase = Literal[
    "PLANNED", "WORKSPACE_READY", "IMPLEMENTING", "VALIDATING", "REVIEWING",
    "READY_FOR_ACCEPTANCE", "BLOCKED", "FAILED", "CANCELLED",
]
@dataclass(frozen=True)
class RunRecord:
    run_id: str
    task_id: str
    repository: str
    branch: str
    workspace: Path
    created_at: str
    updated_at: str
    phase: RunPhase
    attempt_counts: dict[str, int] = field(default_factory=dict)
    terminal_status: str | None = None

    @classmethod
    def planned(cls, run_id: str, plan: ExecutionPlan, *, now: str | None = None) -> "RunRecord":
        timestamp = now or datetime.now(timezone.utc).isoformat()
        return cls(
            run_id=run_id,
            task_id=plan.task_id,
            repository=plan.repository,
            branch=plan.proposed_branch,
            workspace=plan.proposed_workspace,
            created_at=timestamp,
            updated_at=timestamp,
            phase="PLANNED",
        )


class RunStore:
    def __init__(self, root: Path | str | None = None):
        self.root = Path(root) if root is not None else runs_root()

    def create(self, run_id: str, plan: ExecutionPlan, *, now: str | None = None) -> RunRecord:
        directory = self._directory(run_id)
        if directory.exists():
            raise ValueError(f"run already exists: {run_id}")
        record = RunRecord.planned(run_id, plan, now=now)
        directory.mkdir(parents=True)
        self._write_json(directory / "run.json", asdict(record))
        self._write_json(directory / "plan.json", _json_ready(asdict(plan)))
        return record

    def save(self, record: RunRecord) -> None:
        directory = self._directory(record.run_id)
        if not directory.is_dir():
            raise ValueError(f"run not found: {record.run_id}")
        self._write_json(directory / "run.json", asdict(record))

    def save_artifact(self, run_id: str, name: str, value: object) -> None:
        """Persist structured phase evidence beside the run record."""
        if not name.endswith(".json") or Path(name).name != name:
            raise ValueError(f"invalid run artifact name: {name!r}")
        directory = self._directory(run_id)
        if not directory.is_dir():
            raise ValueError(f"run not found: {run_id}")
        self._write_json(directory / name, value)

    def load(self, run_id: str) -> RunRecord:
        path = self._directory(run_id) / "run.json"
        try:
            raw = json.loads(path.read_text(encoding="utf-8"))
        except FileNotFoundError as exc:
            raise ValueError(f"run not found: {run_id}") from exc
        raw["workspace"] = Path(raw["workspace"])
        return RunRecord(**raw)

    def read_artifact(self, run_id: str, name: str) -> dict | None:
        if not name.endswith(".json") or Path(name).name != name:
            raise ValueError(f"invalid run artifact name: {name!r}")
        path = self._directory(run_id) / name
        if not path.is_file():
            return None
        return json.loads(path.read_text(encoding="utf-8"))

    def list(self) -> list[RunRecord]:
        if not self.root.is_dir():
            return []
        records: list[RunRecord] = []
        for directory in sorted(self.root.iterdir()):
            if directory.is_dir() and (directory / "run.json").is_file():
                records.append(self.load(directory.name))
        return records

    def _directory(self, run_id: str) -> Path:
        if not run_id or Path(run_id).name != run_id or run_id in {".", ".."}:
            raise ValueError(f"invalid run ID: {run_id!r}")
        return self.root / run_id

    @staticmethod
    def _write_json(path: Path, value: object) -> None:
        path.write_text(json.dumps(_json_ready(value), indent=2, sort_keys=True) + "\n", encoding="utf-8")


def _json_ready(value: object) -> object:
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, dict):
        return {str(key): _json_ready(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_json_ready(item) for item in value]
    return value
