"""Read-only backlog selection with Hermes advice and deterministic vetting."""

from dataclasses import dataclass
import json
import re
from pathlib import Path
from typing import Literal, Protocol, Sequence

from .architect import _strings
from .config import Config
from .github import GitHubIssue
from .process import CommandError, CommandRunner
from .task_packets import TaskPacket

DecisionStatus = Literal["SELECTED", "NEEDS_INPUT", "NO_ELIGIBLE_ISSUE", "BLOCKED"]


@dataclass(frozen=True)
class WorkerAvailability:
    worker_id: str
    available: bool
    reason: str = ""


@dataclass(frozen=True)
class BacklogCandidate:
    issue: GitHubIssue
    repository: str
    worker_id: str
    available: bool
    context_only: bool
    eligible: bool
    reasons: tuple[str, ...] = ()


@dataclass(frozen=True)
class SelectionRequest:
    context: str
    candidates: tuple[BacklogCandidate, ...]
    rejected_recommendations: tuple[str, ...] = ()


@dataclass(frozen=True)
class SelectionResponse:
    status: Literal["SELECTED", "NEEDS_INPUT", "NO_ELIGIBLE_ISSUE"]
    summary: str
    repository: str | None = None
    issue_number: int | None = None
    questions: tuple[str, ...] = ()
    malformed: bool = False


@dataclass(frozen=True)
class DecisionResult:
    status: DecisionStatus
    summary: str
    issue: GitHubIssue | None = None
    candidate: BacklogCandidate | None = None
    attempts: int = 0
    rejection_reasons: tuple[str, ...] = ()


class IssueSelector(Protocol):
    def select(self, request: SelectionRequest) -> SelectionResponse: ...


def build_candidates(
    config: Config,
    issues: Sequence[GitHubIssue],
    packets: Sequence[TaskPacket],
    availability: dict[str, WorkerAvailability] | None = None,
) -> tuple[BacklogCandidate, ...]:
    """Build an ecosystem snapshot without changing GitHub or task state."""
    availability = availability or {}
    linked = {
        (reference.repository, reference.number)
        for packet in packets
        for reference in packet.github_issues
    }
    by_slug = {
        repo.github_repository: repo.name
        for repo in config.repositories.values()
        if repo.github_repository
    }
    candidates: list[BacklogCandidate] = []
    for issue in sorted(issues, key=lambda item: (item.repository, item.number)):
        repository = by_slug.get(issue.repository, issue.repository.rsplit("/", 1)[-1])
        worker_id, worker_available, worker_reason = _worker_for(repository, config, availability)
        reasons: list[str] = []
        context_only = _is_parent_issue(issue)
        if issue.state != "open":
            reasons.append(f"issue state is {issue.state}")
        if (issue.repository, issue.number) in linked:
            reasons.append("issue is already linked to a TaskPacket")
        if context_only:
            reasons.append("parent/context issue; implementation belongs to child issues")
        if not issue.title.strip() or not issue.body.strip():
            reasons.append("issue lacks a title or body")
        if not worker_available:
            reasons.append(worker_reason or f"required worker {worker_id} is unavailable")
        candidates.append(BacklogCandidate(
            issue, repository, worker_id, worker_available, context_only,
            not reasons, tuple(reasons),
        ))
    return tuple(candidates)


def decide_next_issue(
    selector: IssueSelector,
    candidates: Sequence[BacklogCandidate],
    *,
    max_attempts: int = 3,
) -> DecisionResult:
    """Ask Hermes for a candidate and vet every response before accepting it."""
    if max_attempts < 1:
        raise ValueError("max_attempts must be positive")
    eligible = tuple(candidate for candidate in candidates if candidate.eligible)
    if not eligible:
        return DecisionResult("NO_ELIGIBLE_ISSUE", "No backlog issue is currently eligible for selection.", attempts=0)
    context = render_backlog_context(candidates)
    rejected: list[str] = []
    for attempt in range(1, max_attempts + 1):
        response = selector.select(SelectionRequest(context, tuple(candidates), tuple(rejected)))
        if response.malformed:
            rejected.append(f"HDC rejected Hermes response: {response.summary}")
            continue
        if response.status == "NEEDS_INPUT":
            questions = "; ".join(response.questions)
            return DecisionResult("NEEDS_INPUT", response.summary + (f" Questions: {questions}" if questions else ""), attempts=attempt, rejection_reasons=tuple(rejected))
        if response.status == "NO_ELIGIBLE_ISSUE":
            return DecisionResult("NO_ELIGIBLE_ISSUE", response.summary, attempts=attempt, rejection_reasons=tuple(rejected))
        candidate = next((item for item in eligible if item.issue.repository == response.repository and item.issue.number == response.issue_number), None)
        if candidate is not None:
            return DecisionResult("SELECTED", response.summary, candidate.issue, candidate, attempt, tuple(rejected))
        reason = _rejection_reason(response, candidates)
        rejected.append(reason)
    return DecisionResult("BLOCKED", "Hermes recommendations remained invalid after the bounded decision attempts.", attempts=max_attempts, rejection_reasons=tuple(rejected))


class HermesIssueSelector:
    """Use one bounded Hermes call for issue selection; never execute work."""

    def __init__(self, runner: CommandRunner | None = None, hermes_executable: str = "hermes", timeout: float = 1800.0):
        self.runner = runner or CommandRunner()
        self.hermes_executable = hermes_executable
        self.timeout = timeout

    def select(self, request: SelectionRequest) -> SelectionResponse:
        prompt = build_selection_prompt(request)
        result = self.runner.run([self.hermes_executable, "--safe-mode", "--oneshot", prompt], timeout=self.timeout)
        if isinstance(result, CommandError):
            return SelectionResponse("NO_ELIGIBLE_ISSUE", f"Hermes selection failed: {result.message}")
        if not result.ok:
            return SelectionResponse("NO_ELIGIBLE_ISSUE", f"Hermes selection failed: {result.stderr.strip() or result.returncode}")
        return parse_selection_response(result.stdout)


def build_selection_prompt(request: SelectionRequest) -> str:
    feedback = "\n".join(f"- {item}" for item in request.rejected_recommendations) or "- none"
    return "\n".join([
        "You are the HDC backlog decision consultant.",
        "Select the single best eligible GitHub issue for future implementation.",
        "Do not propose implementation steps for parent/context issues; select an implementation-ready child issue instead.",
        "Return ONLY JSON: {status, summary, repository, issue_number, questions}.",
        "status must be SELECTED, NEEDS_INPUT, or NO_ELIGIBLE_ISSUE.",
        "For SELECTED, repository and issue_number must identify one candidate exactly.",
        "A recommendation is advisory; HDC will deterministically vet it.",
        "",
        "Backlog context:", request.context,
        "",
        "Previous HDC rejection feedback; do not repeat these recommendations:", feedback,
    ])


def parse_selection_response(output: str) -> SelectionResponse:
    try:
        raw = json.loads(output)
        status = raw["status"]
        if status not in {"SELECTED", "NEEDS_INPUT", "NO_ELIGIBLE_ISSUE"}:
            raise ValueError("invalid selection status")
        summary = raw["summary"]
        if not isinstance(summary, str) or not summary.strip():
            raise ValueError("summary must be a non-empty string")
        questions = _strings(raw.get("questions", []), "questions")
        if status == "SELECTED":
            repository = raw.get("repository")
            number = raw.get("issue_number")
            if not isinstance(repository, str) or not repository.strip() or isinstance(number, bool) or not isinstance(number, int) or number <= 0:
                raise ValueError("SELECTED requires repository and positive issue_number")
            return SelectionResponse(status, summary.strip(), repository.strip(), number, questions)
        return SelectionResponse(status, summary.strip(), questions=questions)
    except (json.JSONDecodeError, KeyError, TypeError, ValueError) as exc:
        return SelectionResponse("NO_ELIGIBLE_ISSUE", f"Hermes returned invalid selection output: {exc}", malformed=True)


def render_backlog_context(candidates: Sequence[BacklogCandidate]) -> str:
    lines = []
    for candidate in candidates:
        issue = candidate.issue
        lines.append(json.dumps({
            "issue": f"{issue.repository}#{issue.number}",
            "title": issue.title,
            "body": issue.body[:6000],
            "labels": list(issue.labels),
            "repository": candidate.repository,
            "worker": candidate.worker_id,
            "worker_available": candidate.available,
            "context_only": candidate.context_only,
            "eligible": candidate.eligible,
            "reasons": list(candidate.reasons),
        }, ensure_ascii=False))
    return "\n".join(lines)


def _is_parent_issue(issue: GitHubIssue) -> bool:
    lowered = issue.title.casefold()
    return "type:epic" in issue.labels or "epic:" in lowered or bool(re.search(r"\bHX-[A-Z0-9-]+\.C\d+\b", issue.body))


def _worker_for(repository: str, config: Config, availability: dict[str, WorkerAvailability]) -> tuple[str, bool, str]:
    configured = config.repositories.get(repository)
    if configured is not None and configured.path is not None and repository in config.worker.identity.repositories:
        worker_id = config.worker.identity.worker_id
        status = availability.get(worker_id, WorkerAvailability(worker_id, True))
        return status.worker_id, status.available, status.reason
    conventional = {"helix-core": "core-vm", "helix-endpoint": "endpoint-windows"}.get(repository, f"worker-for-{repository}")
    status = availability.get(conventional, WorkerAvailability(conventional, False, "no local worker configuration"))
    return status.worker_id, status.available, status.reason


def _rejection_reason(response: SelectionResponse, candidates: Sequence[BacklogCandidate]) -> str:
    selected = f"{response.repository}#{response.issue_number}"
    known = {f"{item.issue.repository}#{item.issue.number}": item for item in candidates}
    candidate = known.get(selected)
    if candidate is None:
        return f"HDC rejected Hermes recommendation {selected}: issue was not in the gathered backlog."
    return f"HDC rejected Hermes recommendation {selected}: {'; '.join(candidate.reasons) or 'candidate is not eligible'}."
