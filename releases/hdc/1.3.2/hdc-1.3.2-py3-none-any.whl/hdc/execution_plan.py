"""Deterministic planning for a potential HDC task execution."""

from dataclasses import dataclass
from pathlib import Path

from .adapters import CodexAdapter, GitAdapter, HermesAdapter, ToolStatus
from .config import Config
from .task_packets import TaskPacket

@dataclass(frozen=True)
class ExecutionPlan:
    task_id: str
    repository: str
    repository_path: Path | None
    repository_read_only: bool
    worker_id: str
    worker_platform: str
    worker_capabilities: list[str]
    current_branch: str | None
    proposed_branch: str
    proposed_workspace: Path
    risk: str
    dependencies: list[str]
    required_capabilities: list[str]
    base_branch: str
    validation: list[str]
    stop_conditions: list[str]
    codex_available: bool
    hermes_available: bool
    execution_permitted: bool
    denial_reasons: list[str]


def _availability(status: ToolStatus) -> bool:
    return status.available


def build_execution_plan(
    config: Config,
    packet: TaskPacket,
    *,
    git: GitAdapter | None = None,
    codex: CodexAdapter | None = None,
    hermes: HermesAdapter | None = None,
    require_hermes: bool = True,
) -> ExecutionPlan:
    """Build a plan without changing repository, filesystem, or agent state."""
    git = git or GitAdapter()
    codex = codex or CodexAdapter()
    hermes = hermes or HermesAdapter()
    repository = config.repository(packet.repository)

    current_branch = git.current_branch(repository.path) if repository.path is not None else None
    codex_available = _availability(codex.status())
    hermes_available = _availability(hermes.status()) if require_hermes else False
    denial_reasons: list[str] = []
    if repository.read_only:
        denial_reasons.append(f"repository {repository.name} is configured read_only=true")
    if repository.path is None:
        denial_reasons.append(f"repository {repository.name} is not hosted by this Controller")
    if not codex_available:
        denial_reasons.append("Codex executable is unavailable")
    if require_hermes and not hermes_available:
        denial_reasons.append("Hermes executable is unavailable")

    return ExecutionPlan(
        task_id=packet.id,
        repository=repository.name,
        repository_path=repository.path,
        repository_read_only=repository.read_only,
        worker_id=config.worker.identity.worker_id,
        worker_platform=config.worker.identity.platform,
        worker_capabilities=list(config.worker.identity.capabilities),
        current_branch=current_branch,
        proposed_branch=f"hdc/{packet.id}",
        proposed_workspace=config.worker.workspace_root / packet.id,
        risk=packet.risk,
        dependencies=list(packet.dependencies),
        required_capabilities=list(packet.required_capabilities),
        base_branch=repository.base_branch or config.worker.base_branch,
        validation=list(packet.validation),
        stop_conditions=list(packet.stop_conditions),
        codex_available=codex_available,
        hermes_available=hermes_available,
        execution_permitted=not denial_reasons,
        denial_reasons=denial_reasons,
    )
