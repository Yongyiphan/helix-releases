"""Deterministic discovery of external HDC tools across user and service environments."""

from pathlib import Path
import os
import shutil

try:
    import pwd
except ImportError:  # pragma: no cover - pwd is POSIX-only
    pwd = None


def tool_search_paths(environ: dict[str, str] | None = None) -> tuple[Path, ...]:
    """Return existing executable directories visible to the current deployment context."""
    environment = environ or os.environ
    raw = [Path(entry) for entry in environment.get("PATH", "").split(os.pathsep) if entry]
    account = environment.get("SUDO_USER") or environment.get("HDC_SERVICE_USER")
    if pwd is not None and account:
        try:
            home = Path(pwd.getpwnam(account).pw_dir)
        except KeyError:
            home = None
        if home is not None:
            raw.extend(home / name for name in (".local/bin", ".opencode/bin", ".cargo/bin", ".linuxbrew/bin"))
    raw.extend(Path(path) for path in ("/home/linuxbrew/.linuxbrew/bin", "/opt/homebrew/bin"))
    return tuple(dict.fromkeys(path for path in raw if path.is_dir()))


def find_executable(executable: str, environ: dict[str, str] | None = None) -> str | None:
    """Find an executable using PATH and safe user/system installation directories."""
    found = shutil.which(executable)
    if found:
        return found
    search_path = os.pathsep.join(str(path) for path in tool_search_paths(environ))
    return shutil.which(executable, path=search_path) if search_path else None
