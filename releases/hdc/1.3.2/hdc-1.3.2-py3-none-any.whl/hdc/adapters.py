"""Small read-only adapters for tools used by HDC."""

from dataclasses import dataclass
from pathlib import Path
import shutil

from .process import CommandError, CommandResult, CommandRunner
from .tool_discovery import find_executable


@dataclass(frozen=True)
class ToolStatus:
    name: str
    executable: str | None
    available: bool
    version: str | None = None
    error: str | None = None


class ToolAdapter:
    status_timeout = 10.0

    def __init__(self, name: str, executable: str, runner: CommandRunner | None = None):
        self.name, self.executable = name, executable
        self.runner = runner or CommandRunner()

    def status(self) -> ToolStatus:
        path = find_executable(self.executable)
        if not path:
            return ToolStatus(self.name, None, False, error="executable not found")
        result = self.runner.run([path, "--version"], timeout=self.status_timeout)
        if isinstance(result, CommandError):
            return ToolStatus(self.name, path, False, error=result.message)
        version = (result.stdout or result.stderr).strip().splitlines()
        return ToolStatus(self.name, path, result.ok, version[0] if version else None, None if result.ok else (result.stderr.strip() or "version command failed"))


class GitAdapter(ToolAdapter):
    def __init__(self, runner: CommandRunner | None = None):
        super().__init__("Git", "git", runner)

    def repository_valid(self, path: Path) -> bool:
        result = self.runner.run([self.executable, "-C", str(path), "rev-parse", "--is-inside-work-tree"])
        return isinstance(result, CommandResult) and result.ok and result.stdout.strip() == "true"

    def repository_status(self, path: Path) -> str:
        result = self.runner.run([self.executable, "-C", str(path), "status", "--short", "--branch"])
        if isinstance(result, CommandError) or not result.ok:
            return result.message if isinstance(result, CommandError) else result.stderr.strip()
        return result.stdout.strip()

    def current_branch(self, path: Path) -> str | None:
        result = self.runner.run([self.executable, "-C", str(path), "branch", "--show-current"])
        if isinstance(result, CommandError) or not result.ok:
            return None
        branch = result.stdout.strip()
        return branch or None

    def create_worktree(self, repository: Path, workspace: Path, branch: str, base_branch: str = "main") -> CommandResult | CommandError:
        base_ref = self._resolve_base_ref(repository, base_branch)
        return self.runner.run([
            self.executable, "-C", str(repository), "worktree", "add", "-b", branch, str(workspace), base_ref,
        ], timeout=30.0)

    def _resolve_base_ref(self, repository: Path, base_branch: str) -> str:
        """Prefer a local base branch, falling back to its origin tracking ref."""
        local_ref = self.runner.run([
            self.executable, "-C", str(repository), "rev-parse", "--verify", f"refs/heads/{base_branch}"
        ])
        if isinstance(local_ref, CommandResult) and local_ref.ok:
            return base_branch
        remote_ref = self.runner.run([
            self.executable, "-C", str(repository), "rev-parse", "--verify", f"refs/remotes/origin/{base_branch}"
        ])
        if isinstance(remote_ref, CommandResult) and remote_ref.ok:
            return f"origin/{base_branch}"
        return base_branch

    def diff(self, path: Path) -> str:
        result = self.runner.run([self.executable, "-C", str(path), "diff", "HEAD"])
        if isinstance(result, CommandError) or not result.ok:
            return ""
        return result.stdout


class CodexAdapter(ToolAdapter):
    def __init__(self, runner: CommandRunner | None = None):
        super().__init__("Codex", "codex", runner)


class HermesAdapter(ToolAdapter):
    status_timeout = 30.0

    def __init__(self, runner: CommandRunner | None = None):
        super().__init__("Hermes", "hermes", runner)


class GraphifyAdapter(ToolAdapter):
    def __init__(self, runner: CommandRunner | None = None):
        super().__init__("Graphify", "graphify", runner)

    def output_status(self, path: Path) -> dict[str, bool]:
        output = path / "graphify-out"
        return {name: (output / name).is_file() for name in ("graph.json", "GRAPH_REPORT.md", "graph.html")}
