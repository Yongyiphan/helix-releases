"""Durable design-session state and deterministic DRAFT task persistence."""

from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
import json
from pathlib import Path

from .architect import ArchitectResult, ProposedTask, TaskDependency
from .task_packets import TaskPacket
from .paths import design_root


@dataclass(frozen=True)
class DesignSession:
    design_id: str
    created_at: str
    updated_at: str
    user_request: str
    repositories: tuple[str, ...] = ()
    relevant_issues: tuple[str, ...] = ()
    graphify_concepts: tuple[str, ...] = ()
    questions: tuple[str, ...] = ()
    answers: tuple[str, ...] = ()
    proposed_tasks: tuple[ProposedTask, ...] = ()
    dependencies: tuple[TaskDependency, ...] = ()
    status: str = "OPEN"

    @classmethod
    def create(cls, design_id: str, user_request: str, repositories: tuple[str, ...] = ()) -> "DesignSession":
        timestamp = datetime.now(timezone.utc).isoformat()
        return cls(design_id, timestamp, timestamp, user_request, repositories)


class DesignSessionStore:
    def __init__(self, root: Path | str | None = None):
        self.root = Path(root) if root is not None else design_root()

    def create(self, design_id: str, user_request: str, repositories: tuple[str, ...] = ()) -> DesignSession:
        directory = self._directory(design_id)
        if directory.exists():
            raise ValueError(f"design session already exists: {design_id}")
        session = DesignSession.create(design_id, user_request, repositories)
        directory.mkdir(parents=True)
        self.save(session)
        return session

    def save(self, session: DesignSession) -> None:
        directory = self._directory(session.design_id)
        directory.mkdir(parents=True, exist_ok=True)
        directory.joinpath("session.json").write_text(json.dumps(_ready(asdict(session)), indent=2, sort_keys=True) + "\n", encoding="utf-8")

    def load(self, design_id: str) -> DesignSession:
        try:
            raw = json.loads(self._directory(design_id).joinpath("session.json").read_text(encoding="utf-8"))
        except FileNotFoundError as exc:
            raise ValueError(f"design session not found: {design_id}") from exc
        raw["proposed_tasks"] = tuple(ProposedTask(**item) for item in raw.get("proposed_tasks", []))
        raw["dependencies"] = tuple(TaskDependency(item["task_id"], tuple(item["depends_on"])) for item in raw.get("dependencies", []))
        for key in ("repositories", "relevant_issues", "graphify_concepts", "questions", "answers"):
            raw[key] = tuple(raw.get(key, []))
        return DesignSession(**raw)

    def save_result(self, session: DesignSession, result: ArchitectResult) -> DesignSession:
        updated = DesignSession(
            session.design_id, session.created_at, datetime.now(timezone.utc).isoformat(), session.user_request,
            session.repositories, session.relevant_issues, session.graphify_concepts,
            result.questions, session.answers, result.proposed_tasks, result.dependencies,
            "NEEDS_INPUT" if result.status == "NEEDS_INPUT" else ("DRAFTED" if result.status == "READY_TO_DRAFT" else result.status),
        )
        self.save(updated)
        return updated

    def _directory(self, design_id: str) -> Path:
        if not design_id or Path(design_id).name != design_id:
            raise ValueError(f"invalid design ID: {design_id!r}")
        return self.root / design_id


def write_draft_tasks(tasks_dir: Path, tasks: tuple[tuple[TaskPacket, ProposedTask], ...]) -> list[Path]:
    paths = [tasks_dir / f"{packet.id}.toml" for packet, _ in tasks]
    if len({path.name for path in paths}) != len(paths):
        raise ValueError("duplicate proposed task IDs")
    for path in paths:
        if path.exists():
            raise ValueError(f"task packet already exists: {path}")
    for path, (packet, _) in zip(paths, tasks):
        path.write_text(_packet_toml(packet), encoding="utf-8")
    return paths


def _packet_toml(packet: TaskPacket) -> str:
    def array(values: list[str]) -> str:
        return "[" + ", ".join(json.dumps(value) for value in values) + "]"
    def issue_array() -> str:
        return "[" + ", ".join(
            "{repository = " + json.dumps(reference.repository) + ", number = " + str(reference.number) + "}"
            for reference in packet.github_issues
        ) + "]"
    return "\n".join([
        f"id = {json.dumps(packet.id)}", f"repository = {json.dumps(packet.repository)}", f"objective = {json.dumps(packet.objective)}",
        f"scope = {array(packet.scope)}", f"non_goals = {array(packet.non_goals)}", f"acceptance = {array(packet.acceptance)}",
        f"validation = {array(packet.validation)}", f"stop_conditions = {array(packet.stop_conditions)}", f"risk = {json.dumps(packet.risk)}", "",
        f"dependencies = {array(packet.dependencies)}", f"required_capabilities = {array(packet.required_capabilities)}", f"github_issues = {issue_array()}", "",
    ])


def _ready(value: object) -> object:
    if isinstance(value, dict):
        return {key: _ready(item) for key, item in value.items()}
    if isinstance(value, (tuple, list)):
        return [_ready(item) for item in value]
    return value
