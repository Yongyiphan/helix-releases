"""Controller heartbeat contract and coordination backends."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
import base64
import json
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Callable, Protocol
from urllib.request import Request, urlopen

from .github import GitHubError, GitHubTransport
from .identity import WorkerIdentity

NETWORK_REGISTER_PATH = "/hdc/network/register"


@dataclass(frozen=True)
class WorkerHeartbeat:
    worker_id: str
    host: str
    platform: str
    repositories: tuple[str, ...]
    capabilities: tuple[str, ...]
    observed_at: datetime
    status: str = "available"
    controller_version: str = ""
    controller_id: str = ""
    roles: tuple[str, ...] = ()
    protocol_version: int = 1
    schema_major: int | None = None
    schema_minor: int | None = None
    advertise_urls: tuple[str, ...] = ()

    def is_fresh(self, *, now: datetime | None = None, timeout_seconds: int = 900) -> bool:
        current = now or datetime.now(timezone.utc)
        return self.status == "available" and current - self.observed_at <= timedelta(seconds=timeout_seconds)

    @classmethod
    def from_identity(cls, identity: WorkerIdentity, *, now: datetime | None = None, controller_version: str = "", schema_major: int | None = None, schema_minor: int | None = None, advertise_urls: tuple[str, ...] = ()) -> "WorkerHeartbeat":
        return cls(identity.worker_id, identity.host, identity.platform, identity.repositories, identity.capabilities, now or datetime.now(timezone.utc), "available", controller_version, identity.controller_id, identity.roles, 1, schema_major, schema_minor, advertise_urls)


class HeartbeatBackend(Protocol):
    def publish(self, heartbeat: WorkerHeartbeat) -> bool: ...
    def list(self) -> list[WorkerHeartbeat]: ...


def heartbeat_payload(heartbeat: WorkerHeartbeat) -> dict[str, object]:
    """Return the versioned public Controller heartbeat payload."""
    return _encode(heartbeat)


def request_heartbeat(url: str, *, timeout_seconds: float = 10.0, auth_token: str | None = None) -> WorkerHeartbeat:
    """Read one Controller heartbeat over HTTP(S)."""
    target = url.rstrip("/")
    if not target.endswith("/hdc/heartbeat"):
        target += "/hdc/heartbeat"
    request = Request(target, headers={"Accept": "application/json"})
    if auth_token:
        request.add_header("Authorization", f"Bearer {auth_token}")
    with urlopen(request, timeout=timeout_seconds) as response:
        if response.status != 200:
            raise ValueError(f"heartbeat request returned HTTP {response.status}")
        return _decode(json.loads(response.read().decode("utf-8")))


def send_heartbeat(url: str, heartbeat: WorkerHeartbeat, *, timeout_seconds: float = 10.0, auth_token: str | None = None) -> None:
    """Send one authenticated Controller heartbeat to the Core Controller."""
    target = url.rstrip("/")
    if not target.endswith("/hdc/heartbeat"):
        target += "/hdc/heartbeat"
    request = Request(target, data=json.dumps(heartbeat_payload(heartbeat)).encode("utf-8"), method="POST", headers={"Accept": "application/json", "Content-Type": "application/json"})
    if auth_token:
        request.add_header("Authorization", f"Bearer {auth_token}")
    with urlopen(request, timeout=timeout_seconds) as response:
        if response.status not in (200, 201, 204):
            raise ValueError(f"heartbeat announcement returned HTTP {response.status}")


def register_with_seed(url: str, heartbeat: WorkerHeartbeat, *, timeout_seconds: float = 10.0, auth_token: str | None = None) -> list[WorkerHeartbeat]:
    """Register with one network seed and return its current durable Controller table."""
    target = url.rstrip("/")
    if not target.endswith(NETWORK_REGISTER_PATH):
        target += NETWORK_REGISTER_PATH
    request = Request(
        target,
        data=json.dumps(heartbeat_payload(heartbeat), sort_keys=True).encode("utf-8"),
        method="POST",
        headers={"Accept": "application/json", "Content-Type": "application/json", **({"Authorization": f"Bearer {auth_token}"} if auth_token else {})},
    )
    with urlopen(request, timeout=timeout_seconds) as response:
        if response.status != 200:
            raise ValueError(f"network registration returned HTTP {response.status}")
        raw = json.loads(response.read().decode("utf-8"))
    if not isinstance(raw, dict) or not isinstance(raw.get("controllers"), list):
        raise ValueError("network registration response must contain controllers")
    return [_decode(item) for item in raw["controllers"] if isinstance(item, dict)]


class ControllerRegistry:
    """File-backed Core registry for authenticated Controller presence."""

    def __init__(self, root):
        from pathlib import Path
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)

    def record(self, heartbeat: WorkerHeartbeat) -> None:
        if not heartbeat.controller_id:
            raise ValueError("heartbeat controller_id is required")
        path = self.root / f"{heartbeat.controller_id}.json"
        path.write_text(json.dumps({"heartbeat": heartbeat_payload(heartbeat), "last_seen": heartbeat.observed_at.isoformat()}, sort_keys=True, indent=2) + "\n", encoding="utf-8")

    def list(self) -> list[WorkerHeartbeat]:
        records = []
        for path in sorted(self.root.glob("*.json")):
            raw = json.loads(path.read_text(encoding="utf-8"))
            records.append(_decode(raw["heartbeat"]))
        return records

    def merge(self, heartbeats: list[WorkerHeartbeat]) -> None:
        for heartbeat in heartbeats:
            self.record(heartbeat)

    def payload(self) -> list[dict[str, object]]:
        return [heartbeat_payload(heartbeat) for heartbeat in self.list()]

    def statuses(self, *, now: datetime | None = None, stale_after_seconds: int = 900) -> dict[str, str]:
        """Return each registered Controller as available or stale."""
        return {heartbeat.controller_id: ("available" if heartbeat.is_fresh(now=now, timeout_seconds=stale_after_seconds) else "stale") for heartbeat in self.list()}

    def maintain(self, *, now: datetime | None = None, stale_after_seconds: int = 900) -> dict[str, str]:
        """Refresh derived presence status without deleting registry records.

        Missing Controllers remain registered so their last reported version can continue to
        protect required migration paths. Decommissioning and any later record removal must be
        explicit administrative operations.
        """
        return self.statuses(now=now, stale_after_seconds=stale_after_seconds)

    def prune(
        self,
        *,
        now: datetime | None = None,
        stale_after_seconds: int = 900,
        prune_after_seconds: int = 2592000,
    ) -> list[str]:
        """Compatibility shim: registry maintenance is intentionally non-destructive.

        Keep this method for callers from older releases, but never remove a Controller record
        automatically. The retention argument is accepted for wire/API compatibility only.
        """
        self.maintain(now=now, stale_after_seconds=stale_after_seconds)
        return []


class HeartbeatServer:
    """Foreground HTTP listener for heartbeat and authenticated peer context requests."""

    def __init__(self, heartbeat: WorkerHeartbeat, *, host: str = "127.0.0.1", port: int = 8765, auth_token: str | None = None, registry: ControllerRegistry | None = None, stale_after_seconds: int = 900, prune_after_seconds: int = 2592000, peer_context_provider: Callable[[dict[str, object]], dict[str, object]] | None = None):
        expected = auth_token
        registry_store = registry
        context_provider = peer_context_provider
        stale_limit = stale_after_seconds

        class Handler(BaseHTTPRequestHandler):
            def do_GET(self):  # noqa: N802
                if self.path != "/hdc/heartbeat":
                    self.send_error(404)
                    return
                if expected:
                    authorization = self.headers.get("Authorization", "")
                    if authorization != f"Bearer {expected}":
                        self.send_error(401)
                        return
                body = json.dumps(heartbeat_payload(heartbeat), sort_keys=True, separators=(",", ":")).encode("utf-8")
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)

            def do_POST(self):  # noqa: N802
                if self.path not in {"/hdc/heartbeat", "/hdc/peer/context", NETWORK_REGISTER_PATH}:
                    self.send_error(404)
                    return
                if expected and self.headers.get("Authorization", "") != f"Bearer {expected}":
                    self.send_error(401)
                    return
                try:
                    length = int(self.headers.get("Content-Length", "0"))
                    raw = json.loads(self.rfile.read(length).decode("utf-8"))
                    if self.path == "/hdc/heartbeat":
                        received = _decode(raw)
                        if registry_store is not None:
                            registry_store.record(received)
                            registry_store.maintain(stale_after_seconds=stale_limit)
                    elif self.path == NETWORK_REGISTER_PATH:
                        received = _decode(raw)
                        if registry_store is not None:
                            registry_store.record(received)
                            registry_store.maintain(stale_after_seconds=stale_limit)
                        body = json.dumps({"controllers": registry_store.payload() if registry_store is not None else [heartbeat_payload(received)]}, sort_keys=True, separators=(",", ":")).encode("utf-8")
                        self.send_response(200)
                        self.send_header("Content-Type", "application/json")
                        self.send_header("Content-Length", str(len(body)))
                        self.end_headers()
                        self.wfile.write(body)
                        return
                    else:
                        if context_provider is None:
                            self.send_error(404)
                            return
                        body = json.dumps(context_provider(raw), sort_keys=True, separators=(",", ":")).encode("utf-8")
                        self.send_response(200)
                        self.send_header("Content-Type", "application/json")
                        self.send_header("Content-Length", str(len(body)))
                        self.end_headers()
                        self.wfile.write(body)
                        return
                except (ValueError, KeyError, TypeError, json.JSONDecodeError) as exc:
                    self.send_error(400, str(exc))
                    return
                self.send_response(204)
                self.end_headers()

            def log_message(self, *_args):
                return

        self.server = ThreadingHTTPServer((host, port), Handler)

    def serve_forever(self) -> None:
        self.server.serve_forever()

    def shutdown(self) -> None:
        self.server.shutdown()


class InMemoryHeartbeatBackend:
    def __init__(self):
        self.heartbeats: dict[str, WorkerHeartbeat] = {}

    def publish(self, heartbeat: WorkerHeartbeat) -> bool:
        self.heartbeats[heartbeat.worker_id] = heartbeat
        return True

    def list(self) -> list[WorkerHeartbeat]:
        return sorted(self.heartbeats.values(), key=lambda item: item.worker_id)


class GitHubHeartbeatBackend:
    """Publish one worker's status to the shared HDC control repository."""

    def __init__(self, transport: GitHubTransport, repository: str, *, branch: str = "main", state_root: str = ".hdc/coordination/workers"):
        self.transport, self.repository, self.branch, self.state_root = transport, repository, branch, state_root.strip("/")

    def _path(self, worker_id: str) -> str:
        return f"/repos/{self.repository}/contents/{self.state_root}/{worker_id}.json?ref={self.branch}"

    def _directory(self) -> str:
        return f"/repos/{self.repository}/contents/{self.state_root}?ref={self.branch}"

    def publish(self, heartbeat: WorkerHeartbeat) -> bool:
        sha = None
        try:
            response = self.transport.request("GET", self._path(heartbeat.worker_id))
            if isinstance(response, dict):
                sha = response.get("sha")
        except GitHubError as exc:
            if "404" not in str(exc):
                return False
        payload = {
            "message": f"hdc: heartbeat {heartbeat.worker_id}",
            "content": base64.b64encode(json.dumps(_encode(heartbeat), sort_keys=True, separators=(",", ":")).encode()).decode(),
            "branch": self.branch,
        }
        if isinstance(sha, str):
            payload["sha"] = sha
        try:
            self.transport.request("PUT", self._path(heartbeat.worker_id), payload)
        except GitHubError:
            return False
        return True

    def list(self) -> list[WorkerHeartbeat]:
        try:
            response = self.transport.request("GET", self._directory())
        except GitHubError as exc:
            if "404" in str(exc):
                return []
            raise
        if not isinstance(response, list):
            raise GitHubError("heartbeat directory response must be a list")
        records = []
        for entry in sorted(response, key=lambda item: item.get("name", "") if isinstance(item, dict) else ""):
            name = entry.get("name", "") if isinstance(entry, dict) else ""
            if name.endswith(".json"):
                record = self.transport.request("GET", self._path(name[:-5]))
                if not isinstance(record, dict) or not isinstance(record.get("content"), str):
                    raise GitHubError(f"invalid heartbeat record for {name}")
                records.append(_decode(json.loads(base64.b64decode(record["content"]).decode("utf-8"))))
        return records


def heartbeat_availability(heartbeats: list[WorkerHeartbeat], *, now: datetime | None = None, timeout_seconds: int = 900) -> dict[str, bool]:
    return {heartbeat.worker_id: heartbeat.is_fresh(now=now, timeout_seconds=timeout_seconds) for heartbeat in heartbeats}


def _encode(heartbeat: WorkerHeartbeat) -> dict[str, object]:
    payload = {"protocol_version": heartbeat.protocol_version, "controller_id": heartbeat.controller_id, "controller_name": heartbeat.worker_id, "host": heartbeat.host, "platform": heartbeat.platform, "roles": list(heartbeat.roles), "repositories": list(heartbeat.repositories), "capabilities": list(heartbeat.capabilities), "observed_at": heartbeat.observed_at.isoformat(), "status": heartbeat.status, "controller_version": heartbeat.controller_version, "advertise_urls": list(heartbeat.advertise_urls)}
    if heartbeat.schema_major is not None and heartbeat.schema_minor is not None:
        payload["schema_version"] = {"major": heartbeat.schema_major, "minor": heartbeat.schema_minor}
    return payload


def _decode(raw: dict[str, object]) -> WorkerHeartbeat:
    version = raw.get("schema_version")
    major = minor = None
    if isinstance(version, dict):
        major, minor = version.get("major"), version.get("minor")
        if any(isinstance(value, bool) or not isinstance(value, int) for value in (major, minor)):
            raise ValueError("schema_version major and minor must be integers")
    elif version is not None:
        raise ValueError("schema_version must be an object")
    advertise_urls = raw.get("advertise_urls", ())
    if not isinstance(advertise_urls, (list, tuple)) or not all(isinstance(item, str) and item.strip() for item in advertise_urls):
        raise ValueError("advertise_urls must be a list of non-empty strings")
    return WorkerHeartbeat(str(raw.get("controller_name", raw.get("worker_id", ""))), str(raw["host"]), str(raw["platform"]), tuple(raw.get("repositories", ())), tuple(raw.get("capabilities", ())), datetime.fromisoformat(str(raw["observed_at"])), str(raw.get("status", "available")), str(raw.get("controller_version", "")), str(raw.get("controller_id", "")), tuple(raw.get("roles", ())), int(raw.get("protocol_version", 1)), major, minor, tuple(advertise_urls))
