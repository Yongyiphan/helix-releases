"""Deterministic orchestration for one coordinated worker cycle."""

from dataclasses import dataclass
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

from .config import Config
from .coordination import CoordinationBackend, ResultPublication, TaskClaim, utc_now
from .github import GitHubAdapter
from .lifecycle import TaskLifecycle
from .run_records import RunRecord, RunStore
from .task_packets import TaskPacket, list_task_packets
from .workflow import WorkflowError, start_run
from .workers import DevelopmentWorker
from .workspaces import WorkspaceManager
from .validation import ValidationRunner
from .reviewers import Reviewer


@dataclass(frozen=True)
class CoordinatedTaskResult:
    task_id: str
    claim: TaskClaim
    run: RunRecord | None
    published: bool
    pull_request_url: str = ""
    error: str | None = None


def run_coordinated_cycle(
    config: Config,
    tasks_dir: Path,
    coordination: CoordinationBackend,
    *,
    now: datetime | None = None,
    lease_seconds: int = 900,
    worker: DevelopmentWorker | None = None,
    workspace_manager: WorkspaceManager | None = None,
    validator: ValidationRunner | None = None,
    reviewer: Reviewer | None = None,
    store: RunStore | None = None,
    github: GitHubAdapter | None = None,
    max_tasks: int = 1,
    task_ids: set[str] | None = None,
) -> list[CoordinatedTaskResult]:
    """Discover, claim, execute, and publish each task available to this worker.

    A remote READY projection is the execution authorization for this path. Local
    TaskLifecycle is not changed because the shared projection owns coordination
    state. Every result is published only while the worker's lease is valid.
    """
    if max_tasks < 1:
        raise ValueError("max_tasks must be positive")
    current = now or utc_now()
    packets = {packet.id: packet for packet in list_task_packets(tasks_dir, set(config.repositories))}
    claimed_tasks: list[tuple[TaskPacket, TaskClaim]] = []
    for remote in coordination.discover_tasks(config.worker.identity, current):
        packet = packets.get(remote.task_id)
        if packet is None or packet.repository != remote.repository:
            continue
        if task_ids is not None and packet.id not in task_ids:
            continue
        claim_result = coordination.claim_task(packet.id, config.worker.identity, now=current, lease_seconds=lease_seconds)
        if not claim_result.acquired or claim_result.claim is None:
            continue
        claimed_tasks.append((packet, claim_result.claim))
        if len(claimed_tasks) >= max_tasks:
            break

    def execute(item: tuple[TaskPacket, TaskClaim]) -> CoordinatedTaskResult:
        packet, claim = item
        try:
            record = start_run(
                config,
                packet,
                worker=worker,
                workspace_manager=workspace_manager,
                validator=validator,
                reviewer=reviewer,
                store=store,
                lifecycle=TaskLifecycle(packet.id, "READY"),
            )
            pr_url = _create_draft_pr(config, packet, record, github)
            publication = ResultPublication(
                run_id=record.run_id,
                worker_id=config.worker.identity.worker_id,
                outcome="completed" if record.phase == "READY_FOR_ACCEPTANCE" else "blocked",
                summary=f"HDC run completed with phase {record.phase}",
                branch=record.branch,
                pull_request_url=pr_url,
                blocked_reason=None if record.phase == "READY_FOR_ACCEPTANCE" else record.terminal_status,
                integration_ready=reviewer is not None and record.phase == "READY_FOR_ACCEPTANCE",
            )
            published = coordination.publish_result(packet.id, claim, config.worker.identity, publication, now=current)
            return CoordinatedTaskResult(packet.id, claim, record, published, pr_url)
        except WorkflowError as exc:
            publication = ResultPublication(
                run_id=f"{packet.id}-coordination-failed",
                worker_id=config.worker.identity.worker_id,
                outcome="blocked",
                summary="Coordinated run could not start safely",
                blocked_reason=str(exc),
            )
            published = coordination.publish_result(packet.id, claim, config.worker.identity, publication, now=current)
            return CoordinatedTaskResult(packet.id, claim, None, published, error=str(exc))

    with ThreadPoolExecutor(max_workers=max_tasks, thread_name_prefix="hdc-coordinated-worker") as executor:
        results = list(executor.map(execute, claimed_tasks))
    return results


def _create_draft_pr(config: Config, packet: TaskPacket, record: RunRecord, github: GitHubAdapter | None) -> str:
    if github is None or record.phase != "READY_FOR_ACCEPTANCE":
        return ""
    repository = config.repositories[packet.repository]
    github_repository = getattr(repository, "github_repository", None)
    if not github_repository:
        return ""
    response = github.create_draft_pull_request(
        github_repository,
        head=record.branch,
        base=repository.base_branch or config.worker.base_branch,
        title=f"HDC: {packet.objective}",
        body=f"Automated HDC run `{record.run_id}` for TaskPacket `{packet.id}`.\n\nThis is a draft PR pending review and acceptance.",
    )
    return str(response.get("html_url", "")) if isinstance(response, dict) else ""
